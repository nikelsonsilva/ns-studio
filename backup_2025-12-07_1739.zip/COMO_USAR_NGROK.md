# 🔧 Como Configurar o ngrok

## Problema: Janela abre e fecha

O ngrok precisa ser autenticado na primeira vez.

---

## ✅ Solução: Configurar ngrok

### Passo 1: Criar Conta no ngrok

1. Ir em: https://dashboard.ngrok.com/signup
2. Criar conta (pode usar Google/GitHub)
3. Fazer login

### Passo 2: Copiar seu Authtoken

1. Após login, você será redirecionado para: https://dashboard.ngrok.com/get-started/your-authtoken
2. Copiar o authtoken (exemplo: `2abc123xyz...`)

### Passo 3: Configurar o Authtoken

No PowerShell, executar:

```powershell
ngrok config add-authtoken SEU_TOKEN_AQUI
```

Exemplo:
```powershell
ngrok config add-authtoken 2abc123xyz789...
```

Você verá:
```
Authtoken saved to configuration file: C:\Users\nikel\.ngrok2\ngrok.yml
```

### Passo 4: Executar ngrok

Agora sim, executar:

```powershell
ngrok http 3000
```

---

## 📺 O que você deve ver:

```
ngrok

Session Status                online
Account                       seu_email@gmail.com (Plan: Free)
Version                       3.x.x
Region                        United States (us)
Latency                       50ms
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://abc123-xyz.ngrok-free.app -> http://localhost:3000

Connections                   ttl     opn     rt1     rt5     p50     p90
                              0       0       0.00    0.00    0.00    0.00
```

---

## 🎯 Copiar a URL

Copie a linha **"Forwarding"**:

```
https://abc123-xyz.ngrok-free.app
```

Esta é a URL que você vai usar no Stripe!

---

## ⚠️ Importante

- A janela do ngrok deve **ficar aberta**
- Não feche o terminal
- Se fechar, a URL para de funcionar
- Cada vez que reiniciar, a URL muda

---

## 🔍 Ver Requisições

Abrir no navegador:

```
http://127.0.0.1:4040
```

Aqui você vê todas as requisições que chegam no webhook em tempo real!

---

## 📋 Resumo dos Comandos

```powershell
# 1. Configurar authtoken (só uma vez)
ngrok config add-authtoken SEU_TOKEN

# 2. Iniciar ngrok (deixar aberto)
ngrok http 3000

# 3. Copiar URL do "Forwarding"
# Exemplo: https://abc123-xyz.ngrok-free.app
```

---

## ❓ Ainda não funciona?

### Verificar se ngrok está instalado:

```powershell
ngrok version
```

Deve mostrar:
```
ngrok version 3.x.x
```

### Se não mostrar versão:

O ngrok pode não estar no PATH. Tente:

```powershell
# Verificar onde foi instalado
npm list -g ngrok

# Ou baixar direto do site
# https://ngrok.com/download
```

---

## 🚀 Próximo Passo

Depois que o ngrok estiver rodando:

1. Copiar a URL (ex: `https://abc123-xyz.ngrok-free.app`)
2. Ir para o **Passo 3** do PROXIMOS_PASSOS.md
3. Configurar webhook no Stripe com essa URL
