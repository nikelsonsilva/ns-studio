# 🎯 Configurar Webhook no Stripe - PASSO A PASSO

## ✅ Pré-requisitos

- [x] ngrok rodando
- [x] URL do ngrok copiada (ex: `https://abc123.ngrok-free.app`)

---

## 📋 Passo 1: Abrir Stripe Dashboard

1. Ir em: **https://dashboard.stripe.com/test/webhooks**
2. Fazer login se necessário
3. Você verá a página de "Webhooks"

---

## 📋 Passo 2: Adicionar Endpoint

### Clicar no botão **"+ Add endpoint"** (canto superior direito)

Você verá um formulário com:

---

### 2.1. Endpoint URL

**Cole a URL do ngrok + `/api/stripe/webhook`**

Exemplo:
```
https://abc123-xyz.ngrok-free.app/api/stripe/webhook
```

⚠️ **IMPORTANTE:** Não esqueça o `/api/stripe/webhook` no final!

---

### 2.2. Description (opcional)

```
NS Studio - Webhook de Pagamentos
```

---

### 2.3. Version

Deixar: **Latest API version**

---

### 2.4. Events to send

Clicar em **"+ Select events"**

Na janela que abrir, procurar e selecionar:

#### Opção A - Selecionar Específicos:

1. Digitar "checkout" na busca
2. Marcar: ✅ **checkout.session.completed**

3. Digitar "payment_intent" na busca
4. Marcar: ✅ **payment_intent.succeeded**
5. Marcar: ✅ **payment_intent.payment_failed**

6. Digitar "charge" na busca
7. Marcar: ✅ **charge.succeeded**

#### Opção B - Selecionar Todos de Pagamento (Recomendado):

1. Clicar em **"Select all checkout events"**
2. Clicar em **"Select all payment_intent events"**
3. Clicar em **"Select all charge events"**

Clicar em **"Add events"**

---

### 2.5. Clicar em **"Add endpoint"**

---

## 📋 Passo 3: Copiar Signing Secret

Após criar o endpoint, você será redirecionado para a página do webhook.

### 3.1. Encontrar "Signing secret"

Na seção **"Signing secret"**, você verá:

```
Signing secret  •••••••••••••••••  [Reveal]
```

### 3.2. Clicar em **"Reveal"**

Você verá algo como:

```
whsec_abc123xyz789...
```

### 3.3. Clicar em **"Copy"** ou copiar manualmente

⚠️ **IMPORTANTE:** Guarde este secret! Você vai precisar no próximo passo.

---

## 📋 Passo 4: Salvar Secret no Banco de Dados

### 4.1. Abrir Supabase SQL Editor

1. Ir em: **https://supabase.com/dashboard**
2. Selecionar seu projeto
3. Clicar em **"SQL Editor"** (menu lateral)
4. Clicar em **"New query"**

### 4.2. Buscar ID do seu negócio

```sql
SELECT id, name FROM businesses LIMIT 1;
```

Copiar o `id` retornado (exemplo: `abc-123-xyz`)

### 4.3. Salvar o webhook secret

```sql
-- Substituir pelos seus valores:
-- 'SEU_BUSINESS_ID' = id copiado acima
-- 'SEU_WEBHOOK_SECRET' = whsec_... copiado do Stripe

UPDATE businesses
SET stripe_webhook_secret = 'whsec_abc123xyz789...'
WHERE id = 'abc-123-xyz';
```

### 4.4. Verificar se salvou

```sql
SELECT 
    id, 
    name, 
    CASE 
        WHEN stripe_webhook_secret IS NOT NULL 
        THEN '✅ Configurado' 
        ELSE '❌ Não configurado' 
    END as webhook_status
FROM businesses;
```

Deve mostrar: **✅ Configurado**

---

## 🎉 Pronto! Agora testar

### Teste Rápido:

1. **Criar agendamento** com pagamento online
2. **Copiar link** de pagamento
3. **Pagar** no Stripe (cartão teste: `4242 4242 4242 4242`)
4. **Ver logs** no terminal do Vite:
   ```
   🔔 [Webhook] Received request
   ✅ [Webhook] Updated appointment xyz to paid
   ```
5. **Recarregar agenda** → Status deve estar "Pago" ✅

---

## 📊 Monitorar Webhooks

### No Stripe Dashboard:

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar no seu webhook
3. Ver aba **"Events"**
4. Ver todos os eventos recebidos

### No ngrok:

1. Abrir: http://127.0.0.1:4040
2. Ver todas as requisições em tempo real

---

## ❓ Troubleshooting

### Webhook não recebe eventos:

- ✅ Verificar se ngrok está rodando
- ✅ Verificar se URL no Stripe está correta
- ✅ Verificar se tem `/api/stripe/webhook` no final
- ✅ Ver logs do ngrok em http://127.0.0.1:4040

### Erro "Invalid signature":

- ✅ Verificar se webhook secret está correto no banco
- ✅ Copiar secret novamente do Stripe
- ✅ Executar UPDATE no banco novamente

### Status não atualiza:

- ✅ Ver logs do Vite
- ✅ Verificar se appointment tem `payment_link`
- ✅ Recarregar página da agenda

---

## 🔄 Resumo dos Links

- **Stripe Webhooks:** https://dashboard.stripe.com/test/webhooks
- **Supabase SQL:** https://supabase.com/dashboard
- **ngrok Inspector:** http://127.0.0.1:4040
- **Seu App:** http://localhost:3000

---

## ✅ Checklist Final

- [ ] ngrok rodando
- [ ] URL do ngrok copiada
- [ ] Endpoint criado no Stripe
- [ ] Eventos selecionados
- [ ] Signing secret copiado
- [ ] Secret salvo no banco
- [ ] Teste de pagamento realizado
- [ ] Status atualizado automaticamente

Se todos os itens estiverem ✅, está funcionando perfeitamente! 🎉
