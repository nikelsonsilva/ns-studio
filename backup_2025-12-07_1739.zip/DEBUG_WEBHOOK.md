# 🔍 Debug do Webhook - Checklist

## ✅ Verificações Rápidas

### 1. ngrok está rodando?

Abrir **novo terminal** e executar:

```bash
ngrok http 3000
```

Você deve ver:
```
Forwarding    https://mekhi-cutaneous-nonnutritiously.ngrok-free.dev -> http://localhost:3000
```

**A URL está ativa?** Copie a URL.

---

### 2. Verificar URL no Stripe

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar no seu webhook
3. Verificar se a URL está:
   ```
   https://mekhi-cutaneous-nonnutritiously.ngrok-free.dev/api/stripe/webhook
   ```

**Se a URL for diferente, atualizar!**

---

### 3. Testar endpoint manualmente

No navegador, abrir:
```
http://localhost:3000/api/stripe/webhook
```

Deve dar erro (normal), mas mostra que o endpoint existe.

---

### 4. Ver eventos no Stripe

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar no seu webhook
3. Ver aba **"Events"**

**Tem eventos lá?** Se sim, qual o status?

---

### 5. Ver logs do ngrok

Abrir no navegador:
```
http://127.0.0.1:4040
```

**Tem requisições aparecendo?**

---

## 🔧 Soluções Rápidas

### Se ngrok não está rodando:

```bash
# Terminal novo
ngrok http 3000
```

### Se URL mudou:

1. Copiar nova URL do ngrok
2. Atualizar no Stripe Dashboard
3. Testar novamente

### Se eventos não aparecem no Stripe:

Verificar se selecionou os eventos:
- checkout.session.completed
- payment_intent.succeeded
- charge.succeeded

---

## 📊 Status Atual

- [ ] ngrok rodando
- [ ] URL correta no Stripe
- [ ] Eventos selecionados
- [ ] Signing secret salvo no banco
- [ ] Pagamento realizado
- [ ] Eventos aparecem no Stripe Dashboard
- [ ] Requisições aparecem no ngrok Inspector

Me mostre qual item está faltando!
