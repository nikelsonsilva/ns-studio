# 🚀 Próximos Passos - Configuração do Webhook

## ✅ Status Atual

- [x] Vite rodando em `http://localhost:3000`
- [x] Webhook integrado em `/api/stripe/webhook`
- [x] ngrok instalado

---

## 📋 Passo 1: Executar Migration SQL

### Abrir Supabase SQL Editor:

1. Ir em: https://supabase.com/dashboard
2. Selecionar seu projeto
3. Clicar em "SQL Editor" (menu lateral)
4. Clicar em "New query"

### Executar este SQL:

```sql
-- Adicionar coluna para webhook secret
ALTER TABLE businesses
ADD COLUMN IF NOT EXISTS stripe_webhook_secret TEXT;

-- Verificar se foi criada
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'businesses' 
AND column_name = 'stripe_webhook_secret';
```

### Resultado esperado:
```
column_name              | data_type
-------------------------+-----------
stripe_webhook_secret    | text
```

✅ **Concluído!** Agora a tabela está pronta.

---

## 📋 Passo 2: Expor Webhook com ngrok

### Em um NOVO terminal (deixe o `npm run dev` rodando):

```bash
ngrok http 3000
```

### Você verá algo assim:

```
ngrok

Session Status                online
Account                       seu_email@gmail.com
Version                       3.x.x
Region                        United States (us)
Latency                       -
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://abc123-xyz.ngrok-free.app -> http://localhost:3000

Connections                   ttl     opn     rt1     rt5     p50     p90
                              0       0       0.00    0.00    0.00    0.00
```

### ⚠️ IMPORTANTE: Copie a URL do "Forwarding"

Exemplo: `https://abc123-xyz.ngrok-free.app`

✅ **Anote esta URL!** Você vai usar no próximo passo.

---

## 📋 Passo 3: Configurar Webhook no Stripe

### 3.1. Abrir Stripe Dashboard:

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar em **"Add endpoint"**

### 3.2. Configurar Endpoint:

**Endpoint URL:**
```
https://abc123-xyz.ngrok-free.app/api/stripe/webhook
```
*(Substitua pela sua URL do ngrok)*

**Description (opcional):**
```
NS Studio - Webhook de Pagamentos
```

**Events to send:**

Clicar em **"Select events"** e escolher:

- ✅ `checkout.session.completed`
- ✅ `payment_intent.succeeded`
- ✅ `payment_intent.payment_failed`
- ✅ `charge.succeeded`

Ou usar o filtro: digitar "checkout" e selecionar todos relacionados a pagamento.

### 3.3. Clicar em "Add endpoint"

✅ **Endpoint criado!**

---

## 📋 Passo 4: Copiar Signing Secret

### Após criar o endpoint:

1. Você será redirecionado para a página do webhook
2. Na seção **"Signing secret"**, clicar em **"Reveal"**
3. Copiar o secret (começa com `whsec_...`)

Exemplo:
```
whsec_abc123xyz789...
```

✅ **Anote este secret!** Você vai salvar no banco.

---

## 📋 Passo 5: Salvar Secret no Banco

### Voltar ao Supabase SQL Editor:

```sql
-- Buscar ID do seu negócio
SELECT id, name FROM businesses LIMIT 1;
```

Anote o `id` retornado.

### Salvar o webhook secret:

```sql
-- Substituir 'SEU_BUSINESS_ID' e 'SEU_WEBHOOK_SECRET'
UPDATE businesses
SET stripe_webhook_secret = 'whsec_abc123xyz789...'
WHERE id = 'SEU_BUSINESS_ID';

-- Verificar se salvou
SELECT id, name, 
       CASE 
         WHEN stripe_webhook_secret IS NOT NULL 
         THEN '✅ Configurado' 
         ELSE '❌ Não configurado' 
       END as webhook_status
FROM businesses;
```

### Resultado esperado:
```
id                  | name      | webhook_status
--------------------+-----------+----------------
abc-123-xyz         | NS Studio | ✅ Configurado
```

✅ **Secret salvo no banco!**

---

## 📋 Passo 6: Testar Webhook

### 6.1. Criar Agendamento de Teste:

1. Abrir app: `http://localhost:3000`
2. Ir na **Agenda**
3. Criar novo agendamento
4. Selecionar **"Pagamento Online"**
5. Copiar link de pagamento

### 6.2. Pagar no Stripe:

1. Abrir link de pagamento
2. Usar cartão de teste:
   - Número: `4242 4242 4242 4242`
   - Data: `12/34` (qualquer futura)
   - CVC: `123`
   - Nome: Qualquer
3. Clicar em "Pay"

### 6.3. Verificar Logs:

No terminal onde está rodando `npm run dev`, você deve ver:

```
🔔 [Webhook] Received request
🔔 [Webhook] Event: checkout.session.completed
✅ [Webhook] Checkout completed: cs_test_abc123
✅ [Webhook] Updated appointment xyz789 to paid
```

### 6.4. Verificar na Agenda:

1. Recarregar página da agenda
2. Status do agendamento deve estar **"Pago"** ✅

---

## 🎉 Pronto!

Se você viu os logs e o status mudou para "Pago", está tudo funcionando!

### Resumo do que foi feito:

- ✅ Migration SQL executada
- ✅ ngrok expondo porta 3000
- ✅ Webhook configurado no Stripe
- ✅ Signing secret salvo no banco
- ✅ Teste de pagamento realizado
- ✅ Status atualizado automaticamente

---

## 🔄 Para Usar Novamente

Sempre que reiniciar o computador:

1. **Iniciar Vite:**
   ```bash
   npm run dev
   ```

2. **Iniciar ngrok (novo terminal):**
   ```bash
   ngrok http 3000
   ```

3. **Atualizar URL no Stripe:**
   - Copiar nova URL do ngrok
   - Atualizar endpoint no Stripe Dashboard

---

## 📞 Precisa de Ajuda?

Se algo não funcionar:

1. Verificar logs do Vite
2. Verificar logs do ngrok: `http://127.0.0.1:4040`
3. Verificar eventos no Stripe Dashboard
4. Verificar se webhook secret está correto no banco
