# 🧪 Como Testar o Webhook Agora

Guia rápido para testar se o webhook está funcionando.

---

## ✅ Pré-requisitos

- [x] Vite rodando (`npm run dev`)
- [x] ngrok rodando (`ngrok http 3000`)
- [x] Webhook configurado no Stripe
- [x] Signing secret salvo no banco

---

## 🎯 Passo a Passo do Teste

### 1. Criar Agendamento com Pagamento Online

1. Abrir app: `http://localhost:3000`
2. Fazer login
3. Ir na **Agenda**
4. Clicar em um horário vazio
5. Preencher dados do agendamento:
   - Cliente
   - Serviço
   - **Método de pagamento: Online** ⚠️ IMPORTANTE
6. Salvar

### 2. Copiar Link de Pagamento

Após criar o agendamento:

1. Clicar no agendamento criado
2. Copiar o link de pagamento que aparece
3. Ou ir em **Financeiro** e ver o link lá

### 3. Abrir Link e Pagar

1. Colar o link no navegador
2. Você será redirecionado para o Stripe
3. Preencher dados do cartão de teste:
   - **Número:** `4242 4242 4242 4242`
   - **Data:** `12/34` (qualquer data futura)
   - **CVC:** `123`
   - **Nome:** Qualquer nome
4. Clicar em **"Pay"** ou **"Pagar"**

### 4. Verificar Logs do Webhook

**No terminal onde está rodando `npm run dev`, você deve ver:**

```
🔔 [Webhook] Received request
🔔 [Webhook] Event: checkout.session.completed
✅ [Webhook] Checkout completed: cs_test_abc123
✅ [Webhook] Updated appointment xyz789 to paid
```

Se ver isso, **FUNCIONOU!** ✅

### 5. Verificar na Agenda

1. Voltar para o app
2. Recarregar a página da agenda (F5)
3. O agendamento deve estar com status **"Pago"** ✅
4. Badge verde ou indicador de pagamento confirmado

---

## 🔍 Ver Detalhes do Webhook

### No ngrok Inspector:

1. Abrir: `http://127.0.0.1:4040`
2. Ver todas as requisições recebidas
3. Clicar em uma requisição
4. Ver:
   - Headers
   - Body
   - Response

### No Stripe Dashboard:

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar no seu webhook
3. Ver aba **"Events"**
4. Ver todos os eventos enviados
5. Status de cada evento (succeeded/failed)

---

## ❌ Troubleshooting

### Não vejo logs do webhook:

**Possíveis causas:**

1. **ngrok não está rodando**
   - Verificar se terminal do ngrok está aberto
   - Ver se mostra "Session Status: online"

2. **URL errada no Stripe**
   - Verificar URL no Stripe Dashboard
   - Deve ser: `https://sua-url-ngrok.app/api/stripe/webhook`
   - Não esquecer `/api/stripe/webhook` no final

3. **Eventos não selecionados**
   - Verificar eventos no webhook do Stripe
   - Deve ter: `checkout.session.completed`

### Vejo erro "Invalid signature":

**Solução:**

1. Copiar signing secret novamente do Stripe
2. Executar SQL no Supabase:
   ```sql
   UPDATE businesses
   SET stripe_webhook_secret = 'whsec_NOVO_SECRET'
   WHERE id = 'seu_business_id';
   ```
3. Reiniciar Vite (Ctrl+C e `npm run dev`)

### Status não atualiza na agenda:

**Soluções:**

1. **Recarregar página** (F5)
2. Verificar se agendamento tem `payment_link` no banco
3. Ver logs do Vite para erros
4. Verificar se webhook secret está correto

---

## ✅ Teste Completo - Checklist

- [ ] Agendamento criado com pagamento online
- [ ] Link de pagamento copiado
- [ ] Pagamento realizado no Stripe
- [ ] Logs apareceram no terminal do Vite
- [ ] Status mudou para "Pago" na agenda
- [ ] Evento aparece no Stripe Dashboard
- [ ] Requisição aparece no ngrok Inspector

Se todos os itens estão ✅, **está funcionando perfeitamente!** 🎉

---

## 🎥 Fluxo Visual

```
1. Criar Agendamento
   ↓
2. Selecionar "Pagamento Online"
   ↓
3. Copiar Link
   ↓
4. Pagar no Stripe (4242...)
   ↓
5. Stripe envia webhook
   ↓
6. ngrok recebe
   ↓
7. Vite processa
   ↓
8. Banco atualiza
   ↓
9. Agenda mostra "Pago" ✅
```

---

## 📊 Monitoramento em Tempo Real

### Terminal 1 - Vite:
```
npm run dev
```
Ver logs do webhook aqui.

### Terminal 2 - ngrok:
```
ngrok http 3000
```
Manter aberto.

### Navegador 1 - ngrok Inspector:
```
http://127.0.0.1:4040
```
Ver requisições em tempo real.

### Navegador 2 - Stripe Dashboard:
```
https://dashboard.stripe.com/test/webhooks
```
Ver eventos enviados.

### Navegador 3 - App:
```
http://localhost:3000
```
Usar o app normalmente.

---

## 🚀 Próximo Passo

Depois de testar e confirmar que funciona:

1. Deixar tudo configurado
2. Quando subir para produção, seguir: [DEPLOY_PRODUCAO.md](file:///c:/Users/nikel/Desktop/APP%20ns-studio/DEPLOY_PRODUCAO.md)
3. Trocar URL do ngrok pela URL do domínio
4. Trocar chaves de teste por chaves LIVE
5. Pronto! 🎉
