# ⚡ Guia Rápido - Webhook do Stripe

## ✅ Passo 1: Configurar .env

Adicione estas linhas ao arquivo `.env`:

```env
# Stripe Webhook Secret (obter do dashboard)
STRIPE_WEBHOOK_SECRET=whsec_seu_secret_aqui

# Porta do webhook (opcional)
WEBHOOK_PORT=3001
```

## ✅ Passo 2: Testar Localmente

```bash
npm run webhook
```

Você deve ver:
```
🚀 ============================================
   Stripe Webhook Server
============================================
📍 Running on: http://localhost:3001
🔗 Webhook URL: http://localhost:3001/api/stripe/webhook
🔐 Webhook secret: ✅ Configured
💾 Supabase: ✅ Connected
💳 Stripe: ✅ Connected
============================================
```

## ✅ Passo 3: Expor com ngrok

```bash
# Instalar ngrok
npm install -g ngrok

# Expor porta 3001
ngrok http 3001
```

Copie a URL do ngrok (ex: `https://abc123.ngrok.io`)

## ✅ Passo 4: Configurar no Stripe

1. Ir em: https://dashboard.stripe.com/test/webhooks
2. Clicar em "Add endpoint"
3. URL: `https://abc123.ngrok.io/api/stripe/webhook`
4. Eventos:
   - `checkout.session.completed`
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `charge.succeeded`
5. Copiar "Signing secret" (começa com `whsec_...`)
6. Adicionar ao `.env`:
   ```env
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```
7. Reiniciar webhook: `npm run webhook`

## ✅ Passo 5: Testar

1. Criar agendamento com pagamento online
2. Pagar no Stripe
3. Ver logs do webhook
4. Verificar status na agenda

---

## 🔧 Troubleshooting

### Erro: "Supabase credentials not configured"
- Verificar se `.env` tem `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`

### Erro: "Stripe secret key not configured"
- Verificar se `.env` tem `VITE_STRIPE_SECRET_KEY`

### Webhook não recebe eventos
- Verificar se ngrok está rodando
- Verificar URL no Stripe Dashboard
- Ver logs do ngrok: `ngrok http 3001 --log=stdout`
