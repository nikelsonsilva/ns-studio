
import React, { useState, useEffect } from 'react';
import { X, Sparkles, AlertTriangle, Coffee, MessageCircle, Calendar, DollarSign, StickyNote, History, Award, Plus, Trash2, Bell, Check, Clock, Camera, Image as ImageIcon, Crown, LayoutGrid, Loader2 } from 'lucide-react';
import { Client, ClientPhoto, LoyaltyTier } from '../types';
import {
  fetchClientWithHistory,
  updateClientNotes,
  updateClientTags,
  updateClientPreferences,
  getDaysSinceLastVisit,
  type AppointmentHistory,
  type ClientStats
} from '../lib/clientService';

interface ClientDetailsModalProps {
  client: Client;
  onClose: () => void;
  onEdit?: () => void;
}

const ClientDetailsModal: React.FC<ClientDetailsModalProps> = ({ client, onClose, onEdit }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'gallery'>('overview');
  const [generatedMessage, setGeneratedMessage] = useState<string | null>(null);

  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  const [historyData, setHistoryData] = useState<AppointmentHistory[]>([]);
  const [clientStats, setClientStats] = useState<ClientStats>({
    totalVisits: client.total_visits || 0,
    lifetimeValue: client.lifetime_value || 0,
    averageTicket: 0,
    lastVisitDate: client.last_visit_date || null
  });

  // CRM Enhancements State
  const [tags, setTags] = useState<string[]>(client.tags || []);
  const [newTag, setNewTag] = useState('');
  const [isAddingTag, setIsAddingTag] = useState(false);

  const [notes, setNotes] = useState(client.internal_notes || '');
  const [isSavingNotes, setIsSavingNotes] = useState(false);

  const [reminderDays, setReminderDays] = useState(30);
  const [reminderActive, setReminderActive] = useState(false);

  // Load client data with history
  useEffect(() => {
    const loadClientData = async () => {
      setIsLoading(true);
      const data = await fetchClientWithHistory(client.id);

      if (data) {
        setHistoryData(data.history);
        setClientStats(data.stats);
      }

      setIsLoading(false);
    };

    loadClientData();
  }, [client.id]);

  // Mock points logic if not provided
  const points = client.loyalty_points || (clientStats.totalVisits % 10);
  const maxPoints = 10;

  // Calculate Tier based on total visits (Mock logic)
  const calculateTier = (visits: number): LoyaltyTier => {
    if (visits > 30) return 'Diamante';
    if (visits > 15) return 'Ouro';
    if (visits > 5) return 'Prata';
    return 'Bronze';
  };

  const tier = client.loyalty_tier || calculateTier(clientStats.totalVisits);

  const getTierStyles = (t: LoyaltyTier) => {
    switch (t) {
      case 'Diamante': return { bg: 'bg-cyan-500/10', border: 'border-cyan-500', text: 'text-cyan-400', icon: Crown };
      case 'Ouro': return { bg: 'bg-yellow-500/10', border: 'border-yellow-500', text: 'text-yellow-500', icon: Award };
      case 'Prata': return { bg: 'bg-gray-300/10', border: 'border-gray-400', text: 'text-gray-300', icon: Award };
      default: return { bg: 'bg-orange-700/10', border: 'border-orange-800', text: 'text-orange-700', icon: Award };
    }
  };

  const tierStyle = getTierStyles(tier);
  const TierIcon = tierStyle.icon;

  // Days since last visit
  const daysSinceLastVisit = getDaysSinceLastVisit(clientStats.lastVisitDate);

  // Mock Photos
  const initialPhotos: ClientPhoto[] = client.photos || [
    { id: '1', url: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&q=80&w=400', date: '20 Out, 2023', type: 'after', notes: 'Degradê Navalhado' },
    { id: '2', url: 'https://images.unsplash.com/photo-1593702295094-aea8c5c13d73?auto=format&fit=crop&q=80&w=400', date: '20 Out, 2023', type: 'before' },
    { id: '3', url: 'https://images.unsplash.com/photo-1503951914875-befbb713d052?auto=format&fit=crop&q=80&w=400', date: '25 Set, 2023', type: 'after', notes: 'Low Fade' },
  ];
  const [photos, setPhotos] = useState<ClientPhoto[]>(initialPhotos);

  const handleGenerateMessage = () => {
    // Simulação de IA
    const msg = `Fala ${client.name.split(' ')[0]}! 👊\n\nJá faz 30 dias desde seu último corte navalhado. Como você curte manter o visual em dia, que tal agendar para essa semana?\n\nTenho horário livre na quinta às 17h. Bora?`;
    setGeneratedMessage(msg);
  };

  const handleAddTag = async () => {
    if (newTag.trim()) {
      const updatedTags = [...tags, newTag.trim()];
      setTags(updatedTags);
      setNewTag('');
      setIsAddingTag(false);

      // Save to database
      await updateClientTags(client.id, updatedTags);
    }
  };

  const removeTag = async (tagToRemove: string) => {
    const updatedTags = tags.filter(tag => tag !== tagToRemove);
    setTags(updatedTags);

    // Save to database
    await updateClientTags(client.id, updatedTags);
  };

  const handleSaveNotes = async () => {
    setIsSavingNotes(true);
    const success = await updateClientNotes(client.id, notes);

    if (success) {
      setTimeout(() => setIsSavingNotes(false), 1000);
    } else {
      setIsSavingNotes(false);
      alert('Erro ao salvar notas');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-barber-900 w-full md:max-w-5xl md:rounded-2xl border-none md:border border-barber-800 shadow-2xl flex flex-col h-full md:max-h-[90vh] overflow-hidden">

        {/* Header */}
        <div className="p-4 border-b border-barber-800 flex flex-col justify-between items-start bg-barber-950 shrink-0 gap-4">
          <div className="flex justify-between w-full">
            <div className="flex gap-4">
              <div className={`w-14 h-14 md:w-20 md:h-20 rounded-full flex items-center justify-center text-2xl md:text-3xl font-bold border-2 shrink-0 relative ${tierStyle.border} ${tierStyle.text} bg-barber-900`}>
                {client.name.charAt(0)}
                <div className="absolute -bottom-2 bg-barber-950 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider border border-barber-800 flex items-center gap-1">
                  <TierIcon size={10} /> {tier}
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-white flex flex-wrap items-center gap-2">
                  {client.name}
                  {tags && tags.includes('VIP') && <span className="bg-barber-gold text-black text-xs px-2 py-0.5 rounded font-bold">VIP</span>}
                  {client.activeMembership && (
                    <span className="bg-purple-500/20 text-purple-400 border border-purple-500/50 text-xs px-2 py-0.5 rounded font-bold flex items-center gap-1">
                      <Crown size={10} /> {client.activeMembership}
                    </span>
                  )}
                </h2>
                <p className="text-gray-400 text-sm">{client.phone}</p>

                {/* Tag Management */}
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  {tags && tags.map(tag => (
                    <span key={tag} className="text-[10px] bg-barber-800 text-gray-300 px-2 py-0.5 rounded-full border border-barber-700 flex items-center gap-1 group">
                      {tag}
                      <button onClick={() => removeTag(tag)} className="hover:text-red-400">
                        <X size={10} />
                      </button>
                    </span>
                  ))}

                  {isAddingTag ? (
                    <div className="flex items-center gap-1 bg-barber-950 border border-barber-700 rounded-full px-2 py-0.5">
                      <input
                        type="text"
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        className="bg-transparent text-xs text-white w-16 outline-none"
                        placeholder="Tag..."
                        autoFocus
                        onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                      />
                      <button onClick={handleAddTag} className="text-green-500 hover:text-green-400"><Check size={12} /></button>
                      <button onClick={() => setIsAddingTag(false)} className="text-red-500 hover:text-red-400"><X size={12} /></button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsAddingTag(true)}
                      className="text-[10px] bg-barber-800 hover:bg-barber-700 text-gray-400 hover:text-white px-2 py-0.5 rounded-full border border-barber-700 border-dashed flex items-center gap-1 transition-colors"
                    >
                      <Plus size={8} /> Add
                    </button>
                  )}
                </div>
              </div>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-white p-2 hover:bg-barber-800 rounded-lg transition-colors md:hidden">
              <X size={24} />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full justify-end border-t border-barber-800 pt-3 md:border-t-0 md:pt-0">
            <div className="flex bg-barber-900 rounded-lg p-1 border border-barber-800 w-full sm:w-auto">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'overview' ? 'bg-barber-800 text-white shadow' : 'text-gray-400 hover:text-white'}`}
              >
                <LayoutGrid size={14} /> Visão Geral
              </button>
              <button
                onClick={() => setActiveTab('gallery')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'gallery' ? 'bg-barber-800 text-white shadow' : 'text-gray-400 hover:text-white'}`}
              >
                <ImageIcon size={14} /> Galeria
              </button>
            </div>
            <button onClick={onClose} className="hidden md:block text-gray-500 hover:text-white p-2 hover:bg-barber-800 rounded-lg transition-colors">
              <X size={24} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-barber-900/50">

          {activeTab === 'overview' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
              {/* Coluna Esquerda: Dados Críticos */}
              <div className="space-y-6">

                {/* Loyalty Card */}
                <div className={`p-5 rounded-xl border relative overflow-hidden shadow-lg ${tierStyle.bg} ${tierStyle.border}`}>
                  <div className="absolute top-0 right-0 p-10 bg-white/5 blur-2xl rounded-full"></div>
                  <div className="flex justify-between items-start mb-4 relative z-10">
                    <h3 className={`${tierStyle.text} font-bold text-sm flex items-center gap-2`}>
                      <TierIcon size={16} /> Fidelidade {tier}
                    </h3>
                    <span className="text-xs bg-black/20 px-2 py-1 rounded text-white font-mono">
                      {clientStats.totalVisits} visitas totais
                    </span>
                  </div>

                  <div className="grid grid-cols-5 gap-2 mb-3 relative z-10">
                    {Array.from({ length: maxPoints }).map((_, i) => (
                      <div
                        key={i}
                        className={`aspect-square rounded-full flex items-center justify-center border text-xs font-bold transition-all ${i < points
                          ? `bg-white text-black border-white shadow`
                          : 'bg-black/20 border-white/10 text-white/30'
                          }`}
                      >
                        {i < points ? '✓' : i + 1}
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-300 text-center relative z-10">
                    Faltam <span className="text-white font-bold">{maxPoints - points}</span> cortes para resgatar prêmio!
                  </p>
                </div>

                {/* LTV Card */}
                <div className="bg-barber-950 p-4 rounded-xl border border-barber-800">
                  <div className="flex items-center gap-2 text-gray-400 text-xs uppercase font-bold mb-2">
                    <DollarSign size={14} className="text-green-500" /> Lifetime Value (LTV)
                  </div>
                  <div className="text-2xl font-bold text-white">R$ {clientStats.lifetimeValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  <div className="text-xs text-gray-500 mt-1">Ticket Médio: R$ {clientStats.averageTicket.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>

                {/* Preferências */}
                <div className="bg-barber-950 p-4 rounded-xl border border-barber-800">
                  <h3 className="text-barber-gold font-bold text-sm mb-3 flex items-center gap-2">
                    <Coffee size={16} /> Preferências
                  </h3>
                  <ul className="space-y-3 text-sm">
                    <li className="flex justify-between border-b border-barber-800 pb-2">
                      <span className="text-gray-500">Bebida</span>
                      <span className="text-white text-right">{client.drinkPreference || 'Café'}</span>
                    </li>
                    <li className="flex justify-between border-b border-barber-800 pb-2">
                      <span className="text-gray-500">Estilo</span>
                      <span className="text-white text-right">{client.conversationStyle || 'Normal'}</span>
                    </li>
                    <li className="block pt-1">
                      <span className="text-gray-500 block mb-1">Corte Favorito</span>
                      <span className="text-white bg-barber-800 px-2 py-1 rounded text-xs">{typeof client.preferences === 'string' ? client.preferences : 'Não especificado'}</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Coluna Central: Histórico e Notas */}
              <div className="lg:col-span-2 space-y-6">

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Follow-up / Reminder Automation - NEW */}
                  <div className="bg-barber-950 p-5 rounded-xl border border-barber-800 flex flex-col justify-between">
                    <div>
                      <h3 className="text-white font-bold text-sm mb-3 flex items-center gap-2">
                        <Bell size={16} className="text-barber-gold" /> Lembrete Automático
                      </h3>
                      <p className="text-xs text-gray-400 mb-4">
                        Notificar quando for hora de retornar.
                      </p>
                    </div>

                    <div className="flex items-center justify-between bg-barber-900 p-3 rounded-lg border border-barber-800">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setReminderActive(!reminderActive)}
                          className={`w-10 h-6 rounded-full p-1 transition-colors ${reminderActive ? 'bg-green-500' : 'bg-barber-800'}`}
                        >
                          <div className={`w-4 h-4 bg-white rounded-full transition-transform ${reminderActive ? 'translate-x-4' : 'translate-x-0'}`}></div>
                        </button>
                        <span className={`text-sm font-bold ${reminderActive ? 'text-white' : 'text-gray-500'}`}>
                          {reminderActive ? 'On' : 'Off'}
                        </span>
                      </div>

                      {reminderActive && (
                        <div className="flex items-center gap-2 text-sm">
                          <select
                            value={reminderDays}
                            onChange={(e) => setReminderDays(Number(e.target.value))}
                            className="bg-barber-950 border border-barber-700 rounded text-white px-2 py-1 outline-none text-xs"
                          >
                            <option value={15}>15d</option>
                            <option value={30}>30d</option>
                            <option value={45}>45d</option>
                          </select>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Notas Internas - Enhanced */}
                  <div className="bg-barber-950 p-5 rounded-xl border border-barber-800 flex flex-col">
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-white font-bold text-sm flex items-center gap-2">
                        <StickyNote size={16} className="text-yellow-500" /> Notas
                      </h3>
                      {isSavingNotes ? (
                        <span className="text-green-500 text-xs flex items-center gap-1 animate-fade-in">
                          <Check size={12} /> Salvo
                        </span>
                      ) : (
                        <button
                          onClick={handleSaveNotes}
                          className="text-xs text-barber-gold hover:text-white transition-colors"
                        >
                          Salvar
                        </button>
                      )}
                    </div>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-barber-900 border border-barber-800 rounded-lg p-3 text-sm text-gray-300 focus:border-barber-gold outline-none resize-none flex-1 min-h-[100px]"
                      placeholder="Observações do cliente..."
                    />
                  </div>
                </div>

                {/* IA Actions / Follow-up Template */}
                <div className="bg-gradient-to-r from-barber-900 to-barber-800 p-1 rounded-xl border border-barber-700/50 relative overflow-hidden">
                  <div className="bg-barber-950/80 p-5 rounded-lg backdrop-blur-sm">
                    <h3 className="text-white font-bold flex items-center gap-2 mb-2">
                      <Sparkles size={18} className="text-purple-400" /> Assistant
                    </h3>

                    {!generatedMessage ? (
                      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="text-sm text-gray-400">Cliente inativo há {daysSinceLastVisit} dias.</p>
                        <button
                          onClick={handleGenerateMessage}
                          className="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-900/20 whitespace-nowrap"
                        >
                          <Sparkles size={14} /> Gerar Mensagem
                        </button>
                      </div>
                    ) : (
                      <div className="animate-fade-in">
                        <textarea
                          className="w-full bg-barber-900 border border-barber-700 rounded-lg p-3 text-sm text-gray-200 focus:border-purple-500 outline-none resize-none h-24 mb-2"
                          value={generatedMessage}
                          readOnly
                        />
                        <div className="flex flex-col md:flex-row gap-2">
                          <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2">
                            <MessageCircle size={16} /> Enviar
                          </button>
                          <button onClick={() => setGeneratedMessage(null)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">
                            Cancelar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Histórico - Enhanced */}
                <div className="bg-barber-950 p-5 rounded-xl border border-barber-800">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-white font-bold text-sm flex items-center gap-2">
                      <History size={16} className="text-blue-400" /> Histórico
                    </h3>
                    <span className="text-xs text-gray-500 bg-barber-900 px-2 py-1 rounded-full border border-barber-800">
                      {clientStats.totalVisits} visitas
                    </span>
                  </div>

                  {/* Resumo de Pagamentos */}
                  {!isLoading && historyData.length > 0 && (
                    <div className="grid grid-cols-3 gap-3 mb-4 p-3 bg-barber-900 rounded-lg border border-barber-800">
                      <div className="text-center">
                        <div className="text-green-400 text-xl font-bold">
                          {historyData.filter(h => h.payment_status === 'paid').length}
                        </div>
                        <div className="text-[10px] text-gray-500 uppercase">Pagos</div>
                      </div>
                      <div className="text-center">
                        <div className="text-yellow-400 text-xl font-bold">
                          {historyData.filter(h => h.payment_status === 'awaiting_payment' || h.payment_status === 'pending').length}
                        </div>
                        <div className="text-[10px] text-gray-500 uppercase">Pendentes</div>
                      </div>
                      <div className="text-center">
                        <div className="text-red-400 text-xl font-bold">
                          {historyData.filter(h => h.payment_status === 'failed').length}
                        </div>
                        <div className="text-[10px] text-gray-500 uppercase">Falharam</div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-4">
                    {isLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="animate-spin text-barber-gold" size={24} />
                      </div>
                    ) : historyData.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <History size={32} className="mx-auto mb-2 opacity-20" />
                        <p>Nenhum agendamento encontrado</p>
                      </div>
                    ) : (
                      historyData.map((item, i) => (
                        <div key={item.id || i} className="flex items-center justify-between pb-4 border-b border-barber-800 last:border-0 last:pb-0 hover:bg-barber-900/50 p-2 rounded-lg transition-colors -mx-2 px-2">
                          <div className="flex items-center gap-3">
                            <div className="bg-barber-900 p-2 rounded-lg text-gray-400 border border-barber-800">
                              <Calendar size={18} />
                            </div>
                            <div>
                              <div className="text-white text-sm font-bold">{item.service_name}</div>
                              <div className="text-gray-500 text-xs flex items-center gap-1">
                                <Clock size={10} /> {item.date} • {item.professional_name.split(' ')[0]}
                              </div>
                              {/* Método de pagamento */}
                              {item.payment_method && (
                                <div className="text-xs text-gray-600 mt-1 flex items-center gap-1">
                                  {item.payment_method === 'presential' ? '💵 Presencial' :
                                    item.payment_method === 'online' ? '💳 Online' :
                                      `💳 ${item.payment_method}`}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`font-bold text-sm ${item.payment_status === 'paid' ? 'text-green-500' :
                              item.payment_status === 'awaiting_payment' ? 'text-yellow-500' :
                                item.payment_status === 'pending' ? 'text-yellow-500' :
                                  item.payment_status === 'failed' ? 'text-red-500' :
                                    'text-gray-500'
                              }`}>
                              R$ {item.amount.toFixed(2)}
                            </div>

                            {/* Badge de status */}
                            <div className={`text-[10px] uppercase font-bold mt-1 px-2 py-0.5 rounded inline-block ${item.payment_status === 'paid' ? 'bg-green-500/20 text-green-400' :
                              item.payment_status === 'awaiting_payment' ? 'bg-yellow-500/20 text-yellow-400' :
                                item.payment_status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                                  item.payment_status === 'failed' ? 'bg-red-500/20 text-red-400' :
                                    'bg-gray-500/20 text-gray-400'
                              }`}>
                              {item.payment_status === 'paid' ? '✓ Pago' :
                                item.payment_status === 'awaiting_payment' ? '⏳ Aguardando' :
                                  item.payment_status === 'pending' ? '⏳ Pendente' :
                                    item.payment_status === 'failed' ? '✗ Falhou' :
                                      item.payment_status}
                            </div>

                            {/* Link para pagamento (se aguardando) */}
                            {(item.payment_status === 'awaiting_payment' || item.payment_status === 'pending') && item.payment_link && (
                              <a
                                href={item.payment_link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[10px] text-blue-400 hover:text-blue-300 mt-1 block underline"
                              >
                                Pagar Agora →
                              </a>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>
            </div>
          ) : (
            /* GALLERY VIEW */
            <div className="animate-fade-in h-full flex flex-col">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-xl font-bold text-white">Galeria</h3>
                  <p className="text-gray-400 text-sm">Histórico visual.</p>
                </div>
                <button className="bg-barber-gold hover:bg-barber-goldhover text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-colors text-sm">
                  <Camera size={18} /> Add
                </button>
              </div>

              {photos.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-gray-500 border-2 border-dashed border-barber-800 rounded-xl bg-barber-950/30">
                  <ImageIcon size={48} className="mb-4 opacity-50" />
                  <p>Sem fotos.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 overflow-y-auto pb-4">
                  {photos.map(photo => (
                    <div key={photo.id} className="group relative rounded-xl overflow-hidden bg-barber-950 border border-barber-800 shadow-lg aspect-square">
                      <img src={photo.url} alt="Corte" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3">
                        <div className="flex justify-between items-end">
                          <div>
                            <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded mb-1 inline-block ${photo.type === 'after' ? 'bg-green-500 text-black' : 'bg-gray-600 text-white'}`}>
                              {photo.type === 'before' ? 'Antes' : 'Depois'}
                            </span>
                            <div className="text-xs text-gray-300">{photo.date}</div>
                          </div>
                          <button className="text-white hover:text-red-500 p-2"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ClientDetailsModal;
