
import React, { useState, useMemo } from 'react';
import { Search, Filter, Phone, Calendar, Tag, MoreHorizontal, Eye, Plus, X, Check, Hash, Megaphone, Send, Clock, UserCheck } from 'lucide-react';
import { Client } from '../types';
import ClientDetailsModal from './ClientDetailsModal';
import ClientModal from './ClientModal';

import { useSupabaseQuery } from '../lib/hooks';
import { fetchClients, deleteClient } from '../lib/database';

const Clients: React.FC = () => {
  const { data: clientsData } = useSupabaseQuery(fetchClients);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [selectedTagFilter, setSelectedTagFilter] = useState<string>('Todos');
  const [sendingCampaign, setSendingCampaign] = useState<string | null>(null);

  // State for inline tag editing
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [newTagInput, setNewTagInput] = useState('');

  const [clients, setClients] = useState<Client[]>([]);

  React.useEffect(() => {
    if (clientsData) {
      setClients(clientsData);
    }
  }, [clientsData]);

  // Client Modal State
  const [showClientModal, setShowClientModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);

  // Derive unique tags for filter
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    clients.forEach(c => {
      // ✅ FIX: Check if tags exists and is an array
      if (c.tags && Array.isArray(c.tags)) {
        c.tags.forEach(t => tags.add(t));
      }
    });
    return ['Todos', ...Array.from(tags)];
  }, [clients]);

  // Filtering Logic
  const filteredClients = clients.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.phone.includes(searchTerm);
    // ✅ FIX: Check if tags exists before accessing
    const matchesTag = selectedTagFilter === 'Todos' || (c.tags && Array.isArray(c.tags) && c.tags.includes(selectedTagFilter));
    return matchesSearch && matchesTag;
  });

  // Tag Handlers
  const handleAddTag = (clientId: string) => {
    if (!newTagInput.trim()) {
      setEditingClientId(null);
      return;
    }
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const currentTags = c.tags || [];
        if (!currentTags.includes(newTagInput.trim())) {
          return { ...c, tags: [...currentTags, newTagInput.trim()] };
        }
      }
      return c;
    }));
    setNewTagInput('');
    setEditingClientId(null);
  };

  const handleRemoveTag = (clientId: string, tagToRemove: string) => {
    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const currentTags = c.tags || [];
        return { ...c, tags: currentTags.filter(t => t !== tagToRemove) };
      }
      return c;
    }));
  };

  const handleCampaign = (campaignName: string) => {
    setSendingCampaign(campaignName);
    setTimeout(() => {
      setSendingCampaign(null);
      alert(`Campanha "${campaignName}" enviada para o segmento selecionado!`);
    }, 2000);
  };

  const handleCreateClient = () => {
    setEditingClient(null);
    setShowClientModal(true);
  };

  const handleEditClient = (client: Client) => {
    setEditingClient(client);
    setShowClientModal(true);
  };

  const handleDeleteClient = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
      await deleteClient(id);
      setClients(prev => prev.filter(c => c.id !== id));
    }
  };

  const handleClientSuccess = () => {
    // Refetch clients after create/update
    window.location.reload(); // Simple refresh for now
  };

  return (
    <div className="space-y-6 animate-fade-in pb-20">

      {/* Smart Campaigns Bar - DISABLED */}
      <div className="bg-gradient-to-r from-barber-900 to-barber-950 p-4 rounded-xl border border-barber-800 shadow-lg relative overflow-hidden opacity-60">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="bg-gray-600 p-2 rounded-lg text-gray-400 shrink-0">
              <Megaphone size={20} />
            </div>
            <div>
              <h3 className="text-gray-400 font-bold text-sm flex items-center gap-2">
                Marketing Inteligente
                <span className="text-[9px] bg-barber-800 text-gray-500 px-1.5 py-0.5 rounded uppercase">em breve</span>
              </h3>
              <p className="text-gray-600 text-xs">Envie campanhas via WhatsApp.</p>
            </div>
          </div>

          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-1 scrollbar-hide">
            <button
              disabled
              className="bg-barber-900 border border-barber-800 text-gray-600 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 whitespace-nowrap cursor-not-allowed flex-shrink-0"
            >
              <Clock size={14} />
              Recuperar Inativos
            </button>
            <button
              disabled
              className="bg-barber-900 border border-barber-800 text-gray-600 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 whitespace-nowrap cursor-not-allowed flex-shrink-0"
            >
              <Tag size={14} />
              Aniversariantes
            </button>
            <button
              disabled
              className="bg-barber-900 border border-barber-800 text-gray-600 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 whitespace-nowrap cursor-not-allowed flex-shrink-0"
            >
              <UserCheck size={14} />
              Oferta VIP
            </button>
          </div>
        </div>
      </div>

      {/* Header & Search */}
      <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Base de Clientes</h2>
            <p className="text-sm text-gray-400">Gerencie relacionamento e histórico de clientes.</p>
          </div>
          <button
            onClick={handleCreateClient}
            className="bg-barber-gold hover:bg-barber-goldhover text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-colors shadow-lg shadow-amber-500/20 text-sm"
          >
            <Plus size={16} />
            Novo Cliente
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-2.5 text-gray-500" size={18} />
          <input
            type="text"
            placeholder="Buscar por nome ou telefone..."
            className="w-full bg-barber-950 border border-barber-800 text-white pl-10 pr-4 py-2 rounded-lg focus:border-barber-gold outline-none transition-colors"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Tag Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide border-t border-barber-800 pt-4">
          <span className="text-[10px] text-gray-500 font-medium uppercase tracking-wider mr-2 flex items-center gap-1 shrink-0">
            <Filter size={12} /> Filtros:
          </span>
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setSelectedTagFilter(tag)}
              className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all border shrink-0 ${selectedTagFilter === tag
                ? 'bg-barber-gold text-black border-barber-gold'
                : 'bg-barber-950 text-gray-400 border-barber-800 hover:border-gray-600 hover:text-white'
                }`}
            >
              {tag === 'Todos' ? 'Todos' : `#${tag}`}
            </button>
          ))}
        </div>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClients.map(client => (
          <div
            key={client.id}
            className="bg-barber-900 border border-barber-800 rounded-xl p-6 shadow-lg hover:border-barber-gold/50 transition-all group relative flex flex-col h-full cursor-pointer"
            onClick={() => setSelectedClient(client)}
          >
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-xs text-barber-gold font-bold flex items-center gap-1 cursor-pointer hover:underline">
                <Eye size={14} /> Ver Ficha
              </span>
            </div>

            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-barber-800 to-barber-950 flex items-center justify-center text-xl font-bold text-barber-gold border border-barber-700 shrink-0">
                  {client.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-white leading-tight flex items-center gap-2">
                    {client.name}
                    {client.loyaltyTier === 'Ouro' && <span className="w-2 h-2 rounded-full bg-yellow-500" title="Cliente Ouro"></span>}
                    {client.loyaltyTier === 'Diamante' && <span className="w-2 h-2 rounded-full bg-cyan-500" title="Cliente Diamante"></span>}
                  </h3>
                  <div className="flex items-center gap-1 text-xs text-gray-400 mt-1">
                    <Calendar size={12} /> Última: {new Date(client.lastVisit).toLocaleDateString('pt-BR')}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4 flex-1 flex flex-col">
              {/* Interactive Tags Area */}
              <div
                className="flex flex-wrap gap-2 min-h-[32px] content-start"
                onClick={(e) => e.stopPropagation()}
              >
                {(client.tags || []).map(tag => (
                  <span key={tag} className={`text-xs px-2 py-1 rounded-full font-medium flex items-center gap-1 group/tag transition-all border ${tag === 'VIP'
                    ? 'bg-barber-gold/20 text-barber-gold border-barber-gold/30'
                    : 'bg-barber-950 text-gray-300 border-barber-800'
                    }`}>
                    {tag}
                    <button
                      onClick={() => handleRemoveTag(client.id, tag)}
                      className="opacity-0 group-hover/tag:opacity-100 hover:text-red-400 transition-opacity ml-1"
                      title="Remover tag"
                    >
                      <X size={10} />
                    </button>
                  </span>
                ))}

                {/* Add Tag Input */}
                {editingClientId === client.id ? (
                  <div className="flex items-center bg-barber-950 rounded-full border border-barber-700 px-2 py-0.5 animate-fade-in">
                    <input
                      autoFocus
                      type="text"
                      value={newTagInput}
                      onChange={(e) => setNewTagInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleAddTag(client.id)}
                      onBlur={() => handleAddTag(client.id)}
                      className="w-20 bg-transparent text-xs text-white outline-none"
                      placeholder="Nova tag..."
                    />
                    <button onMouseDown={() => handleAddTag(client.id)} className="text-green-500 hover:text-green-400 ml-1">
                      <Check size={12} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setEditingClientId(client.id)}
                    className="text-xs bg-barber-800/50 hover:bg-barber-800 text-gray-500 hover:text-gray-300 px-2 py-1 rounded-full border border-barber-800 hover:border-barber-700 border-dashed flex items-center gap-1 transition-all"
                  >
                    <Plus size={10} />
                  </button>
                )}
              </div>

              <div className="bg-barber-950 p-3 rounded-lg text-sm text-gray-400 border border-barber-800/50 flex-1">
                <span className="text-barber-gold font-bold block text-xs mb-1 uppercase tracking-wide">Preferências</span>
                {client.preferences}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-barber-800 mt-auto">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">{client.totalVisits}</div>
                  <div className="text-xs text-gray-500 uppercase">Visitas</div>
                </div>
                <button className="bg-green-600/20 hover:bg-green-600/30 text-green-500 px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-colors" onClick={(e) => e.stopPropagation()}>
                  <Phone size={16} /> WhatsApp
                </button>
              </div>
            </div>
          </div>
        ))}

        {filteredClients.length === 0 && (
          <div className="col-span-full py-10 text-center text-gray-500 border-2 border-dashed border-barber-800 rounded-xl">
            <Hash size={40} className="mx-auto mb-2 opacity-20" />
            <p>Nenhum cliente encontrado com os filtros atuais.</p>
            <button
              onClick={() => { setSearchTerm(''); setSelectedTagFilter('Todos'); }}
              className="mt-4 text-barber-gold hover:underline text-sm"
            >
              Limpar filtros
            </button>
          </div>
        )}
      </div>

      {selectedClient && (
        <ClientDetailsModal
          client={selectedClient}
          onClose={() => setSelectedClient(null)}
        />
      )}

      {/* Client Modal */}
      {showClientModal && (
        <ClientModal
          client={editingClient}
          onClose={() => setShowClientModal(false)}
          onSuccess={handleClientSuccess}
        />
      )}
    </div>
  );
};

export default Clients;
