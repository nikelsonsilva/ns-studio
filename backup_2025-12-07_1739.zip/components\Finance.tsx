
import React, { useState, useEffect } from 'react';
import { DollarSign, CreditCard, Wallet, ArrowUpRight, ArrowDownRight, PieChart, Sparkles, Download, Lock, Settings, Key, ShieldCheck, Eye, EyeOff, X, CheckCircle2, PiggyBank, Receipt, Printer, FileText, Sheet } from 'lucide-react';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Barber, RecurringExpense, Role } from '../types';

import { useSupabaseQuery } from '../lib/hooks';
import { fetchProfessionals, fetchFinancialRecords, fetchRecurringExpenses, getCurrentBusinessId } from '../lib/database';
import { supabase } from '../lib/supabase';

interface FinanceProps {
    paymentConfig?: {
        isConnected: boolean;
        stripeKey: string;
    };
    onSaveConfig?: (config: { isConnected: boolean; stripeKey: string }) => void;
    userRole?: Role;
}

const Finance: React.FC<FinanceProps> = ({ paymentConfig, onSaveConfig, userRole = 'Admin' }) => {
    const { data: barbersData } = useSupabaseQuery(fetchProfessionals);
    const { data: financialRecordsData } = useSupabaseQuery(fetchFinancialRecords);
    const { data: recurringExpensesData } = useSupabaseQuery(fetchRecurringExpenses);

    const barbers = barbersData || [];
    const transactions = financialRecordsData || [];
    const recurringExpenses = recurringExpensesData || [];

    // ✅ DADOS REAIS: Buscar agendamentos pagos
    const [paidAppointments, setPaidAppointments] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadPaidAppointments();
    }, []);

    const loadPaidAppointments = async () => {
        try {
            const businessId = await getCurrentBusinessId();
            const { data, error } = await supabase
                .from('appointments')
                .select(`
                    *,
                    service:services(price)
                `)
                .eq('business_id', businessId)
                .eq('payment_status', 'paid');

            if (error) throw error;
            setPaidAppointments(data || []);
            console.log('✅ [Finance] Loaded paid appointments:', data?.length);
        } catch (err) {
            console.error('❌ [Finance] Error loading appointments:', err);
        } finally {
            setLoading(false);
        }
    };

    // ✅ CALCULAR RECEITA REAL
    const totalRevenue = paidAppointments.reduce((sum, apt) => {
        return sum + (apt.service?.price || 0);
    }, 0);

    // ✅ CALCULAR DESPESAS REAIS
    const totalExpenses = recurringExpenses.reduce((sum, exp) => {
        return sum + Number(exp.amount || 0);
    }, 0);

    // ✅ SALDO LÍQUIDO REAL
    const netBalance = totalRevenue - totalExpenses;

    const [activeTab, setActiveTab] = useState<'dashboard' | 'commissions' | 'expenses'>('dashboard');

    // State for Payment Configuration
    const [showConfig, setShowConfig] = useState(false);
    const [stripePublishableKey, setStripePublishableKey] = useState('');
    const [stripeSecretKey, setStripeSecretKey] = useState('');
    const [showKeys, setShowKeys] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isConfigured, setIsConfigured] = useState(false);

    const [isExporting, setIsExporting] = useState<string | null>(null);

    useEffect(() => {
        // Carregar configuração existente do Stripe
        const loadStripeConfig = async () => {
            const { loadStripeKeys } = await import('../lib/stripeConfig');
            const keys = await loadStripeKeys();

            if (keys) {
                setStripePublishableKey(keys.publishableKey);
                setStripeSecretKey(keys.secretKey);
                setIsConfigured(true);
                console.log('✅ Stripe keys loaded from database');
            }
        };

        loadStripeConfig();
    }, []);



    // Calculate Payment Methods from real transactions
    const paymentMethodsCount = transactions.reduce((acc, curr) => {
        const method = curr.payment_method || 'Outros';
        acc[method] = (acc[method] || 0) + Number(curr.amount);
        return acc;
    }, {} as Record<string, number>);

    const paymentData = Object.entries(paymentMethodsCount).map(([name, value], index) => ({
        name,
        value,
        color: ['#22c55e', '#f59e0b', '#3f3f46', '#3b82f6'][index % 4]
    }));

    // Barber Profit Analysis (Simplified/Empty for now if no data)
    const barberProfits: any[] = [];

    const handleSaveKey = async () => {
        if (!stripePublishableKey || !stripeSecretKey) {
            alert('❌ Preencha ambas as chaves (Publishable e Secret)');
            return;
        }

        setIsSaving(true);

        try {
            const { saveStripeKeys } = await import('../lib/stripeConfig');
            const result = await saveStripeKeys(stripePublishableKey, stripeSecretKey);

            if (result) {
                setIsConfigured(true);
                alert('✅ Chaves do Stripe salvas com sucesso!');
                console.log('✅ Stripe keys saved successfully');
            } else {
                alert('❌ Erro: Verifique o formato das chaves');
            }
        } catch (error) {
            console.error('Error saving Stripe keys:', error);
            alert('❌ Erro ao salvar configuração. Tente novamente.');
        } finally {
            setIsSaving(false);
        }
    };

    const handleExport = (type: 'pdf' | 'excel') => {
        setIsExporting(type);
        setTimeout(() => {
            setIsExporting(null);
            alert(`Relatório ${type === 'pdf' ? 'PDF' : 'Excel'} baixado com sucesso! (Simulado)`);
        }, 2000);
    };

    const handlePrintPayslip = (barberName: string) => {
        alert(`Imprimindo Holerite de ${barberName}...`);
    };

    return (
        <div className="space-y-6 animate-fade-in relative pb-20">

            {/* Header Actions */}
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 bg-barber-900 p-4 rounded-xl border border-barber-800">
                <h2 className="text-xl font-bold text-white flex items-center gap-3">
                    <div className="bg-barber-950 p-2 rounded-lg border border-barber-800 shrink-0">
                        <Wallet size={20} className="text-barber-gold" />
                    </div>
                    Controle Financeiro
                </h2>

                <div className="flex flex-col sm:flex-row gap-4 w-full xl:w-auto">
                    {/* Navigation Tabs */}
                    <div className="flex bg-barber-950 rounded-lg p-1 border border-barber-800 overflow-x-auto">
                        <button
                            onClick={() => setActiveTab('dashboard')}
                            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-bold transition-all whitespace-nowrap ${activeTab === 'dashboard' ? 'bg-barber-800 text-white shadow' : 'text-gray-400 hover:text-white'}`}
                        >
                            Visão Geral
                        </button>
                        <button
                            onClick={() => setActiveTab('commissions')}
                            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-bold transition-all whitespace-nowrap ${activeTab === 'commissions' ? 'bg-barber-800 text-white shadow' : 'text-gray-400 hover:text-white'}`}
                        >
                            Comissões
                        </button>
                        <button
                            onClick={() => setActiveTab('expenses')}
                            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-bold transition-all whitespace-nowrap ${activeTab === 'expenses' ? 'bg-barber-800 text-white shadow' : 'text-gray-400 hover:text-white'}`}
                        >
                            Despesas
                        </button>
                    </div>

                    <div className="flex gap-2 w-full sm:w-auto">
                        {userRole === 'Admin' && (
                            <button
                                onClick={() => setShowConfig(true)}
                                className={`flex-1 sm:flex-none bg-barber-950 hover:bg-barber-800 text-gray-300 hover:text-white px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 border transition-colors ${isConfigured ? 'border-green-500/50 text-green-500' : 'border-barber-800'}`}
                            >
                                {isConfigured ? <CheckCircle2 size={14} /> : <Settings size={14} />}
                                {isConfigured ? 'Ativo' : 'Configurar'}
                            </button>
                        )}
                        <button className="flex-1 sm:flex-none bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-green-900/20 whitespace-nowrap">
                            <Lock size={14} /> Fechar Caixa
                        </button>
                    </div>
                </div>
            </div>

            {activeTab === 'dashboard' && (
                <div className="space-y-6 animate-fade-in">
                    {/* Export Buttons */}
                    <div className="flex flex-col sm:flex-row justify-end gap-2">
                        <button
                            onClick={() => handleExport('pdf')}
                            disabled={!!isExporting}
                            className="w-full sm:w-auto bg-red-500/10 hover:bg-red-500/20 text-red-500 px-3 py-1.5 rounded-lg border border-red-500/30 text-xs font-bold flex items-center justify-center gap-2"
                        >
                            {isExporting === 'pdf' ? <Sparkles className="animate-spin" size={14} /> : <FileText size={14} />}
                            Relatório PDF
                        </button>
                        <button
                            onClick={() => handleExport('excel')}
                            disabled={!!isExporting}
                            className="w-full sm:w-auto bg-green-500/10 hover:bg-green-500/20 text-green-500 px-3 py-1.5 rounded-lg border border-green-500/30 text-xs font-bold flex items-center justify-center gap-2"
                        >
                            {isExporting === 'excel' ? <Sparkles className="animate-spin" size={14} /> : <Sheet size={14} />}
                            Relatório Excel
                        </button>
                    </div>

                    {/* AI Financial Insight */}
                    <div className="bg-gradient-to-r from-green-900/20 to-barber-900 border border-green-500/20 rounded-xl p-4 flex flex-col sm:flex-row items-start gap-4">
                        <div className="bg-green-500/20 p-2 rounded-full text-green-500 shrink-0">
                            <Sparkles size={20} />
                        </div>
                        <div>
                            <h3 className="text-green-500 font-bold text-sm">Análise Inteligente de Caixa</h3>
                            <p className="text-gray-300 text-sm mt-1 leading-relaxed">
                                O volume de pagamentos via <strong>Pix</strong> cresceu 22% este mês. A redução nas taxas de cartão economizou <strong>R$ 340,00</strong>. Continue incentivando o Pix!
                            </p>
                        </div>
                    </div>

                    {/* KPI Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                        <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg relative overflow-hidden group">
                            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                                <DollarSign size={100} />
                            </div>
                            <h3 className="text-gray-400 text-sm font-medium uppercase mb-2">Entradas (Mês)</h3>
                            <div className="text-3xl font-bold text-green-500 flex items-center gap-2">
                                {loading ? '...' : `R$ ${totalRevenue.toFixed(2)}`}
                                <ArrowUpRight size={20} />
                            </div>
                            <div className="mt-2 text-xs text-gray-500">{paidAppointments.length} pagamentos confirmados</div>
                        </div>

                        <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg relative overflow-hidden group">
                            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                                <Wallet size={100} />
                            </div>
                            <h3 className="text-gray-400 text-sm font-medium uppercase mb-2">Saídas (Mês)</h3>
                            <div className="text-3xl font-bold text-red-500 flex items-center gap-2">
                                {loading ? '...' : `R$ ${totalExpenses.toFixed(2)}`}
                                <ArrowDownRight size={20} />
                            </div>
                            <div className="mt-2 text-xs text-gray-500">{recurringExpenses.length} despesas registradas</div>
                        </div>

                        {/* Tip Control Card */}
                        <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg relative overflow-hidden group">
                            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                                <PiggyBank size={100} />
                            </div>
                            <h3 className="text-gray-400 text-sm font-medium uppercase mb-2">Caixinha Acumulada</h3>
                            <div className="text-3xl font-bold text-blue-400 flex items-center gap-2">
                                R$ 385
                            </div>
                            <div className="mt-2 text-xs text-gray-500">Separado do faturamento</div>
                        </div>

                        <div className="bg-gradient-to-br from-barber-gold to-yellow-600 p-6 rounded-xl shadow-lg relative overflow-hidden">
                            <h3 className="text-black/70 text-sm font-bold uppercase mb-2">Saldo Líquido</h3>
                            {userRole === 'Admin' ? (
                                <div className="text-4xl font-extrabold text-black">
                                    {loading ? '...' : `R$ ${netBalance.toFixed(2)}`}
                                </div>
                            ) : (
                                <div className="text-2xl font-extrabold text-black/50 flex items-center gap-2">
                                    <Lock size={20} /> Acesso Restrito
                                </div>
                            )}
                            <div className="mt-4 inline-flex items-center gap-2 bg-black/20 px-3 py-1 rounded-full text-black text-xs font-bold">
                                <PieChart size={14} /> Margem: 72%
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Payment Methods Chart */}
                        <div className="bg-barber-900 border border-barber-800 p-6 rounded-xl shadow-lg">
                            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                <CreditCard size={20} className="text-barber-gold" />
                                Métodos de Pagamento
                            </h3>
                            <div className="h-64 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <RePieChart>
                                        <Pie
                                            data={paymentData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={5}
                                            dataKey="value"
                                            stroke="none"
                                        >
                                            {paymentData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <Tooltip
                                            contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff' }}
                                            itemStyle={{ color: '#fff' }}
                                        />
                                        <Legend iconType="circle" />
                                    </RePieChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Transactions List */}
                        <div className="lg:col-span-2 bg-barber-900 border border-barber-800 p-6 rounded-xl shadow-lg flex flex-col">
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="text-lg font-bold text-white">Fluxo de Caixa Diário</h3>
                                <button className="text-xs text-barber-gold hover:underline">Ver completo</button>
                            </div>

                            <div className="flex-1 overflow-x-auto">
                                <table className="w-full text-left border-collapse min-w-[500px]">
                                    <thead>
                                        <tr className="text-gray-500 text-xs uppercase border-b border-barber-800">
                                            <th className="pb-3 pl-2">Hora</th>
                                            <th className="pb-3">Descrição</th>
                                            <th className="pb-3">Pagamento</th>
                                            <th className="pb-3 text-right pr-2">Valor</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-sm">
                                        {transactions.map((tx) => (
                                            <tr key={tx.id} className="border-b border-barber-800/50 hover:bg-barber-800/20 transition-colors">
                                                <td className="py-4 pl-2 text-gray-400 font-mono text-xs">{tx.time}</td>
                                                <td className="py-4 text-white font-medium">{tx.desc}</td>
                                                <td className="py-4">
                                                    <span className={`text-xs px-2 py-1 rounded border ${tx.method === 'Pix' ? 'border-green-500/30 text-green-400 bg-green-500/10' :
                                                        tx.method === 'Cartão' ? 'border-blue-500/30 text-blue-400 bg-blue-500/10' :
                                                            'border-gray-500/30 text-gray-400 bg-gray-500/10'
                                                        }`}>
                                                        {tx.method}
                                                    </span>
                                                </td>
                                                <td className={`py-4 text-right pr-2 font-bold ${tx.type === 'income' ? 'text-green-500' : 'text-red-500'}`}>
                                                    {tx.type === 'income' ? '+' : '-'} R$ {tx.amount.toFixed(2)}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    {/* Barber Profitability Analysis */}
                    {userRole === 'Admin' && (
                        <div className="bg-barber-900 border border-barber-800 rounded-xl p-6 shadow-lg">
                            <h3 className="text-lg font-bold text-white mb-6">Lucratividade por Barbeiro (Líquido)</h3>
                            <div className="overflow-x-auto">
                                <table className="w-full text-left min-w-[600px]">
                                    <thead>
                                        <tr className="text-xs text-gray-500 uppercase border-b border-barber-800">
                                            <th className="pb-3">Profissional</th>
                                            <th className="pb-3">Receita Bruta</th>
                                            <th className="pb-3">Despesas/Custos</th>
                                            <th className="pb-3 text-right">Lucro Líquido</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-sm">
                                        {barberProfits.map((b, idx) => (
                                            <tr key={idx} className="border-b border-barber-800/50 hover:bg-barber-800/20">
                                                <td className="py-4 font-bold text-white">{b.name}</td>
                                                <td className="py-4 text-green-500">R$ {b.gross.toFixed(2)}</td>
                                                <td className="py-4 text-red-400">R$ {b.costs.toFixed(2)}</td>
                                                <td className="py-4 text-right font-bold text-barber-gold">R$ {b.net.toFixed(2)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Commission Calculator Tab (Payroll) */}
            {activeTab === 'commissions' && (
                <div className="animate-fade-in bg-barber-900 border border-barber-800 rounded-xl p-6 shadow-lg">
                    <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                        <Receipt className="text-barber-gold" /> Calculadora de Comissões (Holerite)
                    </h3>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse min-w-[900px]">
                            <thead>
                                <tr className="text-xs text-gray-500 uppercase border-b border-barber-800 bg-barber-950">
                                    <th className="p-3">Profissional</th>
                                    <th className="p-3">Total Serviços</th>
                                    <th className="p-3">Taxa (%)</th>
                                    <th className="p-3 text-green-500">Valor Comissão</th>
                                    <th className="p-3 text-blue-400">+ Produtos</th>
                                    <th className="p-3 text-yellow-500">+ Caixinha</th>
                                    <th className="p-3 text-red-400">- Taxas</th>
                                    <th className="p-3 text-red-400">- Vales</th>
                                    <th className="p-3 text-right font-bold text-white">A Pagar</th>
                                    <th className="p-3 text-center">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="text-sm divide-y divide-barber-800">
                                {barbers.map(barber => {
                                    const totalServices = barber.currentSales || 0;
                                    const commissionValue = totalServices * (barber.commissionRate / 100);
                                    const productCommission = 120; // Mocked
                                    const tips = 45; // Mocked
                                    const cardFees = totalServices * 0.02; // Mocked 2% fee
                                    const advances = 200; // Mocked advance
                                    const netPay = commissionValue + productCommission + tips - cardFees - advances;

                                    return (
                                        <tr key={barber.id} className="hover:bg-barber-800/30 transition-colors">
                                            <td className="p-3 font-medium text-white flex items-center gap-2">
                                                <img src={barber.avatar} className="w-6 h-6 rounded-full" />
                                                {barber.name}
                                            </td>
                                            <td className="p-3">R$ {totalServices.toFixed(2)}</td>
                                            <td className="p-3">{barber.commissionRate}%</td>
                                            <td className="p-3 font-bold text-green-500">R$ {commissionValue.toFixed(2)}</td>
                                            <td className="p-3 text-blue-400">R$ {productCommission.toFixed(2)}</td>
                                            <td className="p-3 text-yellow-500">R$ {tips.toFixed(2)}</td>
                                            <td className="p-3 text-red-400">- R$ {cardFees.toFixed(2)}</td>
                                            <td className="p-3 text-red-400">- R$ {advances.toFixed(2)}</td>
                                            <td className="p-3 text-right font-bold text-barber-gold text-base border-l border-barber-800 bg-barber-950/30">
                                                R$ {netPay.toFixed(2)}
                                            </td>
                                            <td className="p-3 text-center">
                                                <button
                                                    onClick={() => handlePrintPayslip(barber.name)}
                                                    className="p-1.5 hover:bg-barber-700 rounded text-gray-400 hover:text-white" title="Imprimir Holerite"
                                                >
                                                    <Printer size={16} />
                                                </button>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Recurring Expenses Tab */}
            {activeTab === 'expenses' && (
                <div className="animate-fade-in space-y-6">
                    <div className="bg-barber-900 border border-barber-800 rounded-xl p-6 shadow-lg">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                <CreditCard className="text-red-500" /> Despesas Recorrentes (Contas Fixas)
                            </h3>
                            <button className="bg-barber-800 hover:bg-barber-700 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2">
                                + Nova Despesa
                            </button>
                        </div>

                        <div className="grid grid-cols-1 gap-4">
                            {recurringExpenses.map(expense => (
                                <div key={expense.id} className="bg-barber-950 border border-barber-800 p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between group hover:border-barber-700 transition-colors gap-4">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-3 rounded-lg ${expense.active ? 'bg-red-500/10 text-red-500' : 'bg-gray-800 text-gray-500'}`}>
                                            <Wallet size={20} />
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-white">{expense.description}</h4>
                                            <p className="text-xs text-gray-500">Vence dia {expense.dayOfMonth} • Categoria: {expense.category}</p>
                                        </div>
                                    </div>

                                    <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto">
                                        <div className="text-right">
                                            <div className="font-bold text-white">R$ {expense.amount.toFixed(2)}</div>
                                            <div className="text-[10px] text-gray-500 uppercase font-bold">Mensal</div>
                                        </div>
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" checked={expense.active} className="sr-only peer" readOnly />
                                            <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                        </label>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Payment Configuration Modal */}
            {showConfig && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
                    <div className="bg-barber-900 w-full max-w-md rounded-xl border border-barber-800 shadow-2xl relative overflow-hidden">
                        <div className="p-6 border-b border-barber-800 flex justify-between items-center bg-barber-950">
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                <ShieldCheck className="text-barber-gold" /> Gateway de Pagamento
                            </h3>
                            <button onClick={() => setShowConfig(false)} className="text-gray-400 hover:text-white">
                                <X size={20} />
                            </button>
                        </div>

                        <div className="p-6 space-y-6">
                            <div className="flex items-center gap-3 p-3 bg-barber-950 rounded-lg border border-barber-800">
                                <div className="w-10 h-10 bg-[#635BFF] rounded flex items-center justify-center font-bold text-white italic">S</div>
                                <div>
                                    <div className="font-bold text-white">Stripe Payments</div>
                                    <div className="text-xs text-gray-400">Provedor selecionado</div>
                                </div>
                                {isConfigured && <CheckCircle2 className="ml-auto text-green-500" size={20} />}
                            </div>

                            <div className="space-y-2">
                                <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                                    <Key size={14} /> API Key (Secret Key)
                                </label>
                                <div className="relative">
                                    <input
                                        type={showKeys ? "text" : "password"}
                                        value={stripeSecretKey}
                                        onChange={(e) => setStripeSecretKey(e.target.value)}
                                        placeholder="sk_live_..."
                                        className="w-full bg-barber-950 border border-barber-800 text-white rounded-lg pl-4 pr-10 py-3 text-sm focus:border-barber-gold outline-none"
                                    />
                                    <button
                                        onClick={() => setShowKeys(!showKeys)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                                    >
                                        {showKeys ? <EyeOff size={16} /> : <Eye size={16} />}
                                    </button>
                                </div>
                                <p className="text-[10px] text-gray-500">
                                    Insira sua chave secreta do Stripe para habilitar pagamentos automáticos antes da confirmação de agendamentos.
                                </p>
                            </div>

                            {isConfigured && (
                                <div className="bg-green-500/10 border border-green-500/20 text-green-500 text-sm p-3 rounded-lg flex items-center gap-2 animate-fade-in">
                                    <CheckCircle2 size={16} /> Chave API salva e verificada com sucesso!
                                </div>
                            )}

                            <button
                                onClick={handleSaveKey}
                                disabled={isSaving || !stripeSecretKey}
                                className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-all ${isConfigured
                                    ? 'bg-green-600 text-white'
                                    : 'bg-barber-gold hover:bg-barber-goldhover text-black'
                                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                            >
                                {isSaving ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                                        Verificando...
                                    </>
                                ) : isConfigured ? (
                                    'Atualizar Configuração'
                                ) : (
                                    'Salvar Configuração'
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Finance;
