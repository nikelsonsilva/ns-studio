import React, { useState, useEffect } from 'react';
import {
   Save,
   Store,
   Bot,
   Layout,
   ShieldAlert,
   DollarSign,
   BarChart3,
   Globe,
   ToggleLeft,
   ToggleRight,
   Sparkles,
   Clock,
   Calendar,
   Users,
   Timer
} from 'lucide-react';
import { SystemSettings } from '../types';
import { getCurrentBusiness, getCurrentBusinessId } from '../lib/database';
import { supabase } from '../lib/supabase';

interface SettingsProps {
   settings: SystemSettings;
   onUpdateSettings: (newSettings: SystemSettings) => void;
}

interface BusinessHours {
   monday: { open: string; close: string; closed: boolean };
   tuesday: { open: string; close: string; closed: boolean };
   wednesday: { open: string; close: string; closed: boolean };
   thursday: { open: string; close: string; closed: boolean };
   friday: { open: string; close: string; closed: boolean };
   saturday: { open: string; close: string; closed: boolean };
   sunday: { open: string; close: string; closed: boolean };
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings }) => {

   const [businessHours, setBusinessHours] = useState<BusinessHours>({
      monday: { open: '09:00', close: '18:00', closed: false },
      tuesday: { open: '09:00', close: '18:00', closed: false },
      wednesday: { open: '09:00', close: '18:00', closed: false },
      thursday: { open: '09:00', close: '18:00', closed: false },
      friday: { open: '09:00', close: '18:00', closed: false },
      saturday: { open: '09:00', close: '14:00', closed: false },
      sunday: { open: '09:00', close: '14:00', closed: true },
   });

   const [globalBuffer, setGlobalBuffer] = useState(15);
   const [saving, setSaving] = useState(false);

   // Carregar dados do banco
   useEffect(() => {
      loadBusinessData();
   }, []);

   const loadBusinessData = async () => {
      const business = await getCurrentBusiness();
      if (business) {
         if (business.business_hours) {
            setBusinessHours(business.business_hours as BusinessHours);
         }
         if (business.booking_settings?.buffer_minutes) {
            setGlobalBuffer(business.booking_settings.buffer_minutes);
         }
      }
   };

   const handleSaveAll = async () => {
      setSaving(true);
      try {
         const businessId = await getCurrentBusinessId();
         if (!businessId) {
            alert('Erro: Negócio não encontrado');
            return;
         }

         // Atualizar horários de funcionamento
         const { error: hoursError } = await supabase
            .from('businesses')
            .update({ business_hours: businessHours })
            .eq('id', businessId);

         if (hoursError) throw hoursError;

         // Atualizar buffer global
         const { data: currentBusiness } = await supabase
            .from('businesses')
            .select('booking_settings')
            .eq('id', businessId)
            .single();

         const updatedSettings = {
            ...(currentBusiness?.booking_settings || {}),
            buffer_minutes: globalBuffer
         };

         const { error: bufferError } = await supabase
            .from('businesses')
            .update({ booking_settings: updatedSettings })
            .eq('id', businessId);

         if (bufferError) throw bufferError;

         alert('✅ Configurações salvas com sucesso!');
      } catch (error) {
         console.error('Erro ao salvar:', error);
         alert('❌ Erro ao salvar configurações');
      } finally {
         setSaving(false);
      }
   };

   const handleToggleModule = (module: keyof SystemSettings['modules']) => {
      onUpdateSettings({
         ...settings,
         modules: {
            ...settings.modules,
            [module]: !settings.modules[module]
         }
      });
   };

   const handleToggleAI = (type: keyof SystemSettings['aiConfig']['insightTypes']) => {
      onUpdateSettings({
         ...settings,
         aiConfig: {
            ...settings.aiConfig,
            insightTypes: {
               ...settings.aiConfig.insightTypes,
               [type]: !settings.aiConfig.insightTypes[type]
            }
         }
      });
   };

   const handleGlobalAIToggle = () => {
      onUpdateSettings({
         ...settings,
         aiConfig: {
            ...settings.aiConfig,
            enableInsights: !settings.aiConfig.enableInsights
         }
      });
   };

   const handleDayHoursChange = (day: keyof BusinessHours, field: 'open' | 'close', value: string) => {
      setBusinessHours({
         ...businessHours,
         [day]: {
            ...businessHours[day],
            [field]: value
         }
      });
   };

   const handleDayToggle = (day: keyof BusinessHours) => {
      setBusinessHours({
         ...businessHours,
         [day]: {
            ...businessHours[day],
            closed: !businessHours[day].closed
         }
      });
   };

   const Toggle = ({ active, onClick }: { active: boolean, onClick: () => void }) => (
      <button onClick={onClick} className={`transition-colors ${active ? 'text-green-500' : 'text-gray-600'}`}>
         {active ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
      </button>
   );

   const dayNames: { key: keyof BusinessHours; label: string }[] = [
      { key: 'monday', label: 'Segunda-feira' },
      { key: 'tuesday', label: 'Terça-feira' },
      { key: 'wednesday', label: 'Quarta-feira' },
      { key: 'thursday', label: 'Quinta-feira' },
      { key: 'friday', label: 'Sexta-feira' },
      { key: 'saturday', label: 'Sábado' },
      { key: 'sunday', label: 'Domingo' },
   ];

   return (
      <div className="space-y-6 animate-fade-in pb-20">

         {/* Header */}
         <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
               <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Layout className="text-barber-gold" /> Configurações
               </h2>
               <p className="text-gray-400 text-sm mt-1">Personalize módulos, horários e intervalos.</p>
            </div>
            <button
               onClick={handleSaveAll}
               disabled={saving}
               className="bg-barber-gold hover:bg-barber-goldhover text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-colors w-full md:w-auto justify-center disabled:opacity-50"
            >
               <Save size={18} /> {saving ? 'Salvando...' : 'Salvar Alterações'}
            </button>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            {/* Horário de Funcionamento */}
            <div className="lg:col-span-2 bg-barber-950 border border-barber-800 rounded-xl p-6">
               <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <Clock className="text-blue-500" /> Horário de Funcionamento do Estabelecimento
               </h3>
               <p className="text-gray-400 text-sm mb-4">
                  Define o horário global do negócio. Os profissionais só podem trabalhar dentro deste período.
               </p>

               <div className="space-y-3">
                  {dayNames.map(({ key, label }) => (
                     <div
                        key={key}
                        className={`p-4 bg-barber-900 rounded-lg border border-barber-800 transition-all ${businessHours[key].closed ? 'opacity-50' : ''
                           }`}
                     >
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                           <div className="flex items-center justify-between sm:w-48">
                              <span className="text-white font-medium">{label}</span>
                              <Toggle
                                 active={!businessHours[key].closed}
                                 onClick={() => handleDayToggle(key)}
                              />
                           </div>

                           {!businessHours[key].closed && (
                              <div className="flex items-center gap-3 flex-1">
                                 <div className="flex items-center gap-2">
                                    <label className="text-xs text-gray-400">Abertura</label>
                                    <input
                                       type="time"
                                       value={businessHours[key].open}
                                       onChange={(e) => handleDayHoursChange(key, 'open', e.target.value)}
                                       className="bg-barber-950 border border-barber-700 text-white rounded px-3 py-1.5 text-sm outline-none focus:border-barber-gold"
                                    />
                                 </div>
                                 <span className="text-gray-500">→</span>
                                 <div className="flex items-center gap-2">
                                    <label className="text-xs text-gray-400">Fechamento</label>
                                    <input
                                       type="time"
                                       value={businessHours[key].close}
                                       onChange={(e) => handleDayHoursChange(key, 'close', e.target.value)}
                                       className="bg-barber-950 border border-barber-700 text-white rounded px-3 py-1.5 text-sm outline-none focus:border-barber-gold"
                                    />
                                 </div>
                              </div>
                           )}

                           {businessHours[key].closed && (
                              <span className="text-red-400 text-sm font-medium">Fechado</span>
                           )}
                        </div>
                     </div>
                  ))}
               </div>
            </div>

            {/* Intervalo entre Serviços */}
            <div className="lg:col-span-2 bg-barber-950 border border-barber-800 rounded-xl p-6">
               <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <Timer className="text-green-500" /> Intervalo entre Serviços
               </h3>
               <p className="text-gray-400 text-sm mb-6">
                  Tempo de buffer entre atendimentos. Pode ser personalizado por profissional na aba Equipe.
               </p>

               <div className="bg-barber-900 p-6 rounded-lg border border-barber-800">
                  <div className="flex justify-between items-center mb-4">
                     <div>
                        <label className="text-white font-medium block mb-1">Buffer Global Padrão</label>
                        <p className="text-xs text-gray-500">Aplicado a todos os profissionais por padrão</p>
                     </div>
                     <div className="text-right">
                        <span className="text-3xl font-bold text-barber-gold">{globalBuffer}</span>
                        <span className="text-gray-400 ml-1">min</span>
                     </div>
                  </div>

                  <input
                     type="range"
                     min="0"
                     max="60"
                     step="5"
                     value={globalBuffer}
                     onChange={(e) => setGlobalBuffer(Number(e.target.value))}
                     className="w-full accent-barber-gold h-2 bg-barber-800 rounded-lg appearance-none cursor-pointer"
                  />

                  <div className="flex justify-between text-xs text-gray-500 mt-2">
                     <span>0 min</span>
                     <span>15 min</span>
                     <span>30 min</span>
                     <span>45 min</span>
                     <span>60 min</span>
                  </div>

                  <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                     <p className="text-xs text-blue-300 flex items-center gap-2">
                        <Users size={14} />
                        <span>Para configurar buffer individual por profissional, vá em <strong>Equipe</strong> e edite cada profissional.</span>
                     </p>
                  </div>
               </div>
            </div>

            {/* Módulos do Sistema */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-6">
               <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <Store className="text-blue-500" /> Módulos Ativos
               </h3>
               <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-barber-900 rounded-lg border border-barber-800">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-500/20 rounded text-purple-400"><Bot size={18} /></div>
                        <div>
                           <div className="font-bold text-white">Chatbot IA (Site)</div>
                           <div className="text-xs text-gray-500">Assistente virtual.</div>
                        </div>
                     </div>
                     <Toggle active={settings.modules.aiChatbot} onClick={() => handleToggleModule('aiChatbot')} />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-barber-900 rounded-lg border border-barber-800">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-500/20 rounded text-green-400"><DollarSign size={18} /></div>
                        <div>
                           <div className="font-bold text-white">Gestão Financeira</div>
                           <div className="text-xs text-gray-500">Caixa e comissões.</div>
                        </div>
                     </div>
                     <Toggle active={settings.modules.finance} onClick={() => handleToggleModule('finance')} />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-barber-900 rounded-lg border border-barber-800">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-yellow-500/20 rounded text-yellow-400"><Globe size={18} /></div>
                        <div>
                           <div className="font-bold text-white">Agendamento Público</div>
                           <div className="text-xs text-gray-500">Link para clientes.</div>
                        </div>
                     </div>
                     <Toggle active={settings.modules.publicBooking} onClick={() => handleToggleModule('publicBooking')} />
                  </div>
               </div>
            </div>

            {/* IA & Notificações */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-6 relative overflow-hidden">
               {/* Visual Flair */}
               <div className="absolute -top-10 -right-10 w-32 h-32 bg-barber-gold/10 rounded-full blur-3xl"></div>

               <div className="flex justify-between items-start mb-6">
                  <h3 className="text-white font-bold text-lg flex items-center gap-2">
                     <Sparkles className="text-barber-gold" /> Controle da IA
                  </h3>
                  <div className="flex items-center gap-2">
                     <span className="text-xs text-gray-400 font-bold uppercase">{settings.aiConfig.enableInsights ? 'Ativado' : 'Desativado'}</span>
                     <Toggle active={settings.aiConfig.enableInsights} onClick={handleGlobalAIToggle} />
                  </div>
               </div>

               <div className={`space-y-4 transition-all ${!settings.aiConfig.enableInsights ? 'opacity-50 pointer-events-none grayscale' : ''}`}>
                  <div className="bg-barber-900 p-4 rounded-lg border border-barber-800">
                     <p className="text-xs text-gray-400 font-bold uppercase mb-3">Tipos de Notificação</p>

                     <div className="space-y-3">
                        <div className="flex items-center justify-between">
                           <div className="flex items-center gap-2 text-sm text-white">
                              <ShieldAlert size={16} className="text-red-500" /> Risco de Churn
                           </div>
                           <Toggle active={settings.aiConfig.insightTypes.churn} onClick={() => handleToggleAI('churn')} />
                        </div>
                        <div className="flex items-center justify-between">
                           <div className="flex items-center gap-2 text-sm text-white">
                              <BarChart3 size={16} className="text-green-500" /> Financeiro
                           </div>
                           <Toggle active={settings.aiConfig.insightTypes.financial} onClick={() => handleToggleAI('financial')} />
                        </div>
                     </div>
                  </div>

                  <div className="bg-barber-900 p-4 rounded-lg border border-barber-800">
                     <div className="flex justify-between items-center mb-2">
                        <p className="text-xs text-gray-400 font-bold uppercase">Frequência</p>
                        <span className="text-xs bg-black px-2 py-0.5 rounded text-white capitalize">{settings.aiConfig.notificationFrequency}</span>
                     </div>
                     <input
                        type="range"
                        min="0"
                        max="2"
                        step="1"
                        className="w-full accent-barber-gold h-1 bg-barber-800 rounded-lg appearance-none cursor-pointer"
                        value={settings.aiConfig.notificationFrequency === 'low' ? 0 : settings.aiConfig.notificationFrequency === 'medium' ? 1 : 2}
                        onChange={(e) => {
                           const val = Number(e.target.value);
                           onUpdateSettings({
                              ...settings,
                              aiConfig: {
                                 ...settings.aiConfig,
                                 notificationFrequency: val === 0 ? 'low' : val === 1 ? 'medium' : 'high'
                              }
                           })
                        }}
                     />
                     <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                        <span>Baixa</span>
                        <span>Média</span>
                        <span>Alta</span>
                     </div>
                  </div>
               </div>
            </div>

            {/* Dados do Negócio */}
            <div className="lg:col-span-2 bg-barber-950 border border-barber-800 rounded-xl p-6">
               <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <Store className="text-gray-400" /> Informações
               </h3>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                     <label className="text-xs text-gray-400 block mb-1">Nome</label>
                     <input
                        type="text"
                        value={settings.businessName}
                        onChange={(e) => onUpdateSettings({ ...settings, businessName: e.target.value })}
                        className="w-full bg-barber-900 border border-barber-800 text-white rounded-lg p-3 outline-none focus:border-barber-gold"
                     />
                  </div>
                  <div>
                     <label className="text-xs text-gray-400 block mb-1">Endereço</label>
                     <input
                        type="text"
                        value={settings.businessAddress}
                        onChange={(e) => onUpdateSettings({ ...settings, businessAddress: e.target.value })}
                        className="w-full bg-barber-900 border border-barber-800 text-white rounded-lg p-3 outline-none focus:border-barber-gold"
                     />
                  </div>
               </div>
            </div>

         </div>
      </div>
   );
};

export default Settings;
