
import React, { useState } from 'react';
import { Star, Scissors, Banknote, TrendingUp, Trophy, Target, Crown, Settings, X, Calendar, Clock, Check, ToggleLeft, ToggleRight, Users } from 'lucide-react';
import { Barber, WorkDay } from '../types';
import ProfessionalModal from './ProfessionalModal';

import { useSupabaseQuery } from '../lib/hooks';
import { fetchProfessionals, deleteProfessional } from '../lib/database';

interface TeamProps { }

const Team: React.FC<TeamProps> = () => {
   const { data: barbersData, refetch: refetchProfessionals } = useSupabaseQuery(fetchProfessionals);
   const [barbers, setBarbers] = useState<Barber[]>([]);

   React.useEffect(() => {
      if (barbersData) {
         setBarbers(barbersData);
      }
   }, [barbersData]);

   const [editingBarber, setEditingBarber] = useState<Barber | null>(null);
   const [showProfessionalModal, setShowProfessionalModal] = useState(false);
   const [editingProfessional, setEditingProfessional] = useState<Barber | null>(null);

   // Enhanced mock data for visual purposes (ranking)
   const rankedBarbers = [...barbers].sort((a, b) => (b.currentSales || 0) - (a.currentSales || 0));

   const handleEditClick = (barber: Barber) => {
      // Ensure schedule exists if not present
      const schedule = barber.workSchedule || [0, 1, 2, 3, 4, 5, 6].map(d => ({
         dayOfWeek: d, startTime: '09:00', endTime: '19:00', active: d !== 0
      }));
      setEditingBarber({ ...barber, workSchedule: schedule });
   };

   const handleSaveBarber = () => {
      if (!editingBarber) return;
      setBarbers(prev => prev.map(b => b.id === editingBarber.id ? editingBarber : b));
      setEditingBarber(null);
   };

   const updateSchedule = (dayIndex: number, field: keyof WorkDay, value: any) => {
      if (!editingBarber || !editingBarber.workSchedule) return;
      const newSchedule = [...editingBarber.workSchedule];
      newSchedule[dayIndex] = { ...newSchedule[dayIndex], [field]: value };
      setEditingBarber({ ...editingBarber, workSchedule: newSchedule });
   };

   const handleCreateProfessional = () => {
      setEditingProfessional(null);
      setShowProfessionalModal(true);
   };

   const handleDeleteProfessional = async (id: string) => {
      if (confirm('Tem certeza que deseja excluir este profissional?')) {
         const result = await deleteProfessional(id);
         if (result) {
            refetchProfessionals();
         }
      }
   };

   const handleProfessionalSuccess = () => {
      refetchProfessionals();
   };

   const daysMap = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

   return (
      <div className="space-y-8 animate-fade-in pb-20">

         {/* Ranking Header */}
         <div className="bg-gradient-to-r from-barber-900 to-barber-950 border border-barber-800 rounded-xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-10 opacity-5">
               <Trophy size={120} />
            </div>
            <div className="relative z-10">
               <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                  <Trophy className="text-yellow-500" /> Ranking do Mês
               </h2>
               <p className="text-gray-400 text-sm mb-6">Competição saudável baseada em faturamento total.</p>

               <div className="flex items-end gap-4 md:gap-8 overflow-x-auto pb-8 pt-4 scrollbar-hide">
                  {rankedBarbers.slice(0, 3).map((barber, index) => {
                     const isFirst = index === 0;
                     return (
                        <div key={barber.id} className={`flex flex-col items-center flex-shrink-0 ${isFirst ? 'scale-110 -mt-4' : 'opacity-90'}`}>
                           <div className="relative">
                              <img
                                 src={barber.avatar}
                                 alt={barber.name}
                                 className={`rounded-full object-cover border-4 ${isFirst ? 'w-24 h-24 border-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.3)]' : index === 1 ? 'w-20 h-20 border-gray-400' : 'w-16 h-16 border-orange-700'}`}
                              />
                              {isFirst && (
                                 <div className="absolute -top-6 left-1/2 -translate-x-1/2">
                                    <Crown size={32} className="text-yellow-500 fill-yellow-500" />
                                 </div>
                              )}
                              <div className={`absolute -bottom-3 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-xs font-bold whitespace-nowrap ${isFirst ? 'bg-yellow-500 text-black' : 'bg-barber-800 text-white border border-barber-700'}`}>
                                 #{index + 1}
                              </div>
                           </div>
                           <div className="text-center mt-4">
                              <h3 className={`font-bold text-white ${isFirst ? 'text-lg' : 'text-sm'}`}>{barber.name}</h3>
                              <div className="text-green-500 font-bold text-sm">R$ {barber.currentSales}</div>
                           </div>
                        </div>
                     )
                  })}
               </div>
            </div>
         </div>

         <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mt-8 gap-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
               <Target className="text-barber-gold" /> Painel de Metas
            </h2>
            <button onClick={handleCreateProfessional} className="bg-barber-800 hover:bg-barber-700 text-white px-4 py-2 rounded-lg font-bold text-sm transition-colors border border-barber-700 w-full sm:w-auto">
               + Adicionar Profissional
            </button>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {barbers.length === 0 ? (
               <div className="col-span-full p-12 text-center border-2 border-dashed border-barber-800 rounded-xl">
                  <div className="flex flex-col items-center gap-3 text-gray-500">
                     <Users size={48} className="opacity-20" />
                     <p className="text-lg font-medium">Você ainda não tem nenhum profissional cadastrado</p>
                     <p className="text-sm text-gray-600">Clique em "Adicionar Profissional" para começar</p>
                  </div>
               </div>
            ) : (
               barbers.map(barber => {
                  const progress = ((barber.currentSales || 0) / (barber.goal || 1)) * 100;

                  return (
                     <div key={barber.id} className="bg-barber-900 border border-barber-800 rounded-xl overflow-hidden shadow-lg group">
                        {/* Header / Profile */}
                        <div className="p-6 flex items-start gap-4 relative">
                           <div className="absolute top-0 right-0 p-4">
                              <button
                                 onClick={() => handleEditClick(barber)}
                                 className="p-2 bg-barber-950 hover:bg-barber-800 rounded-lg border border-barber-800 text-gray-400 hover:text-white transition-colors"
                                 title="Gerenciar Profissional"
                              >
                                 <Settings size={16} />
                              </button>
                           </div>

                           <img src={barber.avatar} alt={barber.name} className="w-16 h-16 rounded-xl object-cover border-2 border-barber-800 group-hover:border-barber-gold transition-colors" />

                           <div className="flex-1">
                              <h3 className="text-lg font-bold text-white">{barber.name}</h3>
                              <div className="flex items-center gap-2 mb-2">
                                 <div className="flex items-center gap-1 text-yellow-400 text-xs">
                                    <Star size={14} fill="#facc15" />
                                    <span className="font-bold">{barber.rating}</span>
                                 </div>
                                 <span className="text-gray-600 text-xs">• {barber.specialty}</span>
                              </div>

                              {/* Meta Progress */}
                              <div className="mt-3 pr-10">
                                 <div className="flex justify-between text-xs mb-1">
                                    <span className="text-gray-400">Meta Mensal</span>
                                    <span className="text-white font-bold">{progress.toFixed(0)}%</span>
                                 </div>
                                 <div className="w-full h-2 bg-barber-950 rounded-full overflow-hidden border border-barber-800">
                                    <div
                                       className="h-full bg-gradient-to-r from-barber-gold to-yellow-600 rounded-full transition-all duration-500"
                                       style={{ width: `${Math.min(progress, 100)}%` }}
                                    ></div>
                                 </div>
                                 <div className="flex justify-between text-[10px] mt-1 text-gray-500">
                                    <span>R$ {barber.currentSales}</span>
                                    <span>Alvo: R$ {barber.goal}</span>
                                 </div>
                              </div>
                           </div>
                        </div>

                        {/* Metrics Grid */}
                        <div className="grid grid-cols-3 border-t border-barber-800 divide-x divide-barber-800 bg-barber-950/30">
                           <div className="p-4 text-center hover:bg-barber-800/30 transition-colors">
                              <div className="flex justify-center mb-2 text-barber-gold"><Banknote size={18} /></div>
                              <div className="text-base font-bold text-white">R$ {barber.currentSales}</div>
                              <div className="text-[10px] uppercase text-gray-500 font-bold tracking-wider">Faturamento</div>
                           </div>
                           <div className="p-4 text-center hover:bg-barber-800/30 transition-colors">
                              <div className="flex justify-center mb-2 text-blue-400"><Scissors size={18} /></div>
                              <div className="text-base font-bold text-white">84</div>
                              <div className="text-[10px] uppercase text-gray-500 font-bold tracking-wider">Cortes</div>
                           </div>
                           <div className="p-4 text-center hover:bg-barber-800/30 transition-colors">
                              <div className="flex justify-center mb-2 text-green-400"><TrendingUp size={18} /></div>
                              <div className="text-base font-bold text-white">R$ 52</div>
                              <div className="text-[10px] uppercase text-gray-500 font-bold tracking-wider">Ticket Médio</div>
                           </div>
                        </div>

                        {/* Action Footer */}
                        <div className="p-3 bg-barber-950 flex justify-between items-center border-t border-barber-800">
                           <span className="text-xs text-green-500 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                              Online
                           </span>
                           <button onClick={() => handleEditClick(barber)} className="text-xs font-bold text-barber-gold hover:text-white uppercase tracking-wider">Detalhes &rarr;</button>
                        </div>
                     </div>
                  )
               })
            )}
         </div>

         {/* Edit Modal */}
         {editingBarber && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
               <div className="bg-barber-900 w-full max-w-2xl rounded-2xl border border-barber-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
                  <div className="p-6 border-b border-barber-800 flex justify-between items-center bg-barber-950 shrink-0">
                     <div className="flex items-center gap-3">
                        <img src={editingBarber.avatar} className="w-10 h-10 rounded-full border border-barber-700 hidden sm:block" />
                        <div>
                           <h3 className="text-lg font-bold text-white">Gerenciar Profissional</h3>
                           <p className="text-gray-400 text-xs">Ajuste metas e horários de trabalho</p>
                        </div>
                     </div>
                     <button onClick={() => setEditingBarber(null)} className="text-gray-500 hover:text-white p-2">
                        <X size={20} />
                     </button>
                  </div>

                  <div className="p-6 overflow-y-auto space-y-8 flex-1">

                     {/* Financial Settings */}
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-barber-950 p-4 rounded-xl border border-barber-800">
                           <h4 className="text-barber-gold font-bold text-sm mb-4 flex items-center gap-2">
                              <Target size={16} /> Metas & Comissão
                           </h4>
                           <div className="space-y-4">
                              <div>
                                 <label className="text-xs text-gray-400 block mb-1">Meta Financeira Mensal (R$)</label>
                                 <input
                                    type="number"
                                    value={editingBarber.goal}
                                    onChange={(e) => setEditingBarber({ ...editingBarber, goal: Number(e.target.value) })}
                                    className="w-full bg-barber-900 border border-barber-800 rounded-lg p-2 text-white outline-none focus:border-barber-gold"
                                 />
                              </div>
                              <div>
                                 <label className="text-xs text-gray-400 block mb-1">Comissão Base (%)</label>
                                 <input
                                    type="number"
                                    value={editingBarber.commissionRate}
                                    onChange={(e) => setEditingBarber({ ...editingBarber, commissionRate: Number(e.target.value) })}
                                    className="w-full bg-barber-900 border border-barber-800 rounded-lg p-2 text-white outline-none focus:border-barber-gold"
                                 />
                              </div>
                           </div>
                        </div>

                        <div className="bg-barber-950 p-4 rounded-xl border border-barber-800 flex flex-col justify-center text-center">
                           <div className="w-16 h-16 bg-barber-900 rounded-full flex items-center justify-center mx-auto mb-3 border border-barber-800">
                              <Trophy size={32} className="text-yellow-500" />
                           </div>
                           <h5 className="text-white font-bold">Nível Master</h5>
                           <p className="text-xs text-gray-500 mt-1">Este profissional está no topo do ranking. Considere aumentar a meta para estimular.</p>
                        </div>
                     </div>

                     {/* Shifts / Schedule */}
                     <div>
                        <h4 className="text-white font-bold text-sm mb-4 flex items-center gap-2">
                           <Calendar size={16} className="text-blue-500" /> Turnos de Trabalho (Escala)
                        </h4>

                        <div className="bg-barber-950 border border-barber-800 rounded-xl overflow-hidden">
                           {/* Header row hidden on mobile */}
                           <div className="hidden sm:grid grid-cols-[60px_1fr_1fr_1fr] bg-barber-900 p-2 text-xs font-bold text-gray-400 uppercase text-center border-b border-barber-800">
                              <div>Dia</div>
                              <div>Entrada / Saída</div>
                              <div>Pausa (Almoço)</div>
                              <div>Status</div>
                           </div>

                           {editingBarber.workSchedule?.map((day, idx) => (
                              <div key={idx} className={`flex flex-col sm:grid sm:grid-cols-[60px_1fr_1fr_1fr] p-3 items-center border-b border-barber-800 last:border-0 gap-2 sm:gap-0 ${day.active ? 'opacity-100' : 'opacity-40 bg-black/20'}`}>
                                 <div className="flex justify-between w-full sm:w-auto sm:block">
                                    <div className="text-sm font-bold text-center text-white">{daysMap[day.dayOfWeek]}</div>
                                    <div className="sm:hidden">
                                       <button
                                          onClick={() => updateSchedule(idx, 'active', !day.active)}
                                          className={`text-xs px-2 py-0.5 rounded-full font-bold flex items-center justify-center gap-1 ${day.active ? 'bg-green-500/20 text-green-500' : 'bg-red-500/10 text-red-500'
                                             }`}
                                       >
                                          {day.active ? 'Ativo' : 'Folga'}
                                       </button>
                                    </div>
                                 </div>

                                 <div className="flex items-center justify-center gap-2 w-full">
                                    <span className="text-[10px] text-gray-500 sm:hidden uppercase font-bold w-12">Horário:</span>
                                    <input
                                       type="time"
                                       value={day.startTime}
                                       onChange={(e) => updateSchedule(idx, 'startTime', e.target.value)}
                                       disabled={!day.active}
                                       className="bg-barber-900 border border-barber-700 rounded px-1 text-xs text-white outline-none w-20 text-center py-1"
                                    />
                                    <span className="text-gray-500">-</span>
                                    <input
                                       type="time"
                                       value={day.endTime}
                                       onChange={(e) => updateSchedule(idx, 'endTime', e.target.value)}
                                       disabled={!day.active}
                                       className="bg-barber-900 border border-barber-700 rounded px-1 text-xs text-white outline-none w-20 text-center py-1"
                                    />
                                 </div>

                                 <div className="flex items-center justify-center gap-2 w-full">
                                    <span className="text-[10px] text-gray-500 sm:hidden uppercase font-bold w-12">Pausa:</span>
                                    <input
                                       type="time"
                                       value={day.breakStart || ''}
                                       onChange={(e) => updateSchedule(idx, 'breakStart', e.target.value)}
                                       disabled={!day.active}
                                       className="bg-barber-900 border border-barber-700 rounded px-1 text-xs text-white outline-none w-20 text-center py-1"
                                    />
                                    <span className="text-gray-500">-</span>
                                    <input
                                       type="time"
                                       value={day.breakEnd || ''}
                                       onChange={(e) => updateSchedule(idx, 'breakEnd', e.target.value)}
                                       disabled={!day.active}
                                       className="bg-barber-900 border border-barber-700 rounded px-1 text-xs text-white outline-none w-20 text-center py-1"
                                    />
                                 </div>

                                 <div className="hidden sm:flex justify-center">
                                    <button
                                       onClick={() => updateSchedule(idx, 'active', !day.active)}
                                       className={`text-xs px-2 sm:px-3 py-1 rounded-full font-bold flex items-center justify-center gap-1 transition-all w-full sm:w-auto ${day.active
                                          ? 'bg-green-500/20 text-green-500 border border-green-500/50'
                                          : 'bg-red-500/10 text-red-500 border border-red-500/20'
                                          }`}
                                    >
                                       {day.active ? <ToggleRight size={14} /> : <ToggleLeft size={14} />}
                                       <span className="hidden sm:inline">{day.active ? 'Ativo' : 'Folga'}</span>
                                    </button>
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>

                  </div>

                  <div className="p-4 bg-barber-950 border-t border-barber-800 flex justify-end gap-3 shrink-0">
                     <button onClick={() => setEditingBarber(null)} className="px-4 py-2 rounded-lg text-gray-400 hover:text-white font-medium text-sm">Cancelar</button>
                     <button onClick={handleSaveBarber} className="bg-barber-gold hover:bg-barber-goldhover text-black px-6 py-2 rounded-lg font-bold flex items-center gap-2 text-sm">
                        <Check size={18} /> Salvar
                     </button>
                  </div>
               </div>
            </div>
         )}

         {/* Professional Modal */}
         {showProfessionalModal && (
            <ProfessionalModal
               professional={editingProfessional}
               onClose={() => setShowProfessionalModal(false)}
               onSuccess={handleProfessionalSuccess}
            />
         )}
      </div>
   );
};

export default Team;
