import { supabase } from './supabase';
import { format, addMinutes, parse, isWithinInterval, isBefore, isAfter } from 'date-fns';

// =====================================================
// TYPES
// =====================================================

export interface BookingSettings {
    min_advance_hours: number;
    max_advance_days: number;
    buffer_minutes: number;
    allow_same_day: boolean;
    require_payment: boolean;
    api_token: string | null;
    slot_duration_minutes: number;
}

export interface ProfessionalAvailability {
    id: string;
    professional_id: string;
    day_of_week: number;
    start_time: string;
    end_time: string;
    break_start: string | null;
    break_end: string | null;
    is_active: boolean;
}

export interface TimeBlock {
    id: string;
    business_id: string;
    professional_id: string | null;
    start_datetime: string;
    end_datetime: string;
    reason: string | null;
    block_type: string;
}

export interface TimeSlot {
    time: string;
    available: boolean;
    reason?: string;
}

// =====================================================
// HELPER FUNCTIONS
// =====================================================

/**
 * Converte string de tempo "HH:mm" para minutos desde meia-noite
 */
function timeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
}

/**
 * Converte minutos desde meia-noite para string "HH:mm"
 */
function minutesToTime(minutes: number): string {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
}

/**
 * Gera array de slots de tempo entre start e end
 */
function generateTimeSlots(
    startTime: string,
    endTime: string,
    slotDuration: number,
    breakStart?: string | null,
    breakEnd?: string | null
): string[] {
    const slots: string[] = [];
    const startMinutes = timeToMinutes(startTime);
    const endMinutes = timeToMinutes(endTime);
    const breakStartMinutes = breakStart ? timeToMinutes(breakStart) : null;
    const breakEndMinutes = breakEnd ? timeToMinutes(breakEnd) : null;

    for (let minutes = startMinutes; minutes < endMinutes; minutes += slotDuration) {
        // Pular horário de intervalo
        if (breakStartMinutes && breakEndMinutes) {
            if (minutes >= breakStartMinutes && minutes < breakEndMinutes) {
                continue;
            }
        }

        slots.push(minutesToTime(minutes));
    }

    return slots;
}

// =====================================================
// MAIN FUNCTIONS
// =====================================================

/**
 * Busca as configurações de agendamento do negócio
 */
export async function getBookingSettings(businessId: string): Promise<BookingSettings | null> {
    const { data, error } = await supabase
        .from('businesses')
        .select('booking_settings')
        .eq('id', businessId)
        .single();

    if (error || !data) {
        console.error('Error fetching booking settings:', error);
        return null;
    }

    return data.booking_settings as BookingSettings;
}

/**
 * Busca a disponibilidade de um profissional para um dia da semana
 */
export async function getProfessionalAvailability(
    professionalId: string,
    dayOfWeek: number
): Promise<ProfessionalAvailability | null> {
    const { data, error } = await supabase
        .from('professional_availability')
        .select('*')
        .eq('professional_id', professionalId)
        .eq('day_of_week', dayOfWeek)
        .eq('is_active', true)
        .single();

    if (error) {
        console.error('Error fetching professional availability:', error);
        return null;
    }

    return data;
}

/**
 * Busca bloqueios de tempo para uma data específica
 */
export async function getTimeBlocks(
    businessId: string,
    professionalId: string,
    date: string
): Promise<TimeBlock[]> {
    const startOfDay = `${date}T00:00:00`;
    const endOfDay = `${date}T23:59:59`;

    const { data, error } = await supabase
        .from('time_blocks')
        .select('*')
        .eq('business_id', businessId)
        .or(`professional_id.is.null,professional_id.eq.${professionalId}`)
        .lte('start_datetime', endOfDay)
        .gte('end_datetime', startOfDay);

    if (error) {
        console.error('Error fetching time blocks:', error);
        return [];
    }

    return data || [];
}

/**
 * Busca agendamentos existentes para um profissional em uma data
 */
export async function getExistingAppointments(
    professionalId: string,
    date: string
): Promise<any[]> {
    const { data, error } = await supabase
        .from('appointments')
        .select('*')
        .eq('professional_id', professionalId)
        .eq('date', date)
        .in('status', ['pending', 'confirmed']);

    if (error) {
        console.error('Error fetching appointments:', error);
        return [];
    }

    return data || [];
}

/**
 * Verifica se um horário específico está bloqueado
 */
function isTimeBlocked(
    time: string,
    date: string,
    timeBlocks: TimeBlock[]
): boolean {
    const checkDateTime = new Date(`${date}T${time}:00`);

    return timeBlocks.some(block => {
        const blockStart = new Date(block.start_datetime);
        const blockEnd = new Date(block.end_datetime);
        return isWithinInterval(checkDateTime, { start: blockStart, end: blockEnd });
    });
}

/**
 * Verifica se um horário tem conflito com agendamentos existentes
 */
function hasAppointmentConflict(
    time: string,
    durationMinutes: number,
    bufferMinutes: number,
    existingAppointments: any[]
): boolean {
    const slotStart = timeToMinutes(time);
    const slotEnd = slotStart + durationMinutes + bufferMinutes;

    return existingAppointments.some(apt => {
        const aptStart = timeToMinutes(apt.time);
        const aptEnd = aptStart + (apt.duration_minutes || 60) + bufferMinutes;

        // Verifica se há sobreposição
        return (slotStart < aptEnd && slotEnd > aptStart);
    });
}

/**
 * Calcula os slots disponíveis para um profissional em uma data
 */
export async function getAvailableSlots(
    businessId: string,
    professionalId: string,
    date: string,
    serviceDurationMinutes: number
): Promise<TimeSlot[]> {
    // 1. Buscar configurações do negócio
    const settings = await getBookingSettings(businessId);
    if (!settings) {
        return [];
    }

    // 2. Verificar se a data está dentro do período permitido
    const now = new Date();
    const targetDate = new Date(date);
    const minDate = addMinutes(now, settings.min_advance_hours * 60);
    const maxDate = addMinutes(now, settings.max_advance_days * 24 * 60);

    if (isBefore(targetDate, minDate) || isAfter(targetDate, maxDate)) {
        return [];
    }

    // 3. Buscar horário de funcionamento do estabelecimento
    const { data: business, error: businessError } = await supabase
        .from('businesses')
        .select('business_hours')
        .eq('id', businessId)
        .single();

    if (businessError || !business) {
        return [];
    }

    const dayOfWeek = targetDate.getDay();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayKey = dayNames[dayOfWeek];
    const businessHours = business.business_hours?.[dayKey];

    // Se o estabelecimento está fechado neste dia
    if (!businessHours || businessHours.closed) {
        return [];
    }

    // 4. Buscar disponibilidade do profissional para o dia da semana
    const availability = await getProfessionalAvailability(professionalId, dayOfWeek);

    if (!availability) {
        return [];
    }

    // 5. Calcular horário efetivo (interseção entre estabelecimento e profissional)
    const businessOpen = businessHours.open;
    const businessClose = businessHours.close;
    const professionalStart = availability.start_time;
    const professionalEnd = availability.end_time;

    // Usar o horário mais restritivo
    const effectiveStart = timeToMinutes(professionalStart) > timeToMinutes(businessOpen)
        ? professionalStart
        : businessOpen;
    const effectiveEnd = timeToMinutes(professionalEnd) < timeToMinutes(businessClose)
        ? professionalEnd
        : businessClose;

    // Se não há interseção válida
    if (timeToMinutes(effectiveStart) >= timeToMinutes(effectiveEnd)) {
        return [];
    }

    // 6. Buscar buffer do profissional
    const { data: professional } = await supabase
        .from('professionals')
        .select('custom_buffer, buffer_minutes')
        .eq('id', professionalId)
        .single();

    const bufferMinutes = professional?.custom_buffer
        ? (professional.buffer_minutes || 15)
        : (settings.buffer_minutes || 15);

    // 7. Gerar slots base (usando horário efetivo)
    const baseSlots = generateTimeSlots(
        effectiveStart,
        effectiveEnd,
        settings.slot_duration_minutes,
        availability.break_start,
        availability.break_end
    );

    // 8. Buscar bloqueios e agendamentos
    const [timeBlocks, existingAppointments] = await Promise.all([
        getTimeBlocks(businessId, professionalId, date),
        getExistingAppointments(professionalId, date)
    ]);

    // 9. Verificar disponibilidade de cada slot
    const slots: TimeSlot[] = baseSlots.map(time => {
        // Verificar se está bloqueado
        if (isTimeBlocked(time, date, timeBlocks)) {
            return { time, available: false, reason: 'Horário bloqueado' };
        }

        // Verificar conflito com agendamentos (usando buffer do profissional)
        if (hasAppointmentConflict(time, serviceDurationMinutes, bufferMinutes, existingAppointments)) {
            return { time, available: false, reason: 'Horário ocupado' };
        }

        // Verificar se o serviço cabe antes do fim do expediente ou intervalo
        const slotMinutes = timeToMinutes(time);
        const endMinutes = timeToMinutes(effectiveEnd);
        const breakStartMinutes = availability.break_start ? timeToMinutes(availability.break_start) : null;

        if (slotMinutes + serviceDurationMinutes > endMinutes) {
            return { time, available: false, reason: 'Serviço não cabe no horário' };
        }

        if (breakStartMinutes && slotMinutes + serviceDurationMinutes > breakStartMinutes) {
            const breakEndMinutes = availability.break_end ? timeToMinutes(availability.break_end) : breakStartMinutes;
            if (slotMinutes < breakEndMinutes) {
                return { time, available: false, reason: 'Conflito com intervalo' };
            }
        }

        return { time, available: true };
    });

    return slots.filter(slot => slot.available);
}

/**
 * Verifica se um horário específico está disponível
 */
export async function isSlotAvailable(
    businessId: string,
    professionalId: string,
    date: string,
    time: string,
    durationMinutes: number
): Promise<{ available: boolean; reason?: string }> {
    const slots = await getAvailableSlots(businessId, professionalId, date, durationMinutes);
    const slot = slots.find(s => s.time === time);

    if (!slot) {
        return { available: false, reason: 'Horário não encontrado' };
    }

    return { available: slot.available, reason: slot.reason };
}

/**
 * Cria um agendamento público (usado pelo WhatsApp bot e link público)
 */
export async function createPublicAppointment(
    businessId: string,
    appointmentData: {
        professional_id: string;
        service_id: string;
        client_name: string;
        client_phone: string;
        client_email?: string;
        date: string;
        time: string;
        notes?: string;
    }
): Promise<{ success: boolean; appointmentId?: string; error?: string }> {
    try {
        // 1. Buscar informações do serviço
        const { data: service, error: serviceError } = await supabase
            .from('services')
            .select('duration_minutes, price')
            .eq('id', appointmentData.service_id)
            .single();

        if (serviceError || !service) {
            return { success: false, error: 'Serviço não encontrado' };
        }

        // 2. Verificar disponibilidade
        const availability = await isSlotAvailable(
            businessId,
            appointmentData.professional_id,
            appointmentData.date,
            appointmentData.time,
            service.duration_minutes
        );

        if (!availability.available) {
            return { success: false, error: availability.reason || 'Horário não disponível' };
        }

        // 3. Buscar ou criar cliente
        let clientId: string | null = null;

        const { data: existingClient } = await supabase
            .from('clients')
            .select('id')
            .eq('business_id', businessId)
            .eq('phone', appointmentData.client_phone)
            .single();

        if (existingClient) {
            clientId = existingClient.id;
        } else {
            const { data: newClient, error: clientError } = await supabase
                .from('clients')
                .insert({
                    business_id: businessId,
                    name: appointmentData.client_name,
                    phone: appointmentData.client_phone,
                    email: appointmentData.client_email
                })
                .select('id')
                .single();

            if (clientError || !newClient) {
                console.error('Error creating client:', clientError);
                // Continuar sem client_id
            } else {
                clientId = newClient.id;
            }
        }

        // 4. Criar agendamento
        const { data: appointment, error: appointmentError } = await supabase
            .from('appointments')
            .insert({
                business_id: businessId,
                client_id: clientId,
                professional_id: appointmentData.professional_id,
                service_id: appointmentData.service_id,
                date: appointmentData.date,
                time: appointmentData.time,
                status: 'pending',
                payment_status: 'pending',
                amount_paid: service.price,
                notes: appointmentData.notes
            })
            .select('id')
            .single();

        if (appointmentError || !appointment) {
            console.error('Error creating appointment:', appointmentError);
            return { success: false, error: 'Erro ao criar agendamento' };
        }

        return { success: true, appointmentId: appointment.id };

    } catch (error) {
        console.error('Error in createPublicAppointment:', error);
        return { success: false, error: 'Erro interno do servidor' };
    }
}
