
import React, { useState, useEffect, useRef } from 'react';
import {
    ChevronLeft,
    ChevronRight,
    Plus,
    Clock,
    User,
    Filter,
    Ban,
    Search,
    CheckCircle2,
    DollarSign,
    Calendar as CalendarIcon,
    TrendingUp,
    Zap,
    MoreHorizontal,
    Banknote,
    X,
    ShoppingBag,
    Check,
    Lock
} from 'lucide-react';
import {
    format,
    addDays,
    subDays,
    addMonths,
    subMonths,
    startOfWeek,
    endOfWeek,
    eachDayOfInterval,
    isSameDay,
    isToday,
    startOfMonth,
    endOfMonth,
    isSameMonth
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Barber, Appointment, Status, Service, Product, PaymentStatus } from '../types';
import Button from './ui/Button';
import Select from './ui/Select';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Card from './ui/Card';
import Switch from './ui/Switch';
import { useToast } from './ui/Toast';

import { useSupabaseQuery } from '../lib/hooks';
import { fetchProfessionals, fetchServices, fetchProducts, fetchAppointments } from '../lib/database';

interface CalendarProps { }

const Calendar: React.FC<CalendarProps> = () => {
    // === SUPABASE DATA FETCHING (Backend Logic) ===
    const { data: barbersData } = useSupabaseQuery(fetchProfessionals);
    const { data: servicesData } = useSupabaseQuery(fetchServices);
    const { data: productsData } = useSupabaseQuery(fetchProducts);
    const { data: appointmentsData } = useSupabaseQuery(fetchAppointments);

    const barbers = barbersData || [];
    const services = servicesData || [];
    const products = productsData || [];

    // === STATE ===
    const [currentDate, setCurrentDate] = useState(new Date());
    const [miniCalendarMonth, setMiniCalendarMonth] = useState(new Date());
    const [selectedBarberId, setSelectedBarberId] = useState('all');
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    const [selectedSlotTime, setSelectedSlotTime] = useState<string | null>(null);

    // Mobile Sidebar State
    const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

    // New Visual State
    const [highlightFreeSlots, setHighlightFreeSlots] = useState(false);

    // Real-time Clock
    const [currentTime, setCurrentTime] = useState(new Date());

    // Appointments State (from Supabase)
    const [appointments, setAppointments] = useState<Appointment[]>([]);

    // Command State (existing backend logic)
    const [activeCommandApp, setActiveCommandApp] = useState<string | null>(null);

    const toast = useToast();
    const scrollRef = useRef<HTMLDivElement>(null);

    // Sync appointments from Supabase
    useEffect(() => {
        if (appointmentsData) {
            setAppointments(appointmentsData);
        }
    }, [appointmentsData]);

    // Update clock every minute
    useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 60000);
        return () => clearInterval(timer);
    }, [currentDate]);

    // === HANDLERS ===
    const handlePrevMonth = () => setMiniCalendarMonth(subMonths(miniCalendarMonth, 1));
    const handleNextMonth = () => setMiniCalendarMonth(addMonths(miniCalendarMonth, 1));

    const onDateClick = (day: Date) => {
        setCurrentDate(day);
        if (window.innerWidth < 1280) {
            setIsMobileSidebarOpen(false);
        }
    };

    const handleOpenNewAppointment = (time?: string) => {
        setSelectedSlotTime(time || '09:00');
        setIsAppointmentModalOpen(true);
    };

    const handlePrevDay = () => setCurrentDate(subDays(currentDate, 1));
    const handleNextDay = () => setCurrentDate(addDays(currentDate, 1));
    const handleToday = () => {
        const today = new Date();
        setCurrentDate(today);
        setMiniCalendarMonth(today);
    };

    // === EXISTING BACKEND LOGIC ===
    const handleStatusChange = (id: string, newStatus: Status) => {
        setAppointments(prev => prev.map(app =>
            app.id === id ? { ...app, status: newStatus } : app
        ));
    };

    const handleAddToCommand = (productId: string) => {
        if (!activeCommandApp) return;

        const product = products.find(p => p.id === productId);
        if (!product) return;

        setAppointments(prev => prev.map(app => {
            if (app.id === activeCommandApp) {
                const currentConsumption = app.consumption || [];
                return {
                    ...app,
                    consumption: [...currentConsumption, {
                        id: Math.random().toString(),
                        productId: product.id,
                        name: product.name,
                        price: product.price,
                        quantity: 1
                    }]
                };
            }
            return app;
        }));
    };

    // === HELPERS FOR GRID ===
    const startHour = 8;
    const endHour = 20;
    const timeSlots = Array.from({ length: endHour - startHour + 1 }, (_, i) => startHour + i);

    // Mini Calendar Generation
    const generateCalendarGrid = () => {
        const monthStart = startOfMonth(miniCalendarMonth);
        const monthEnd = endOfMonth(monthStart);
        const startDate = startOfWeek(monthStart);
        const endDate = endOfWeek(monthEnd);
        return eachDayOfInterval({ start: startDate, end: endDate });
    };
    const calendarDays = generateCalendarGrid();
    const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

    // === STATS CALCULATION (Cockpit) ===
    const dailyAppointments = appointments.filter(a => isSameDay(new Date(a.start_datetime || a.date), currentDate));
    const dailyRevenue = dailyAppointments.reduce((acc, curr) => {
        if (curr.status === Status.CANCELED || curr.status === Status.BLOCKED) return acc;
        const service = services.find(s => s.id === curr.serviceId);
        return acc + (service?.price || 0);
    }, 0);
    const occupancyRate = Math.round((dailyAppointments.filter(a => a.status !== Status.BLOCKED).length / (timeSlots.length * Math.max(barbers.length, 1))) * 100);

    // === VISUAL HELPERS ===
    const getAppointmentStyles = (status: Status) => {
        switch (status) {
            case Status.CONFIRMED:
                return { border: 'border-l-emerald-500', bg: 'bg-emerald-500/10', text: 'text-emerald-100', icon: CheckCircle2 };
            case Status.COMPLETED:
                return { border: 'border-l-gray-500', bg: 'bg-gray-500/10', text: 'text-gray-400', opacity: 'opacity-70', icon: CheckCircle2 };
            case Status.PENDING:
                return { border: 'border-l-blue-500', bg: 'bg-blue-500/10', text: 'text-blue-100', icon: Clock };
            case Status.CANCELED:
                return { border: 'border-l-red-500', bg: 'bg-red-500/10', text: 'text-red-100', decoration: 'line-through', icon: Ban };
            case Status.BLOCKED:
                return { border: 'border-l-amber-500', bg: 'bg-amber-500/10', text: 'text-amber-100', pattern: true, icon: Ban };
            default:
                return { border: 'border-l-gray-500', bg: 'bg-gray-500/10', text: 'text-gray-200', icon: MoreHorizontal };
        }
    };

    const isBusinessHour = (hour: number) => hour >= 9 && hour < 19;

    // Current Time Line Logic
    const getCurrentTimePosition = () => {
        const now = currentTime;
        if (!isSameDay(now, currentDate)) return null;

        const currentHour = now.getHours();
        const currentMin = now.getMinutes();

        if (currentHour < startHour || currentHour > endHour) return null;

        return { hour: currentHour, percent: (currentMin / 60) * 100 };
    };
    const timeIndicator = getCurrentTimePosition();

    return (
        <div className="flex flex-col xl:flex-row gap-6 h-[calc(100vh-80px)] md:h-[calc(100vh-100px)] animate-fade-in pb-0 md:pb-4 relative">

            {/* === MOBILE OVERLAY (Drawer) === */}
            {isMobileSidebarOpen && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm xl:hidden" onClick={() => setIsMobileSidebarOpen(false)} />
            )}

            {/* === LEFT SIDEBAR (Responsive) === */}
            <div className={`
            fixed inset-y-0 left-0 z-50 w-80 bg-barber-950 border-r border-barber-800 transform transition-transform duration-300 ease-in-out p-6 flex flex-col gap-6 overflow-y-auto
            ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
            xl:translate-x-0 xl:static xl:w-80 xl:p-0 xl:bg-transparent xl:border-0 xl:overflow-visible xl:flex
        `}>
                {/* Mobile Header for Sidebar */}
                <div className="flex items-center justify-between xl:hidden mb-2">
                    <h3 className="text-lg font-bold text-main">Calendário & Filtros</h3>
                    <button onClick={() => setIsMobileSidebarOpen(false)} className="p-2 bg-barber-800 rounded-full text-white">
                        <X size={20} />
                    </button>
                </div>

                {/* 1. Mini Calendar (Navigation) */}
                <Card noPadding className="p-4 bg-barber-950 border-barber-800 shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <button onClick={handlePrevMonth} className="p-1 hover:bg-barber-800 rounded text-muted hover:text-main"><ChevronLeft size={16} /></button>
                        <span className="font-bold text-main capitalize text-sm">
                            {format(miniCalendarMonth, 'MMMM yyyy', { locale: ptBR })}
                        </span>
                        <button onClick={handleNextMonth} className="p-1 hover:bg-barber-800 rounded text-muted hover:text-main"><ChevronRight size={16} /></button>
                    </div>

                    <div className="grid grid-cols-7 mb-2">
                        {weekDays.map((day, idx) => (
                            <div key={idx} className="text-center text-[10px] font-bold text-muted h-6 flex items-center justify-center">
                                {day}
                            </div>
                        ))}
                    </div>

                    <div className="grid grid-cols-7 gap-1">
                        {calendarDays.map((day, idx) => {
                            const isSelected = isSameDay(day, currentDate);
                            const isCurrentMonth = isSameMonth(day, miniCalendarMonth);
                            const isDayToday = isToday(day);
                            const hasEvents = appointments.some(a => isSameDay(new Date(a.start_datetime || a.date), day));

                            return (
                                <button
                                    key={idx}
                                    onClick={() => onDateClick(day)}
                                    className={`
                                    h-8 w-8 rounded-full flex items-center justify-center text-xs font-medium transition-all relative
                                    ${!isCurrentMonth ? 'text-gray-600 opacity-30' : 'text-main'}
                                    ${isSelected ? 'bg-barber-gold text-inverted font-bold shadow-md shadow-amber-500/20 scale-105' : 'hover:bg-barber-800'}
                                    ${isDayToday && !isSelected ? 'border border-barber-gold text-barber-gold' : ''}
                                `}
                                >
                                    {format(day, 'd')}
                                    {hasEvents && !isSelected && (
                                        <span className="absolute bottom-1 w-1 h-1 bg-barber-800 rounded-full"></span>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                </Card>

                {/* 2. "Available Now" Widget (Compact & Operational) */}
                <Card noPadding className="flex-1 min-h-[300px] xl:min-h-0 bg-barber-950 border-barber-800 flex flex-col overflow-hidden shadow-md">
                    <div className="p-4 border-b border-barber-800 bg-barber-900/30">
                        <div className="flex justify-between items-center mb-3">
                            <div className="flex items-center gap-2">
                                <div className="bg-emerald-500/10 p-1.5 rounded-md animate-pulse">
                                    <Zap size={16} className="text-emerald-500" />
                                </div>
                                <div>
                                    <h3 className="font-bold text-main text-sm leading-none">Disponíveis agora</h3>
                                    <span className="text-[10px] text-muted">{format(currentTime, 'HH:mm')} • Tempo Real</span>
                                </div>
                            </div>
                            <button className="p-1.5 text-muted hover:text-white bg-barber-900 rounded border border-barber-800 hover:border-barber-700 transition-colors">
                                <Filter size={14} />
                            </button>
                        </div>

                        {/* Toggle Highlight */}
                        <div className="flex items-center justify-between bg-black/20 p-2 rounded-lg border border-white/5">
                            <span className="text-[10px] text-muted font-bold uppercase tracking-wide">Destacar na Grade</span>
                            <Switch checked={highlightFreeSlots} onCheckedChange={setHighlightFreeSlots} />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-3 space-y-2">
                        {barbers.map((barber, index) => {
                            // Calculate free time based on appointments
                            const now = new Date();
                            const currentHour = now.getHours();
                            const barberTodayAppts = appointments.filter(a => {
                                const profId = a.professional_id || a.barberId;
                                const aptDate = a.start_datetime ? new Date(a.start_datetime) : null;
                                if (!aptDate) return false;
                                return profId === barber.id &&
                                    isSameDay(aptDate, now) &&
                                    aptDate.getHours() >= currentHour;
                            });

                            // Simple logic: find next appointment time or default to end of day
                            const getAptTime = (apt: any) => {
                                if (apt.start_datetime) {
                                    const d = new Date(apt.start_datetime);
                                    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
                                }
                                return apt.time || '00:00';
                            };
                            const sortedAppts = barberTodayAppts.sort((a, b) => getAptTime(a).localeCompare(getAptTime(b)));
                            const nextAppt = sortedAppts[0];
                            const freeUntil = nextAppt ? getAptTime(nextAppt) : '19:00';
                            const nextBusy = nextAppt
                                ? Math.max(0, (parseInt(getAptTime(nextAppt).split(':')[0]) - currentHour) * 60 + (parseInt(getAptTime(nextAppt).split(':')[1] || '0') - now.getMinutes()))
                                : 120;
                            const progressColor = nextBusy > 60 ? 'bg-emerald-500' : 'bg-amber-500';

                            return (
                                <div key={barber.id} className="border border-barber-800 rounded-xl p-3 hover:border-barber-700 transition-all cursor-pointer group bg-barber-900/20 hover:bg-barber-900/60 relative overflow-hidden">
                                    {/* Progress Bar Background */}
                                    <div className="absolute bottom-0 left-0 h-1 bg-barber-800 w-full">
                                        <div className={`h-full ${progressColor}`} style={{ width: `${Math.min(nextBusy, 100)}%` }}></div>
                                    </div>

                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="w-8 h-8 rounded-full bg-barber-800 border border-barber-700 overflow-hidden shrink-0">
                                            {barber.avatar ? <img src={barber.avatar} className="w-full h-full object-cover" /> : <span className="flex items-center justify-center h-full text-xs font-bold">{barber.name[0]}</span>}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex justify-between items-center">
                                                <h4 className="font-bold text-main text-sm truncate">{barber.name}</h4>
                                                <span className="text-[10px] text-emerald-500 font-bold bg-emerald-500/10 px-1.5 rounded">Livre</span>
                                            </div>
                                            <div className="flex items-center gap-1.5 text-[10px] text-muted mt-0.5">
                                                <span>Até {freeUntil}</span>
                                                <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                                                <span>{nextBusy} min livres</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Card>
            </div>

            {/* === MAIN AREA (Cockpit & Timeline) === */}
            <div className="flex-1 flex flex-col bg-input-bg border border-barber-800 rounded-xl overflow-hidden shadow-xl relative h-full">

                {/* 3. Cockpit Header (Stats & Controls) */}
                <div className="flex flex-col border-b border-barber-800 bg-barber-950 z-20 shadow-sm">

                    {/* Top Row: Date & Main Actions */}
                    <div className="p-3 sm:p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 sm:gap-4">
                        <div className="flex items-center justify-between w-full md:w-auto gap-4">
                            <div className="flex items-center gap-3">
                                {/* Mobile Sidebar Toggle */}
                                <button
                                    onClick={() => setIsMobileSidebarOpen(true)}
                                    className="xl:hidden p-2 bg-barber-900 border border-barber-800 rounded-lg text-muted hover:text-white"
                                >
                                    <CalendarIcon size={20} />
                                </button>

                                <div className="flex items-center bg-barber-900 rounded-lg p-1 border border-barber-800 shadow-inner">
                                    <button onClick={handlePrevDay} className="p-1.5 hover:bg-barber-800 rounded text-muted hover:text-white transition-colors"><ChevronLeft size={18} /></button>
                                    <button onClick={handleToday} className="px-3 py-1 text-xs font-bold text-main hover:bg-barber-800 rounded transition-colors uppercase tracking-wider hidden sm:block">Hoje</button>
                                    <button onClick={handleNextDay} className="p-1.5 hover:bg-barber-800 rounded text-muted hover:text-white transition-colors"><ChevronRight size={18} /></button>
                                </div>
                                <div>
                                    <h2 className="text-lg sm:text-xl font-bold text-main capitalize leading-none flex items-center gap-2">
                                        {format(currentDate, 'EEEE, d', { locale: ptBR })}
                                    </h2>
                                    <span className="text-[10px] sm:text-xs text-muted font-medium uppercase tracking-wide">
                                        {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                                    </span>
                                </div>
                            </div>

                            <div className="md:hidden">
                                <Button onClick={() => handleOpenNewAppointment()} size="icon" className="rounded-full w-10 h-10 shadow-lg bg-barber-gold text-black">
                                    <Plus size={20} />
                                </Button>
                            </div>
                        </div>

                        <div className="flex items-center gap-2 sm:gap-3 w-full md:w-auto">
                            <Select
                                value={selectedBarberId}
                                onChange={(e) => setSelectedBarberId(e.target.value)}
                                options={[
                                    { value: 'all', label: 'Todos Profissionais' },
                                    ...barbers.map(b => ({ value: b.id, label: b.name }))
                                ]}
                                className="bg-barber-900 border-barber-800 text-xs h-9 py-0 flex-1 sm:w-48 shadow-sm"
                                icon={<Filter size={12} />}
                            />

                            {/* Desktop Add Button */}
                            <div className="hidden md:block relative group">
                                <Button onClick={() => handleOpenNewAppointment()} size="sm" leftIcon={<Plus size={16} />}>
                                    Novo
                                </Button>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Row: Daily KPIs (Cockpit) - Scrollable on Mobile */}
                    <div className="px-3 sm:px-4 pb-3 flex items-center gap-4 sm:gap-6 overflow-x-auto border-t border-barber-800/50 pt-3 bg-barber-900/30 scrollbar-hide">
                        <div className="flex items-center gap-3 pr-4 sm:pr-6 border-r border-barber-800/50 min-w-fit">
                            <div className="p-1.5 sm:p-2 bg-blue-500/10 rounded-lg text-blue-400"><CalendarIcon size={14} className="sm:w-4 sm:h-4" /></div>
                            <div>
                                <span className="block text-[10px] text-muted uppercase font-bold">Agendamentos</span>
                                <span className="block font-bold text-main text-xs sm:text-sm">{dailyAppointments.length} <span className="text-[10px] text-muted font-normal">hoje</span></span>
                            </div>
                        </div>
                        <div className="flex items-center gap-3 pr-4 sm:pr-6 border-r border-barber-800/50 min-w-fit">
                            <div className="p-1.5 sm:p-2 bg-emerald-500/10 rounded-lg text-emerald-400"><DollarSign size={14} className="sm:w-4 sm:h-4" /></div>
                            <div>
                                <span className="block text-[10px] text-muted uppercase font-bold">Faturamento Prev.</span>
                                <span className="block font-bold text-emerald-400 text-xs sm:text-sm">R$ {dailyRevenue.toFixed(0)}</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-3 min-w-fit">
                            <div className="p-1.5 sm:p-2 bg-amber-500/10 rounded-lg text-amber-400"><TrendingUp size={14} className="sm:w-4 sm:h-4" /></div>
                            <div>
                                <span className="block text-[10px] text-muted uppercase font-bold">Ocupação</span>
                                <span className="block font-bold text-amber-400 text-xs sm:text-sm">{occupancyRate}%</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 4. Timeline Scroll Area */}
                <div className="flex-1 overflow-y-auto relative bg-barber-950 scroll-smooth touch-pan-y" ref={scrollRef}>

                    {timeSlots.map((hour, index) => {
                        const timeString = `${hour.toString().padStart(2, '0')}:00`;

                        // Filter appointments for this slot
                        const slotAppointments = appointments.filter(apt => {
                            // Handle both formats: Supabase (start_datetime) and legacy (date/time)
                            let aptDate: Date;
                            let aptHour: number;

                            if (apt.start_datetime) {
                                aptDate = new Date(apt.start_datetime);
                                aptHour = aptDate.getHours();
                            } else if (apt.date && apt.time) {
                                aptDate = new Date(apt.date);
                                aptHour = parseInt(apt.time.split(':')[0]);
                            } else {
                                return false;
                            }

                            const isCorrectDate = isSameDay(aptDate, currentDate);
                            const isCorrectHour = aptHour === hour;
                            const profId = apt.professional_id || apt.barberId;
                            const isCorrectBarber = selectedBarberId === 'all' || profId === selectedBarberId;
                            return isCorrectDate && isCorrectHour && isCorrectBarber;
                        });

                        // Check if this hour contains the current time line
                        const isCurrentHourSlot = timeIndicator && timeIndicator.hour === hour;

                        // Styling for Business Hours vs Off Hours
                        const isWorkingHour = isBusinessHour(hour);
                        const bgClass = isWorkingHour
                            ? 'bg-transparent'
                            : 'bg-[#000000]/30';

                        return (
                            <div key={hour} className={`group relative flex border-b border-barber-800/40 min-h-[100px] sm:min-h-[120px] transition-colors ${bgClass}`}>

                                {/* Time Column */}
                                <div className="w-12 sm:w-16 py-2 sm:py-3 text-right pr-2 sm:pr-4 shrink-0 border-r border-barber-800/40 relative bg-barber-950/50 backdrop-blur-sm z-10">
                                    <span className={`text-[10px] sm:text-xs font-bold block sticky top-2 transition-colors ${isWorkingHour ? 'text-muted' : 'text-gray-700'}`}>
                                        {timeString}
                                    </span>
                                </div>

                                {/* Content Column */}
                                <div className="flex-1 relative p-1 sm:p-2">

                                    {/* Vertical Grid Lines (for visual rhythm) */}
                                    <div className="absolute inset-y-0 left-0 w-px bg-barber-800/10"></div>
                                    <div className="absolute inset-y-0 left-1/2 w-px bg-barber-800/10"></div>

                                    {/* Current Time Line Indicator */}
                                    {isCurrentHourSlot && (
                                        <div
                                            className="absolute left-0 right-0 h-[2px] bg-red-500 z-10 flex items-center pointer-events-none shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                                            style={{ top: `${timeIndicator.percent}%` }}
                                        >
                                            <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-red-500 -ml-1 sm:-ml-1.5 border-2 border-barber-950"></div>
                                            <div className="absolute left-2 bg-red-500 text-white text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 rounded-r-md shadow-sm">
                                                {format(currentTime, 'HH:mm')}
                                            </div>
                                        </div>
                                    )}

                                    {/* Slot Content Grid */}
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 sm:gap-3 h-full relative z-0">
                                        {slotAppointments.length > 0 ? (
                                            slotAppointments.map(apt => {
                                                const barber = barbers.find(b => b.id === (apt.professional_id || apt.barberId));
                                                const service = services.find(s => s.id === (apt.service_id || apt.serviceId)) || apt.service;
                                                const clientName = apt.customer_name || apt.clientName || apt.client_name || apt.client?.name || 'Cliente';
                                                const aptTime = apt.start_datetime
                                                    ? format(new Date(apt.start_datetime), 'HH:mm')
                                                    : apt.time || '';

                                                // Status Styling
                                                const styles = getAppointmentStyles(apt.status);
                                                const StatusIcon = styles.icon;

                                                return (
                                                    <div
                                                        key={apt.id}
                                                        className={`
                                                        relative rounded-lg border-l-[3px] sm:border-l-[4px] p-2 sm:p-3 transition-all cursor-pointer shadow-sm
                                                        ${styles.border} ${styles.bg} ${styles.opacity || ''}
                                                        active:scale-95 hover:brightness-110 hover:shadow-md hover:-translate-y-0.5
                                                        flex flex-col justify-between
                                                    `}
                                                        style={styles.pattern ? { backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '4px 4px', backgroundOpacity: 0.1 } : {}}
                                                        onClick={() => toast.info(`Detalhes: ${clientName}`)}
                                                    >
                                                        <div>
                                                            <div className="flex justify-between items-start mb-0.5 sm:mb-1">
                                                                <span className={`font-bold text-xs sm:text-sm text-white truncate ${styles.decoration || ''}`}>{clientName}</span>
                                                                <div className="flex gap-1">
                                                                    {/* Payment Badge */}
                                                                    {apt.payment_status !== 'paid' && apt.status !== Status.BLOCKED && (
                                                                        <div title="Pagamento Pendente" className="bg-black/20 p-0.5 rounded text-amber-400"><Banknote size={10} /></div>
                                                                    )}
                                                                </div>
                                                            </div>
                                                            <div className={`text-[10px] sm:text-xs truncate mb-1 sm:mb-2 ${styles.text}`}>
                                                                {apt.status === Status.BLOCKED ? 'Bloqueio de Agenda' : service?.name}
                                                            </div>
                                                        </div>

                                                        <div className="flex items-center justify-between pt-1 sm:pt-2 border-t border-white/5 mt-auto">
                                                            <div className="flex items-center gap-1.5">
                                                                {barber?.avatar ? (
                                                                    <img src={barber.avatar} className="w-3 h-3 sm:w-4 sm:h-4 rounded-full border border-white/10" />
                                                                ) : (
                                                                    <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-white/20 flex items-center justify-center text-[8px]">{barber?.name?.charAt(0) || '?'}</div>
                                                                )}
                                                                <span className="text-[9px] sm:text-[10px] opacity-70 truncate max-w-[60px] sm:max-w-[80px]">{barber?.name?.split(' ')[0] || 'Prof'}</span>
                                                            </div>
                                                            <div className={`text-[9px] sm:text-[10px] uppercase font-bold flex items-center gap-1 ${styles.text}`}>
                                                                <StatusIcon size={10} /> {aptTime}
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })
                                        ) : (
                                            /* Ghost Button on Hover (Touch friendly for mobile) */
                                            <div className={`col-span-full h-full w-full ${isMobileSidebarOpen ? '' : 'flex'} items-center px-2 sm:px-4`}>
                                                <button
                                                    onClick={() => handleOpenNewAppointment(timeString)}
                                                    className={`
                                                    flex items-center gap-2 text-[10px] sm:text-xs font-bold text-barber-gold bg-barber-950/90 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full border border-barber-800 shadow-lg
                                                    opacity-0 group-hover:opacity-100 transition-all duration-200
                                                    ${highlightFreeSlots ? 'opacity-100' : ''}
                                                    active:opacity-100 active:scale-95
                                                `}
                                                >
                                                    <Plus size={12} className="sm:w-3.5 sm:h-3.5" /> Agendar {timeString}
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}

                    {/* Bottom Spacer */}
                    <div className="h-24 flex items-center justify-center text-[10px] sm:text-xs text-muted/30 uppercase font-bold tracking-widest">
                        Fim do Expediente
                    </div>
                </div>
            </div>

            {/* Command Modal (Existing Backend Logic) */}
            {activeCommandApp && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
                    <div className="bg-barber-900 w-full max-w-md rounded-xl border border-barber-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                        <div className="p-4 border-b border-barber-800 flex justify-between items-center bg-barber-950">
                            <h3 className="font-bold text-white flex items-center gap-2">
                                <ShoppingBag className="text-barber-gold" size={18} /> Comanda Digital
                            </h3>
                            <button onClick={() => setActiveCommandApp(null)} className="text-gray-400 hover:text-white"><X size={16} /></button>
                        </div>
                        <div className="p-4 overflow-y-auto flex-1">
                            <p className="text-xs text-gray-400 mb-4 uppercase font-bold">Adicionar Produtos</p>
                            <div className="grid grid-cols-2 gap-3">
                                {products.map(product => (
                                    <button
                                        key={product.id}
                                        onClick={() => handleAddToCommand(product.id)}
                                        className="bg-barber-950 p-3 rounded-lg border border-barber-800 hover:border-barber-gold transition-colors text-left"
                                    >
                                        <div className="text-sm font-bold text-white truncate">{product.name}</div>
                                        <div className="text-xs text-barber-gold">R$ {product.price.toFixed(2)}</div>
                                    </button>
                                ))}
                            </div>

                            <div className="mt-6 border-t border-barber-800 pt-4">
                                <p className="text-xs text-gray-400 mb-2 uppercase font-bold">Consumo Atual</p>
                                {appointments.find(a => a.id === activeCommandApp)?.consumption?.length === 0 ? (
                                    <p className="text-sm text-gray-500 italic">Nenhum item adicionado.</p>
                                ) : (
                                    <ul className="space-y-2">
                                        {appointments.find(a => a.id === activeCommandApp)?.consumption?.map((item, idx) => (
                                            <li key={idx} className="flex justify-between text-sm text-gray-300">
                                                <span>{item.name}</span>
                                                <span>R$ {item.price.toFixed(2)}</span>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        </div>
                        <div className="p-4 bg-barber-950 border-t border-barber-800">
                            <button onClick={() => setActiveCommandApp(null)} className="w-full bg-barber-gold hover:bg-barber-goldhover text-black font-bold py-2 rounded-lg">
                                Concluir
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal for New Appointment */}
            <Modal
                isOpen={isAppointmentModalOpen}
                onClose={() => setIsAppointmentModalOpen(false)}
                title="Novo Agendamento"
                footer={
                    <>
                        <Button variant="ghost" onClick={() => setIsAppointmentModalOpen(false)}>Cancelar</Button>
                        <Button variant="primary" onClick={() => {
                            toast.success('Agendamento criado com sucesso!');
                            setIsAppointmentModalOpen(false);
                        }}>Confirmar</Button>
                    </>
                }
            >
                <div className="space-y-4">
                    <Input label="Nome do Cliente" placeholder="Buscar cliente..." icon={<Search size={16} />} />
                    <div className="grid grid-cols-2 gap-4">
                        <Input label="Data" type="date" defaultValue={format(currentDate, 'yyyy-MM-dd')} />
                        <Input label="Hora" type="time" defaultValue={selectedSlotTime || "09:00"} />
                    </div>
                    <Select
                        label="Profissional"
                        options={barbers.map(b => ({ value: b.id, label: b.name }))}
                    />
                    <Select
                        label="Serviço"
                        options={services.map(s => ({ value: s.id, label: s.name }))}
                    />
                </div>
            </Modal>

        </div>
    );
};

export default Calendar;
