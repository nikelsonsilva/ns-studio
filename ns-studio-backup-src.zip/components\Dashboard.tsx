import React, { useState } from 'react';
import {
  TrendingUp,
  Users,
  Scissors,
  AlertCircle,
  MessageCircle,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  Target,
  DollarSign,
  Settings as SettingsIcon,
  Loader2,
  Calendar,
  Bell,
  ChevronRight,
  RefreshCw,
  ExternalLink,
  Plus,
  Zap,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { SystemSettings } from '../types';
import { useDashboardData } from '../lib/hooks/useDashboardData';

// UI Components (Design System)
import Card from './ui/Card';
import Button from './ui/Button';
import { useToast } from './ui/Toast';

interface DashboardProps {
  settings?: SystemSettings;
  onGoToSettings?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ settings, onGoToSettings }) => {
  const toast = useToast();
  const [viewMode, setViewMode] = useState<'resumo' | 'aovivo'>('aovivo');
  const [chairFilter, setChairFilter] = useState<'all' | 'free' | 'busy'>('all');

  // Fetch real data from database
  const { stats, chairs, weeklyRevenue, monthlyGoal, pendingRequests, isLoading, error, refresh } = useDashboardData();

  const goalProgress = monthlyGoal.target > 0 ? (monthlyGoal.current / monthlyGoal.target) * 100 : 0;

  // Filter chairs based on selection
  const filteredChairs = chairs.filter(chair => {
    if (chairFilter === 'all') return true;
    if (chairFilter === 'free') return chair.status === 'free';
    if (chairFilter === 'busy') return chair.status === 'busy';
    return true;
  });

  const busyCount = chairs.filter(c => c.status === 'busy').length;
  const freeCount = chairs.filter(c => c.status === 'free').length;

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 text-barber-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fade-in pb-20">

      {/* ═══════════════════════════════════════════════════════════════════
          TOPBAR - Estado + Ações
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Calendar size={16} className="text-barber-gold" />
            <span className="font-bold text-white text-lg">Hoje</span>
            <span className="text-gray-500 text-sm">
              {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'short' })}
            </span>
          </div>

          {/* Mode Toggle */}
          <div className="flex bg-barber-900 border border-barber-800 rounded-lg p-1">
            <button
              onClick={() => setViewMode('resumo')}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-colors ${viewMode === 'resumo' ? 'bg-barber-800 text-white' : 'text-gray-500 hover:text-white'
                }`}
            >
              Resumo
            </button>
            <button
              onClick={() => setViewMode('aovivo')}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-colors flex items-center gap-1.5 ${viewMode === 'aovivo' ? 'bg-green-500/20 text-green-400' : 'text-gray-500 hover:text-white'
                }`}
            >
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
              Ao vivo
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => refresh()}
            className="text-gray-500 hover:text-white p-2 rounded-lg hover:bg-barber-900 transition-colors"
            title="Atualizar"
          >
            <RefreshCw size={16} />
          </button>
          <button className="flex items-center gap-2 bg-barber-gold hover:bg-barber-goldhover text-black px-4 py-2 rounded-lg text-sm font-bold transition-colors">
            <Plus size={16} /> Novo Agendamento
          </button>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          KPIs - 4 Cards no topo (altura 96-110px)
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receita */}
        <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-green-500" />
          <div className="flex items-center gap-2 mb-2">
            <DollarSign size={16} className="text-green-500" />
            <span className="text-xs text-gray-400 uppercase">Receita Hoje</span>
          </div>
          <div className="text-2xl font-bold text-green-400">
            R$ {stats.faturamentoHoje.toLocaleString('pt-BR')}
          </div>
        </div>

        {/* Agendamentos */}
        <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-blue-500" />
          <div className="flex items-center gap-2 mb-2">
            <Calendar size={16} className="text-blue-400" />
            <span className="text-xs text-gray-400 uppercase">Agendamentos</span>
          </div>
          <div className="text-2xl font-bold text-white">{stats.agendamentosHoje}</div>
        </div>

        {/* Pendentes */}
        <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500" />
          <div className="flex items-center gap-2 mb-2">
            <Clock size={16} className="text-yellow-500" />
            <span className="text-xs text-gray-400 uppercase">Pendentes</span>
          </div>
          <div className={`text-2xl font-bold ${stats.agendamentosPendentes > 0 ? 'text-yellow-400' : 'text-white'}`}>
            {stats.agendamentosPendentes}
          </div>
        </div>

        {/* No-Show */}
        <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-red-500" />
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle size={16} className="text-red-400" />
            <span className="text-xs text-gray-400 uppercase">No-Show (30d)</span>
          </div>
          <div className={`text-2xl font-bold ${stats.taxaNoShow > 5 ? 'text-red-400' : 'text-white'}`}>
            {stats.taxaNoShow.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          MAIN GRID: 2 Colunas (8 + 4)
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-12 gap-5">

        {/* ══════════ MAIN COLUMN (8 cols) ══════════ */}
        <div className="col-span-12 lg:col-span-8 space-y-5">

          {/* Próximos 60 min + Cadeiras (lado a lado) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* PRÓXIMOS 60 MIN */}
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-white flex items-center gap-2 text-sm">
                  <Clock size={14} className="text-blue-400" />
                  Próximos 60 min
                </h3>
                <button className="text-xs text-barber-gold hover:underline font-medium">
                  Ver agenda →
                </button>
              </div>

              {pendingRequests.length > 0 ? (
                <div className="space-y-1">
                  {pendingRequests.slice(0, 4).map((apt) => (
                    <div key={apt.id} className="flex items-center gap-3 py-2.5 px-3 bg-barber-950 rounded-xl border border-barber-800">
                      <span className="font-bold text-white text-sm w-12">{apt.time}</span>
                      <div className="flex-1 min-w-0">
                        <span className="text-sm text-gray-300 truncate block">{apt.clientName}</span>
                        <span className="text-xs text-gray-500">{apt.service}</span>
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${apt.source === 'pending'
                          ? 'text-yellow-400'
                          : 'text-green-400'
                        }`}>
                        {apt.source === 'pending' ? 'Pendente' : 'Confirmado'}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Clock size={24} className="mx-auto mb-2 opacity-30" />
                  <p className="text-xs">Nenhum agendamento próximo</p>
                </div>
              )}
            </div>

            {/* CADEIRAS */}
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-white flex items-center gap-2 text-sm">
                  <Users size={14} className="text-barber-gold" />
                  Cadeiras
                  {viewMode === 'aovivo' && (
                    <span className="text-[9px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded-full font-bold">
                      AO VIVO
                    </span>
                  )}
                </h3>
                <div className="text-xs text-gray-500">
                  {freeCount} livres · {busyCount} ocupadas
                </div>
              </div>

              <div className="space-y-2">
                {filteredChairs.slice(0, 4).map((chair) => {
                  const isBusy = chair.status === 'busy';
                  const isBreak = chair.status === 'break';
                  const remaining = (chair.duration || 0) - (chair.elapsed || 0);

                  return (
                    <div
                      key={chair.id}
                      className="flex items-center justify-between py-3 px-3 bg-barber-950 rounded-xl border border-barber-800 hover:border-barber-700 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full shrink-0 ${isBusy ? 'bg-red-500' : isBreak ? 'bg-yellow-500' : 'bg-green-500'
                          }`} />
                        <div>
                          <span className="font-bold text-white text-sm">{chair.name}</span>
                          {isBusy && (
                            <p className="text-xs text-gray-500">{chair.currentService}</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {isBusy ? (
                          <span className="text-xs text-red-400 font-medium">
                            termina {remaining}min
                          </span>
                        ) : (
                          <>
                            <span className="text-xs text-green-400 font-medium">Livre</span>
                            <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1 bg-barber-gold text-black rounded hover:bg-barber-goldhover" title="Encaixe">
                              <Zap size={12} />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {filteredChairs.length === 0 && (
                <div className="text-center py-6 text-gray-500">
                  <Users size={24} className="mx-auto mb-1 opacity-30" />
                  <p className="text-xs">Nenhuma cadeira</p>
                </div>
              )}
            </div>
          </div>

          {/* GRÁFICO RECEITA SEMANAL (Modo Resumo) */}
          {viewMode === 'resumo' && (
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-white flex items-center gap-2 text-sm">
                  <TrendingUp size={14} className="text-blue-400" />
                  Receita Semanal
                </h3>
                <select className="bg-barber-950 border border-barber-800 text-xs text-gray-400 rounded-lg px-2 py-1 outline-none">
                  <option>Esta Semana</option>
                  <option>Mês</option>
                </select>
              </div>
              <div className="h-40 w-full" style={{ minWidth: 0 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyRevenue}>
                    <XAxis
                      dataKey="name"
                      stroke="#71717a"
                      tick={{ fill: '#71717a', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#71717a"
                      tick={{ fill: '#71717a', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(value) => `R$${value}`}
                      width={50}
                    />
                    <Tooltip
                      cursor={{ fill: '#27272a' }}
                      contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff', fontSize: 12 }}
                    />
                    <Bar dataKey="total" radius={[6, 6, 0, 0]}>
                      {weeklyRevenue.map((entry, index) => {
                        const isToday = entry.date === new Date().toISOString().split('T')[0];
                        const hasValue = entry.total > 0;
                        return (
                          <Cell
                            key={`cell-${index}`}
                            fill={isToday ? '#f59e0b' : hasValue ? '#3b82f6' : '#3f3f46'}
                          />
                        );
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* CARDS SECUNDÁRIOS */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Users size={12} className="text-blue-400" />
                <span className="text-[10px] text-gray-500 uppercase">Novos Clientes</span>
              </div>
              <div className="text-lg font-bold text-white">{stats.novosClientesMes}</div>
            </div>

            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp size={12} className="text-green-400" />
                <span className="text-[10px] text-gray-500 uppercase">Média/Dia</span>
              </div>
              <div className="text-lg font-bold text-white">R$ {monthlyGoal.dailyAverage.toFixed(0)}</div>
            </div>

            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Scissors size={12} className="text-barber-gold" />
                <span className="text-[10px] text-gray-500 uppercase">Concluídos</span>
              </div>
              <div className="text-lg font-bold text-white">{stats.agendamentosHoje - stats.agendamentosPendentes}</div>
            </div>

            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Target size={12} className="text-purple-400" />
                <span className="text-[10px] text-gray-500 uppercase">Projeção</span>
              </div>
              <div className="text-lg font-bold text-white">R$ {(monthlyGoal.projection / 1000).toFixed(1)}k</div>
            </div>
          </div>
        </div>

        {/* ══════════ SIDEBAR (4 cols) ══════════ */}
        <div className="col-span-12 lg:col-span-4 space-y-4">

          {/* SOLICITAÇÕES PENDENTES */}
          <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="text-green-500" size={14} />
                <h3 className="font-bold text-white text-sm">Solicitações</h3>
              </div>
              {pendingRequests.length > 0 && (
                <span className="bg-barber-gold text-black text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {pendingRequests.length}
                </span>
              )}
            </div>

            {pendingRequests.length > 0 ? (
              <div className="space-y-2">
                {pendingRequests.slice(0, 3).map((req) => (
                  <div key={req.id} className="flex items-center gap-3 py-3 px-3 bg-barber-950 rounded-xl border border-barber-800 group">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm truncate">{req.clientName}</span>
                        <span className="text-barber-gold text-xs font-bold">{req.time}</span>
                      </div>
                      <p className="text-xs text-gray-500 truncate">{req.service}</p>
                    </div>
                    <div className="flex gap-1.5 opacity-70 group-hover:opacity-100 transition-opacity">
                      <button
                        className="p-1.5 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                        title="Confirmar"
                      >
                        <CheckCircle2 size={12} />
                      </button>
                      <button
                        className="p-1.5 bg-barber-800 hover:bg-barber-700 text-white rounded-lg transition-colors"
                        title="Reagendar"
                      >
                        <RefreshCw size={12} />
                      </button>
                    </div>
                  </div>
                ))}

                {pendingRequests.length > 3 && (
                  <button className="w-full py-2 text-center text-barber-gold text-xs font-bold hover:underline">
                    Ver todas ({pendingRequests.length}) →
                  </button>
                )}
              </div>
            ) : (
              <div className="bg-barber-950 p-4 rounded-xl border border-barber-800 border-dashed text-center">
                <CheckCircle2 size={20} className="mx-auto mb-1 text-green-500/50" />
                <p className="text-gray-500 text-xs">Nenhuma pendência!</p>
              </div>
            )}
          </div>

          {/* META MENSAL (compacta na sidebar) */}
          {settings?.modules.finance && (
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="text-barber-gold" size={14} />
                  <span className="font-bold text-white text-sm">Meta {monthlyGoal.periodLabel}</span>
                </div>
                <span className="text-green-400 text-xs font-bold">{goalProgress.toFixed(0)}%</span>
              </div>

              <div className="h-2 w-full bg-barber-950 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-gradient-to-r from-green-600 to-green-400 rounded-full transition-all duration-1000"
                  style={{ width: `${Math.min(goalProgress, 100)}%` }}
                />
              </div>

              <div className="flex justify-between text-xs">
                <span className="text-white font-bold">R$ {monthlyGoal.current.toLocaleString('pt-BR')}</span>
                <span className="text-gray-500">/ {monthlyGoal.target.toLocaleString('pt-BR')}</span>
              </div>
            </div>
          )}

          {/* AÇÕES RÁPIDAS */}
          <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4">
            <h3 className="font-bold text-white text-sm mb-3 flex items-center gap-2">
              <ArrowRight size={12} className="text-barber-gold" />
              Ações Rápidas
            </h3>
            <div className="space-y-2">
              <button className="w-full flex items-center justify-between py-2.5 px-3 bg-barber-950 rounded-xl border border-barber-800 hover:border-barber-700 transition-colors group text-sm">
                <div className="flex items-center gap-2">
                  <Calendar size={12} className="text-blue-400" />
                  <span className="text-white">Abrir Agenda</span>
                </div>
                <ChevronRight size={12} className="text-gray-500 group-hover:text-white" />
              </button>
              <button className="w-full flex items-center justify-between py-2.5 px-3 bg-barber-950 rounded-xl border border-barber-800 hover:border-barber-700 transition-colors group text-sm">
                <div className="flex items-center gap-2">
                  <ExternalLink size={12} className="text-barber-gold" />
                  <span className="text-white">Link Público</span>
                </div>
                <ChevronRight size={12} className="text-gray-500 group-hover:text-white" />
              </button>
            </div>
          </div>

          {/* IA INSIGHT */}
          {settings?.aiConfig.enableInsights && (
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-4 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-blue-500" />
              <div className="flex items-start gap-3">
                <div className="bg-barber-950 p-2 rounded-full shrink-0">
                  <Sparkles size={12} className="text-barber-gold" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold text-xs mb-1">IA Insight</h4>
                  <p className="text-gray-400 text-xs leading-relaxed">
                    Sábado representa 30% do seu faturamento. Considere abrir 1h mais cedo.
                  </p>
                  <button
                    onClick={() => toast.info('Em breve')}
                    className="text-barber-gold text-xs font-bold hover:underline mt-2"
                  >
                    Ver mais →
                  </button>
                </div>
              </div>
            </div>
          )}

          {!settings?.aiConfig.enableInsights && (
            <div className="bg-barber-900 border border-barber-800 rounded-2xl p-3 flex justify-between items-center opacity-70 hover:opacity-100 transition-opacity">
              <span className="text-xs text-gray-400">IA desativada</span>
              <button onClick={onGoToSettings} className="text-xs bg-barber-950 px-3 py-1 rounded-lg text-white flex items-center gap-1">
                <SettingsIcon size={10} /> Ativar
              </button>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};

export default Dashboard;
