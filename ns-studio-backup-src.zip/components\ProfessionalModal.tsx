import React, { useState, useEffect, useRef } from 'react';
import { X, UserPlus, Clock, Target, Percent, ChevronRight, ChevronLeft, Check, Calendar, AlertCircle, CheckCircle, Copy, RotateCcw, Scissors, HelpCircle, Pencil, Trash2 } from 'lucide-react';
import { createProfessional, updateProfessional, getCurrentBusinessId } from '../lib/database';
import { supabase } from '../lib/supabase';
import { validatePhone, validateEmailComplete, normalizeEmail } from '../lib/validation';
import type { Professional } from '../types';

interface ProfessionalModalProps {
    professional?: Professional | null;
    onClose: () => void;
    onSuccess: () => void;
}

interface DaySchedule {
    day_of_week: number;
    start_time: string;
    end_time: string;
    break_start: string | null;
    break_end: string | null;
    is_active: boolean;
}

const SPECIALTY_CHIPS = ['Corte', 'Barba', 'Sobrancelha', 'Coloração', 'Tratamentos', 'Infantil'];
const BREAK_PRESETS = ['30m', '45m', '1h', '1h30'];

const ProfessionalModal: React.FC<ProfessionalModalProps> = ({ professional, onClose, onSuccess }) => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        specialty: '',
        selectedSpecialties: [] as string[],
        commission_rate: 50,
        monthly_goal: 5000,
        buffer_minutes: 15,
        custom_buffer: false,
    });

    const [schedule, setSchedule] = useState<DaySchedule[]>([
        { day_of_week: 0, start_time: '09:00', end_time: '19:00', break_start: null, break_end: null, is_active: false },
        { day_of_week: 1, start_time: '09:00', end_time: '19:00', break_start: '12:00', break_end: '13:00', is_active: true },
        { day_of_week: 2, start_time: '09:00', end_time: '19:00', break_start: '12:00', break_end: '13:00', is_active: true },
        { day_of_week: 3, start_time: '09:00', end_time: '19:00', break_start: '12:00', break_end: '13:00', is_active: true },
        { day_of_week: 4, start_time: '09:00', end_time: '19:00', break_start: '12:00', break_end: '13:00', is_active: true },
        { day_of_week: 5, start_time: '09:00', end_time: '19:00', break_start: '12:00', break_end: '13:00', is_active: true },
        { day_of_week: 6, start_time: '09:00', end_time: '19:00', break_start: null, break_end: null, is_active: false },
    ]);

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [currentStep, setCurrentStep] = useState<1 | 2>(1);
    const [phoneValidation, setPhoneValidation] = useState<{ valid: boolean; message?: string }>({ valid: true });
    const [emailValidation, setEmailValidation] = useState<{ valid: boolean; message?: string }>({ valid: true });
    const [hasChanges, setHasChanges] = useState(false);
    const [fieldErrors, setFieldErrors] = useState<{ name?: string; specialty?: string }>({});
    const [editingPauseDay, setEditingPauseDay] = useState<number | null>(null);
    const [tempPause, setTempPause] = useState({ start: '12:00', end: '13:00' });

    const nameInputRef = useRef<HTMLInputElement>(null);
    const specialtyInputRef = useRef<HTMLInputElement>(null);

    const dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    const dayNamesFull = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

    useEffect(() => {
        if (professional) {
            const specialties = professional.specialty?.split(',').map(s => s.trim()).filter(Boolean) || [];
            setFormData({
                name: professional.name,
                email: professional.email || '',
                phone: professional.phone || '',
                specialty: professional.specialty || '',
                selectedSpecialties: specialties,
                commission_rate: professional.commission_rate || 50,
                monthly_goal: professional.monthly_goal || 5000,
                buffer_minutes: professional.buffer_minutes || 15,
                custom_buffer: professional.custom_buffer || false,
            });
            loadProfessionalSchedule(professional.id);
        }
    }, [professional]);

    const loadProfessionalSchedule = async (professionalId: string) => {
        const { data } = await supabase
            .from('professional_availability')
            .select('*')
            .eq('professional_id', professionalId)
            .order('day_of_week');

        if (data && data.length > 0) {
            const loadedSchedule = schedule.map(day => {
                const found = data.find(d => d.day_of_week === day.day_of_week);
                return found ? {
                    day_of_week: found.day_of_week,
                    start_time: found.start_time,
                    end_time: found.end_time,
                    break_start: found.break_start,
                    break_end: found.break_end,
                    is_active: found.is_active
                } : day;
            });
            setSchedule(loadedSchedule);
        }
    };

    const handleSubmit = async () => {
        setIsLoading(true);
        setError('');

        try {
            const businessId = await getCurrentBusinessId();
            if (!businessId) throw new Error('Business ID not found');

            let professionalId: string;
            const specialtyString = formData.selectedSpecialties.join(', ');

            const dataToSend = {
                name: formData.name,
                specialty: specialtyString || formData.specialty,
                commission_rate: formData.commission_rate,
                monthly_goal: formData.monthly_goal,
                buffer_minutes: formData.buffer_minutes,
                custom_buffer: formData.custom_buffer,
                is_active: true,
                business_id: businessId,
                ...(formData.email && { email: formData.email }),
                ...(formData.phone && { phone: formData.phone }),
            };

            if (professional) {
                await updateProfessional(professional.id, dataToSend);
                professionalId = professional.id;
            } else {
                const result = await createProfessional(dataToSend);
                if (!result || !result.id) throw new Error('Failed to create professional');
                professionalId = result.id;
            }

            await supabase.from('professional_availability').delete().eq('professional_id', professionalId);

            const scheduleData = schedule.map(day => ({
                business_id: businessId,
                professional_id: professionalId,
                day_of_week: day.day_of_week,
                start_time: day.start_time,
                end_time: day.end_time,
                break_start: day.break_start,
                break_end: day.break_end,
                is_active: day.is_active
            }));

            await supabase.from('professional_availability').insert(scheduleData);

            onSuccess();
            onClose();
        } catch (err: any) {
            setError(err.message || 'Erro ao salvar profissional');
        } finally {
            setIsLoading(false);
        }
    };

    // Phone formatting
    const formatPhone = (value: string) => {
        const digits = value.replace(/\D/g, '');
        if (digits.length <= 2) return `(${digits}`;
        if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
        return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
    };

    const handlePhoneChange = async (value: string) => {
        const formatted = formatPhone(value);
        setFormData({ ...formData, phone: formatted });
        setHasChanges(true);
        if (formatted.replace(/\D/g, '').length > 0) {
            const validation = await validatePhone(formatted);
            setPhoneValidation(validation);
        } else {
            setPhoneValidation({ valid: true });
        }
    };

    const handleEmailChange = async (value: string) => {
        setFormData({ ...formData, email: value });
        setHasChanges(true);
        if (value.trim()) {
            const validation = await validateEmailComplete(value);
            setEmailValidation(validation);
        } else {
            setEmailValidation({ valid: true });
        }
    };

    const handleNext = () => {
        const errors: { name?: string; specialty?: string } = {};

        if (!formData.name.trim()) {
            errors.name = 'Campo obrigatório';
        }
        if (!formData.specialty.trim() && formData.selectedSpecialties.length === 0) {
            errors.specialty = 'Selecione ao menos uma especialidade';
        }
        if (formData.phone && !phoneValidation.valid) {
            setError('Corrija o telefone antes de continuar');
            return;
        }
        if (formData.email && !emailValidation.valid) {
            setError('Corrija o email antes de continuar');
            return;
        }

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            if (errors.name) nameInputRef.current?.focus();
            else if (errors.specialty) specialtyInputRef.current?.focus();
            return;
        }

        setFieldErrors({});
        setError('');
        setCurrentStep(2);
    };

    const updateSchedule = (index: number, field: keyof DaySchedule, value: any) => {
        const newSchedule = [...schedule];
        newSchedule[index] = { ...newSchedule[index], [field]: value };
        setSchedule(newSchedule);
        setHasChanges(true);
    };

    // Specialty chip selection
    const toggleSpecialty = (chip: string) => {
        const current = [...formData.selectedSpecialties];
        const idx = current.findIndex(s => s.toLowerCase() === chip.toLowerCase());
        if (idx >= 0) {
            current.splice(idx, 1);
        } else {
            current.push(chip);
        }
        setFormData({ ...formData, selectedSpecialties: current, specialty: current.join(', ') });
        setHasChanges(true);
        if (fieldErrors.specialty) setFieldErrors({ ...fieldErrors, specialty: undefined });
    };

    // Schedule Actions
    const copyFromMonday = () => {
        const monday = schedule[1];
        const newSchedule = schedule.map((day, idx) =>
            idx === 0 || idx === 6 ? day : {
                ...monday,
                day_of_week: day.day_of_week
            }
        );
        setSchedule(newSchedule);
    };

    const applyMondayToAll = () => {
        const monday = schedule[1];
        const newSchedule = schedule.map(day => ({
            ...monday,
            day_of_week: day.day_of_week
        }));
        setSchedule(newSchedule);
    };

    const clearSchedule = () => {
        const newSchedule = schedule.map(day => ({
            ...day,
            is_active: false,
            break_start: null,
            break_end: null
        }));
        setSchedule(newSchedule);
    };

    // Pause editing
    const openPauseEditor = (dayIndex: number) => {
        const day = schedule[dayIndex];
        setTempPause({
            start: day.break_start || '12:00',
            end: day.break_end || '13:00'
        });
        setEditingPauseDay(dayIndex);
    };

    const savePause = () => {
        if (editingPauseDay === null) return;
        // Validate pause times
        const startMinutes = parseInt(tempPause.start.split(':')[0]) * 60 + parseInt(tempPause.start.split(':')[1]);
        const endMinutes = parseInt(tempPause.end.split(':')[0]) * 60 + parseInt(tempPause.end.split(':')[1]);
        if (endMinutes <= startMinutes) {
            return; // Invalid
        }
        updateSchedule(editingPauseDay, 'break_start', tempPause.start);
        updateSchedule(editingPauseDay, 'break_end', tempPause.end);
        setEditingPauseDay(null);
    };

    const removePause = () => {
        if (editingPauseDay === null) return;
        updateSchedule(editingPauseDay, 'break_start', null);
        updateSchedule(editingPauseDay, 'break_end', null);
        setEditingPauseDay(null);
    };

    const applyPreset = (preset: string) => {
        const durationMap: Record<string, number> = { '30m': 30, '45m': 45, '1h': 60, '1h30': 90 };
        const duration = durationMap[preset] || 60;
        const startMinutes = parseInt(tempPause.start.split(':')[0]) * 60 + parseInt(tempPause.start.split(':')[1]);
        const endMinutes = startMinutes + duration;
        const endHour = Math.floor(endMinutes / 60).toString().padStart(2, '0');
        const endMin = (endMinutes % 60).toString().padStart(2, '0');
        setTempPause({ ...tempPause, end: `${endHour}:${endMin}` });
    };

    const handleClose = () => {
        if (hasChanges) {
            if (confirm('Descartar mudanças?')) {
                onClose();
            }
        } else {
            onClose();
        }
    };

    // Stats calculation
    const activeDays = schedule.filter(d => d.is_active);
    const weeklyHours = activeDays.reduce((acc, day) => {
        const [startH, startM] = day.start_time.split(':').map(Number);
        const [endH, endM] = day.end_time.split(':').map(Number);
        const hours = (endH * 60 + endM - startH * 60 - startM) / 60;
        const breakHours = day.break_start && day.break_end ?
            (() => {
                const [bs, bsm] = day.break_start.split(':').map(Number);
                const [be, bem] = day.break_end.split(':').map(Number);
                return (be * 60 + bem - bs * 60 - bsm) / 60;
            })() : 0;
        return acc + hours - breakHours;
    }, 0);

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-barber-900 w-full max-w-[720px] rounded-2xl border border-barber-800 shadow-2xl overflow-hidden flex flex-col" style={{ maxHeight: 'min(78vh, 680px)' }}>
                {/* Header */}
                <div className="p-6 border-b border-barber-800 shrink-0">
                    <div className="flex justify-between items-start">
                        <div>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-barber-gold/20 flex items-center justify-center">
                                    <UserPlus className="text-barber-gold" size={20} />
                                </div>
                                <div>
                                    <h3 className="text-lg font-bold text-white">
                                        {professional ? 'Editar Profissional' : 'Novo Profissional'}
                                    </h3>
                                    <p className="text-xs text-gray-500">Cadastre dados e jornada</p>
                                </div>
                            </div>
                        </div>
                        <button
                            onClick={handleClose}
                            className="p-2 text-gray-500 hover:text-white hover:bg-barber-800 rounded-lg transition-colors"
                            title="Fechar"
                        >
                            <X size={20} />
                        </button>
                    </div>

                    {/* Stepper */}
                    <div className="flex justify-center gap-16 mt-6">
                        <div className="flex flex-col items-center">
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${currentStep > 1 ? 'bg-barber-gold text-black' :
                                    currentStep === 1 ? 'bg-barber-gold text-black ring-4 ring-barber-gold/20' :
                                        'bg-barber-800 text-gray-500'
                                }`}>
                                {currentStep > 1 ? <Check size={16} /> : '1'}
                            </div>
                            <span className={`text-[10px] mt-2 font-bold uppercase tracking-widest ${currentStep >= 1 ? 'text-barber-gold' : 'text-gray-600'
                                }`}>Dados</span>
                        </div>

                        <div className="flex items-center -mt-4">
                            <div className={`w-16 h-0.5 ${currentStep > 1 ? 'bg-barber-gold' : 'bg-barber-800'}`} />
                        </div>

                        <div className="flex flex-col items-center">
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${currentStep === 2 ? 'bg-barber-gold text-black ring-4 ring-barber-gold/20' :
                                    'border-2 border-barber-700 bg-transparent text-gray-500'
                                }`}>
                                2
                            </div>
                            <span className={`text-[10px] mt-2 font-bold uppercase tracking-widest ${currentStep === 2 ? 'text-barber-gold' : 'text-gray-600'
                                }`}>Jornada</span>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6">
                    {error && (
                        <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-sm p-3 rounded-xl mb-4 flex items-center gap-2">
                            <AlertCircle size={16} />
                            {error}
                        </div>
                    )}

                    {/* Step 1: DADOS */}
                    {currentStep === 1 && (
                        <div className="space-y-5">
                            {/* Row 1: Nome + Especialidade */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold">
                                        Nome Completo <span className="text-red-400">*</span>
                                    </label>
                                    <input
                                        ref={nameInputRef}
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => {
                                            setFormData({ ...formData, name: e.target.value });
                                            setHasChanges(true);
                                            if (fieldErrors.name) setFieldErrors({ ...fieldErrors, name: undefined });
                                        }}
                                        className={`w-full bg-barber-950 border text-white rounded-xl px-4 h-11 text-sm outline-none transition-all ${fieldErrors.name
                                                ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                                                : 'border-barber-800 focus:border-barber-gold focus:ring-2 focus:ring-barber-gold/20'
                                            }`}
                                        placeholder="Ex: Carlos Silva"
                                    />
                                    {fieldErrors.name && (
                                        <p className="text-red-400 text-[11px] mt-1 flex items-center gap-1">
                                            <AlertCircle size={10} /> {fieldErrors.name}
                                        </p>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold">
                                        Especialidade <span className="text-red-400">*</span>
                                    </label>
                                    <div className={`w-full bg-barber-950 border rounded-xl px-3 py-2 min-h-[44px] flex flex-wrap gap-1.5 items-center ${fieldErrors.specialty
                                            ? 'border-red-500'
                                            : 'border-barber-800 focus-within:border-barber-gold focus-within:ring-2 focus-within:ring-barber-gold/20'
                                        }`}>
                                        {formData.selectedSpecialties.map(spec => (
                                            <span
                                                key={spec}
                                                className="px-2 py-0.5 bg-barber-gold/20 text-barber-gold text-xs font-medium rounded-md border border-barber-gold/30 flex items-center gap-1"
                                            >
                                                {spec}
                                                <button
                                                    type="button"
                                                    onClick={() => toggleSpecialty(spec)}
                                                    className="hover:text-white"
                                                >
                                                    <X size={10} />
                                                </button>
                                            </span>
                                        ))}
                                        {formData.selectedSpecialties.length === 0 && (
                                            <span className="text-gray-500 text-sm">Selecione abaixo</span>
                                        )}
                                    </div>
                                    {fieldErrors.specialty && (
                                        <p className="text-red-400 text-[11px] mt-1 flex items-center gap-1">
                                            <AlertCircle size={10} /> {fieldErrors.specialty}
                                        </p>
                                    )}
                                </div>
                            </div>

                            {/* Specialty Chips */}
                            <div className="flex flex-wrap gap-2">
                                {SPECIALTY_CHIPS.map(chip => {
                                    const isSelected = formData.selectedSpecialties.some(s => s.toLowerCase() === chip.toLowerCase());
                                    return (
                                        <button
                                            key={chip}
                                            type="button"
                                            onClick={() => toggleSpecialty(chip)}
                                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${isSelected
                                                    ? 'bg-barber-gold/20 text-barber-gold border border-barber-gold/40 shadow-sm shadow-barber-gold/10'
                                                    : 'bg-barber-800/50 text-gray-400 hover:bg-barber-700 hover:text-white border border-transparent'
                                                }`}
                                        >
                                            <Scissors size={10} />
                                            {chip}
                                            {isSelected && <Check size={10} />}
                                        </button>
                                    );
                                })}
                            </div>

                            {/* Row 2: Email + Telefone */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold">
                                        E-mail
                                    </label>
                                    <div className="relative">
                                        <input
                                            type="email"
                                            value={formData.email}
                                            onChange={(e) => handleEmailChange(e.target.value)}
                                            className={`w-full bg-barber-950 border text-white rounded-xl px-4 h-11 text-sm outline-none transition-all pr-10 ${formData.email && !emailValidation.valid
                                                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                                                    : formData.email && emailValidation.valid
                                                        ? 'border-green-500 focus:border-green-500 focus:ring-2 focus:ring-green-500/20'
                                                        : 'border-barber-800 focus:border-barber-gold focus:ring-2 focus:ring-barber-gold/20'
                                                }`}
                                            placeholder="profissional@email.com"
                                        />
                                        {formData.email && (
                                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                                {emailValidation.valid ? (
                                                    <CheckCircle className="text-green-500" size={16} />
                                                ) : (
                                                    <AlertCircle className="text-red-500" size={16} />
                                                )}
                                            </div>
                                        )}
                                    </div>
                                    {formData.email && !emailValidation.valid && emailValidation.message && (
                                        <p className="text-red-400 text-[10px] mt-1">{emailValidation.message}</p>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold">
                                        WhatsApp
                                    </label>
                                    <div className="relative">
                                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium select-none">+55</div>
                                        <input
                                            type="tel"
                                            value={formData.phone}
                                            onChange={(e) => handlePhoneChange(e.target.value)}
                                            className={`w-full bg-barber-950 border text-white rounded-xl pl-12 pr-10 h-11 text-sm outline-none transition-all ${formData.phone && !phoneValidation.valid
                                                    ? 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                                                    : formData.phone && phoneValidation.valid
                                                        ? 'border-green-500 focus:border-green-500 focus:ring-2 focus:ring-green-500/20'
                                                        : 'border-barber-800 focus:border-barber-gold focus:ring-2 focus:ring-barber-gold/20'
                                                }`}
                                            placeholder="(11) 99999-9999"
                                            maxLength={15}
                                        />
                                        {formData.phone && (
                                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                                {phoneValidation.valid ? (
                                                    <CheckCircle className="text-green-500" size={16} />
                                                ) : (
                                                    <AlertCircle className="text-red-500" size={16} />
                                                )}
                                            </div>
                                        )}
                                    </div>
                                    {formData.phone && !phoneValidation.valid && phoneValidation.message && (
                                        <p className="text-red-400 text-[10px] mt-1">{phoneValidation.message}</p>
                                    )}
                                </div>
                            </div>

                            {/* Divider */}
                            <div className="flex items-center gap-3 py-2">
                                <div className="flex-1 h-px bg-barber-800" />
                                <span className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Configurações Financeiras</span>
                                <div className="flex-1 h-px bg-barber-800" />
                            </div>

                            {/* Row 3: Meta + Comissão */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold flex items-center gap-1.5">
                                        Meta Mensal
                                        <span className="group relative">
                                            <HelpCircle size={12} className="text-gray-500 cursor-help" />
                                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 bg-barber-800 text-[10px] text-gray-300 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                                Usado para acompanhar performance
                                            </span>
                                        </span>
                                    </label>
                                    <div className="relative">
                                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium select-none">R$</div>
                                        <input
                                            type="text"
                                            inputMode="numeric"
                                            value={formData.monthly_goal.toLocaleString('pt-BR')}
                                            onChange={(e) => {
                                                const value = parseInt(e.target.value.replace(/\D/g, '')) || 0;
                                                setFormData({ ...formData, monthly_goal: value });
                                                setHasChanges(true);
                                            }}
                                            className="w-full bg-barber-950 border border-barber-800 text-white rounded-xl pl-12 pr-4 h-11 text-sm font-bold outline-none focus:border-barber-gold focus:ring-2 focus:ring-barber-gold/20 transition-all"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-gray-300 mb-2 font-bold flex items-center gap-1.5">
                                        Comissão
                                        <span className="group relative">
                                            <HelpCircle size={12} className="text-gray-500 cursor-help" />
                                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 bg-barber-800 text-[10px] text-gray-300 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                                Aplicado nos serviços concluídos
                                            </span>
                                        </span>
                                    </label>
                                    <div className="relative">
                                        <input
                                            type="text"
                                            inputMode="numeric"
                                            value={formData.commission_rate}
                                            onChange={(e) => {
                                                const value = Math.min(100, Math.max(0, parseInt(e.target.value.replace(/\D/g, '')) || 0));
                                                setFormData({ ...formData, commission_rate: value });
                                                setHasChanges(true);
                                            }}
                                            className="w-full bg-barber-950 border border-barber-800 text-white rounded-xl px-4 pr-10 h-11 text-sm font-bold outline-none focus:border-barber-gold focus:ring-2 focus:ring-barber-gold/20 transition-all"
                                        />
                                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium select-none">%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Step 2: JORNADA */}
                    {currentStep === 2 && (
                        <div className="space-y-4">
                            {/* Summary Stats */}
                            <div className="grid grid-cols-3 gap-3">
                                <div className="bg-barber-950 rounded-xl p-3 border border-barber-800 text-center">
                                    <div className="text-2xl font-bold text-white">{activeDays.length}</div>
                                    <div className="text-[10px] text-gray-500 uppercase tracking-wider">Dias Ativos</div>
                                </div>
                                <div className="bg-barber-950 rounded-xl p-3 border border-barber-800 text-center">
                                    <div className="text-2xl font-bold text-barber-gold">{weeklyHours.toFixed(0)}h</div>
                                    <div className="text-[10px] text-gray-500 uppercase tracking-wider">Carga Semanal</div>
                                </div>
                                <div className="bg-barber-950 rounded-xl p-3 border border-barber-800 text-center">
                                    <div className="text-2xl font-bold text-white">
                                        {activeDays.filter(d => d.break_start).length > 0 ? '1h' : '0h'}
                                    </div>
                                    <div className="text-[10px] text-gray-500 uppercase tracking-wider">Pausa Média</div>
                                </div>
                            </div>

                            {/* Action Toolbar */}
                            <div className="flex items-center justify-between bg-barber-950 rounded-xl p-3 border border-barber-800">
                                <div className="flex items-center gap-2">
                                    <button
                                        type="button"
                                        onClick={copyFromMonday}
                                        className="px-3 py-1.5 bg-barber-800 hover:bg-barber-700 text-gray-300 hover:text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
                                    >
                                        <Copy size={12} />
                                        Copiar de Seg
                                    </button>
                                    <button
                                        type="button"
                                        onClick={applyMondayToAll}
                                        className="px-3 py-1.5 bg-barber-800 hover:bg-barber-700 text-gray-300 hover:text-white text-xs font-medium rounded-lg transition-colors"
                                    >
                                        Aplicar a Todos
                                    </button>
                                    <button
                                        type="button"
                                        onClick={clearSchedule}
                                        className="px-3 py-1.5 bg-barber-800 hover:bg-red-500/20 text-gray-400 hover:text-red-400 text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
                                    >
                                        <RotateCcw size={12} />
                                        Limpar
                                    </button>
                                </div>
                            </div>

                            {/* Days List - 3 Column Layout */}
                            <div className="bg-barber-950 rounded-xl border border-barber-800 overflow-hidden">
                                {schedule.map((day, index) => (
                                    <div
                                        key={day.day_of_week}
                                        className={`grid grid-cols-[120px_1fr_200px] items-center px-4 h-12 border-b border-barber-800 last:border-b-0 transition-all ${!day.is_active ? 'opacity-40 bg-barber-950/50' : ''
                                            }`}
                                    >
                                        {/* Col 1: Day + Toggle */}
                                        <div className="flex items-center gap-3">
                                            <span className="w-14 text-white font-medium text-sm">{dayNamesFull[day.day_of_week]}</span>
                                            <button
                                                type="button"
                                                onClick={() => updateSchedule(index, 'is_active', !day.is_active)}
                                                className={`w-9 h-5 rounded-full transition-colors relative shrink-0 ${day.is_active ? 'bg-barber-gold' : 'bg-barber-700'
                                                    }`}
                                            >
                                                <div className={`absolute w-4 h-4 bg-white rounded-full top-0.5 transition-all shadow ${day.is_active ? 'right-0.5' : 'left-0.5'
                                                    }`} />
                                            </button>
                                        </div>

                                        {/* Col 2: Time Inputs or "Folga" */}
                                        {day.is_active ? (
                                            <div className="flex items-center gap-2">
                                                <span className="text-[10px] text-gray-500 uppercase">Jornada:</span>
                                                <input
                                                    type="time"
                                                    value={day.start_time}
                                                    onChange={(e) => updateSchedule(index, 'start_time', e.target.value)}
                                                    className="bg-barber-900 border border-barber-700 text-white rounded-lg px-2 py-1 text-sm w-20 text-center outline-none focus:border-barber-gold transition-colors"
                                                />
                                                <span className="text-gray-600">—</span>
                                                <input
                                                    type="time"
                                                    value={day.end_time}
                                                    onChange={(e) => updateSchedule(index, 'end_time', e.target.value)}
                                                    className="bg-barber-900 border border-barber-700 text-white rounded-lg px-2 py-1 text-sm w-20 text-center outline-none focus:border-barber-gold transition-colors"
                                                />
                                            </div>
                                        ) : (
                                            <div className="text-gray-600 text-sm font-medium">Folga</div>
                                        )}

                                        {/* Col 3: Pause Chip */}
                                        {day.is_active && (
                                            <div className="flex justify-end relative">
                                                {day.break_start && day.break_end ? (
                                                    <button
                                                        type="button"
                                                        onClick={() => openPauseEditor(index)}
                                                        className="px-2.5 py-1 bg-orange-500/15 border border-orange-500/30 rounded-lg text-[11px] text-orange-400 font-medium flex items-center gap-1.5 hover:bg-orange-500/25 transition-colors"
                                                    >
                                                        <Clock size={10} />
                                                        Pausa {day.break_start}–{day.break_end}
                                                        <Pencil size={10} className="opacity-50" />
                                                    </button>
                                                ) : (
                                                    <button
                                                        type="button"
                                                        onClick={() => openPauseEditor(index)}
                                                        className="px-2.5 py-1 bg-transparent border border-barber-700 rounded-lg text-[11px] text-gray-500 font-medium flex items-center gap-1 hover:border-barber-gold hover:text-barber-gold transition-colors"
                                                    >
                                                        + Adicionar pausa
                                                    </button>
                                                )}

                                                {/* Pause Editor Popover */}
                                                {editingPauseDay === index && (
                                                    <>
                                                        <div className="fixed inset-0 z-40" onClick={() => setEditingPauseDay(null)} />
                                                        <div className="absolute right-0 top-full mt-2 z-50 bg-barber-900 border border-barber-700 rounded-xl p-4 shadow-2xl w-64 animate-fade-in">
                                                            <div className="text-xs text-gray-400 uppercase tracking-wider mb-3 font-bold">Pausa</div>

                                                            <div className="flex items-center gap-2 mb-3">
                                                                <div className="flex-1">
                                                                    <label className="text-[10px] text-gray-500 block mb-1">Início</label>
                                                                    <input
                                                                        type="time"
                                                                        value={tempPause.start}
                                                                        onChange={(e) => setTempPause({ ...tempPause, start: e.target.value })}
                                                                        className="w-full bg-barber-950 border border-barber-700 text-white rounded-lg px-2 py-1.5 text-sm text-center outline-none focus:border-barber-gold"
                                                                    />
                                                                </div>
                                                                <div className="flex-1">
                                                                    <label className="text-[10px] text-gray-500 block mb-1">Fim</label>
                                                                    <input
                                                                        type="time"
                                                                        value={tempPause.end}
                                                                        onChange={(e) => setTempPause({ ...tempPause, end: e.target.value })}
                                                                        className="w-full bg-barber-950 border border-barber-700 text-white rounded-lg px-2 py-1.5 text-sm text-center outline-none focus:border-barber-gold"
                                                                    />
                                                                </div>
                                                            </div>

                                                            {/* Presets */}
                                                            <div className="flex gap-1.5 mb-4">
                                                                {BREAK_PRESETS.map(preset => (
                                                                    <button
                                                                        key={preset}
                                                                        type="button"
                                                                        onClick={() => applyPreset(preset)}
                                                                        className="px-2 py-1 bg-barber-800 hover:bg-barber-700 text-gray-400 hover:text-white text-[10px] rounded transition-colors"
                                                                    >
                                                                        {preset}
                                                                    </button>
                                                                ))}
                                                            </div>

                                                            {/* Actions */}
                                                            <div className="flex gap-2">
                                                                <button
                                                                    type="button"
                                                                    onClick={removePause}
                                                                    className="flex-1 px-3 py-1.5 text-red-400 hover:bg-red-500/10 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1"
                                                                >
                                                                    <Trash2 size={12} />
                                                                    Remover
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={savePause}
                                                                    className="flex-1 px-3 py-1.5 bg-barber-gold hover:bg-barber-goldhover text-black text-xs font-bold rounded-lg transition-colors"
                                                                >
                                                                    Salvar
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            {/* Buffer Section */}
                            <div className="bg-barber-950 border border-barber-800 rounded-xl p-4">
                                <div className="flex items-center justify-between mb-3">
                                    <div>
                                        <div className="text-white font-semibold text-sm">Buffer Personalizado</div>
                                        <div className="text-gray-500 text-xs">Intervalo entre agendamentos</div>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => setFormData({ ...formData, custom_buffer: !formData.custom_buffer })}
                                        className={`w-10 h-5 rounded-full transition-colors relative ${formData.custom_buffer ? 'bg-barber-gold' : 'bg-barber-700'
                                            }`}
                                    >
                                        <div className={`absolute w-4 h-4 bg-white rounded-full top-0.5 transition-all shadow ${formData.custom_buffer ? 'right-0.5' : 'left-0.5'
                                            }`} />
                                    </button>
                                </div>

                                {formData.custom_buffer && (
                                    <div className="pt-2 border-t border-barber-800">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-gray-400 text-sm">Intervalo</span>
                                            <span className="text-barber-gold font-bold">{formData.buffer_minutes} min</span>
                                        </div>
                                        <input
                                            type="range"
                                            min="0"
                                            max="60"
                                            step="5"
                                            value={formData.buffer_minutes}
                                            onChange={(e) => setFormData({ ...formData, buffer_minutes: Number(e.target.value) })}
                                            className="w-full accent-barber-gold h-1.5 bg-barber-800 rounded-lg appearance-none cursor-pointer"
                                        />
                                        <div className="flex justify-between text-[9px] text-gray-600 mt-1">
                                            <span>0</span><span>15</span><span>30</span><span>45</span><span>60 min</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Sticky Footer */}
                <div className="p-6 border-t border-barber-800 flex items-center justify-between shrink-0 bg-barber-950">
                    {currentStep === 1 ? (
                        <>
                            <button
                                onClick={handleClose}
                                className="text-gray-400 hover:text-white transition-colors text-sm px-4 py-2 hover:bg-barber-800 rounded-lg"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={handleNext}
                                className="bg-barber-gold hover:bg-barber-goldhover text-black font-bold px-8 py-3 rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-barber-gold/20"
                            >
                                Próximo
                                <ChevronRight size={18} />
                            </button>
                        </>
                    ) : (
                        <>
                            <button
                                onClick={() => setCurrentStep(1)}
                                className="text-gray-400 hover:text-white transition-colors flex items-center gap-1 text-sm px-4 py-2 hover:bg-barber-800 rounded-lg"
                            >
                                <ChevronLeft size={16} />
                                Voltar
                            </button>
                            <button
                                onClick={handleSubmit}
                                disabled={isLoading}
                                className="bg-barber-gold hover:bg-barber-goldhover text-black font-bold px-8 py-3 rounded-xl transition-all flex items-center gap-2 disabled:opacity-50 shadow-lg shadow-barber-gold/20"
                            >
                                <Check size={18} />
                                {isLoading ? 'Salvando...' : (professional ? 'Salvar Alterações' : 'Concluir Cadastro')}
                            </button>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProfessionalModal;
