import React, { useState, useEffect } from 'react';
import {
   Save,
   Store,
   Bot,
   Layout,
   ShieldAlert,
   DollarSign,
   BarChart3,
   Globe,
   X,
   ToggleLeft,
   ToggleRight,
   Sparkles,
   Clock,
   Calendar,
   Users,
   Timer,
   Award,
   Gift,
   Megaphone,
   Bell,
   Camera,
   CreditCard,
   ChevronDown,
   ChevronUp,
   Info,
   Check,
   Phone,
   Mail,
   MapPin,
   Building2,
   CheckCircle,
   AlertCircle,
   Edit2
} from 'lucide-react';
import { SystemSettings } from '../types';
import { getCurrentBusiness, getCurrentBusinessId } from '../lib/database';
import { supabase } from '../lib/supabase';
import { validatePhone, formatPhone, PhoneValidationResult } from '../lib/validation';
import {
   fetchBusinessSettings,
   updateBusinessSettings as updateSettings,
   BusinessSettings,
   LoyaltyTier,
   DEFAULT_SETTINGS
} from '../lib/settingsService';

// UI Components (Design System)
import Card from './ui/Card';
import Button from './ui/Button';
import { useToast } from './ui/Toast';

interface SettingsProps {
   settings: SystemSettings;
   onUpdateSettings: (newSettings: SystemSettings) => void;
}

interface BusinessHours {
   monday: { open: string; close: string; closed: boolean };
   tuesday: { open: string; close: string; closed: boolean };
   wednesday: { open: string; close: string; closed: boolean };
   thursday: { open: string; close: string; closed: boolean };
   friday: { open: string; close: string; closed: boolean };
   saturday: { open: string; close: string; closed: boolean };
   sunday: { open: string; close: string; closed: boolean };
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings }) => {
   const toast = useToast();

   const [businessHours, setBusinessHours] = useState<BusinessHours>({
      monday: { open: '09:00', close: '18:00', closed: false },
      tuesday: { open: '09:00', close: '18:00', closed: false },
      wednesday: { open: '09:00', close: '18:00', closed: false },
      thursday: { open: '09:00', close: '18:00', closed: false },
      friday: { open: '09:00', close: '18:00', closed: false },
      saturday: { open: '09:00', close: '14:00', closed: false },
      sunday: { open: '09:00', close: '14:00', closed: true },
   });

   const [globalBuffer, setGlobalBuffer] = useState(15);
   const [saving, setSaving] = useState(false);

   // Business Info State
   const [businessInfo, setBusinessInfo] = useState({
      business_name: '',
      address: '',
      phone: '',
      email: ''
   });
   const [originalBusinessInfo, setOriginalBusinessInfo] = useState({
      business_name: '',
      address: '',
      phone: '',
      email: ''
   });
   const [savingBusinessInfo, setSavingBusinessInfo] = useState(false);
   const [isEditingBusinessInfo, setIsEditingBusinessInfo] = useState(false);
   const [phoneValidation, setPhoneValidation] = useState<PhoneValidationResult>({ valid: true });

   // Handle phone blur - validate and format
   const handlePhoneBlur = async () => {
      if (!businessInfo.phone.trim()) {
         setPhoneValidation({ valid: true });
         return;
      }
      const result = await validatePhone(businessInfo.phone);
      setPhoneValidation(result);
      if (result.valid && result.national) {
         setBusinessInfo({ ...businessInfo, phone: result.national });
      }
   };

   // Feature toggles & Loyalty settings
   const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
   const [expandedSection, setExpandedSection] = useState<string | null>(null);

   // Carregar dados do banco
   useEffect(() => {
      loadBusinessData();
   }, []);

   const loadBusinessData = async () => {
      const business = await getCurrentBusiness();
      if (business) {
         if (business.business_hours) {
            setBusinessHours(business.business_hours as BusinessHours);
         }
         if (business.booking_settings?.buffer_minutes) {
            setGlobalBuffer(business.booking_settings.buffer_minutes);
         }
         // Load business info
         // Note: DB uses 'business_name' but TS type uses 'name'
         const businessData = business as any;
         const info = {
            business_name: businessData.business_name || businessData.name || '',
            address: business.address || '',
            phone: business.phone || '',
            email: business.email || ''
         };
         setBusinessInfo(info);
         setOriginalBusinessInfo(info);

         // Load feature toggles & loyalty settings
         const settings = await fetchBusinessSettings(business.id);
         if (settings) {
            setBusinessSettings(settings);
         }
      }
   };

   // Update a single business setting
   const handleUpdateBusinessSetting = async (key: keyof BusinessSettings, value: any) => {
      const businessId = await getCurrentBusinessId();
      if (!businessId || !businessSettings) return;

      const updates = { [key]: value };
      const success = await updateSettings(businessId, updates);
      if (success) {
         setBusinessSettings(prev => prev ? { ...prev, ...updates } : null);
      }
   };

   // Check if business info has changed
   const hasBusinessInfoChanged = () => {
      return (
         businessInfo.business_name !== originalBusinessInfo.business_name ||
         businessInfo.address !== originalBusinessInfo.address ||
         businessInfo.phone !== originalBusinessInfo.phone ||
         businessInfo.email !== originalBusinessInfo.email
      );
   };

   // Cancel editing - revert to original values
   const handleCancelEdit = () => {
      setBusinessInfo({ ...originalBusinessInfo });
      setPhoneValidation({ valid: true });
      setIsEditingBusinessInfo(false);
   };

   // Save business info
   const handleSaveBusinessInfo = async () => {

      setSavingBusinessInfo(true);
      try {
         const businessId = await getCurrentBusinessId();
         if (!businessId) {
            toast.error('Erro: Negócio não encontrado');
            return;
         }

         const { error } = await supabase
            .from('businesses')
            .update({
               business_name: businessInfo.business_name,
               address: businessInfo.address,
               phone: businessInfo.phone,
               email: businessInfo.email,
               updated_at: new Date().toISOString()
            })
            .eq('id', businessId);

         if (error) throw error;

         setOriginalBusinessInfo({ ...businessInfo });
         setIsEditingBusinessInfo(false);
         toast.success('Informações salvas com sucesso!');
      } catch (error) {
         console.error('Error saving business info:', error);
         toast.error('Erro ao salvar informações');
      } finally {
         setSavingBusinessInfo(false);
      }
   };

   const handleSaveAll = async () => {
      setSaving(true);
      try {
         const businessId = await getCurrentBusinessId();
         if (!businessId) {
            toast.error('Erro: Negócio não encontrado');
            return;
         }

         // Atualizar horários de funcionamento
         const { error: hoursError } = await supabase
            .from('businesses')
            .update({ business_hours: businessHours })
            .eq('id', businessId);

         if (hoursError) throw hoursError;

         // Atualizar buffer global
         const { data: currentBusiness } = await supabase
            .from('businesses')
            .select('booking_settings')
            .eq('id', businessId)
            .single();

         const updatedSettings = {
            ...(currentBusiness?.booking_settings || {}),
            buffer_minutes: globalBuffer
         };

         const { error: bufferError } = await supabase
            .from('businesses')
            .update({ booking_settings: updatedSettings })
            .eq('id', businessId);

         if (bufferError) throw bufferError;

         toast.success('Configurações salvas com sucesso!');
      } catch (error) {
         console.error('Erro ao salvar:', error);
         toast.error('Erro ao salvar configurações');
      } finally {
         setSaving(false);
      }
   };

   const handleToggleModule = (module: keyof SystemSettings['modules']) => {
      onUpdateSettings({
         ...settings,
         modules: {
            ...settings.modules,
            [module]: !settings.modules[module]
         }
      });
   };

   const handleToggleAI = (type: keyof SystemSettings['aiConfig']['insightTypes']) => {
      onUpdateSettings({
         ...settings,
         aiConfig: {
            ...settings.aiConfig,
            insightTypes: {
               ...settings.aiConfig.insightTypes,
               [type]: !settings.aiConfig.insightTypes[type]
            }
         }
      });
   };

   const handleGlobalAIToggle = () => {
      onUpdateSettings({
         ...settings,
         aiConfig: {
            ...settings.aiConfig,
            enableInsights: !settings.aiConfig.enableInsights
         }
      });
   };

   const handleDayHoursChange = (day: keyof BusinessHours, field: 'open' | 'close', value: string) => {
      setBusinessHours({
         ...businessHours,
         [day]: {
            ...businessHours[day],
            [field]: value
         }
      });
   };

   const handleDayToggle = (day: keyof BusinessHours) => {
      setBusinessHours({
         ...businessHours,
         [day]: {
            ...businessHours[day],
            closed: !businessHours[day].closed
         }
      });
   };

   const Toggle = ({ active, onClick }: { active: boolean, onClick: (e?: React.MouseEvent) => void }) => (
      <button onClick={(e) => onClick(e)} className={`transition-colors ${active ? 'text-green-500' : 'text-gray-600'}`}>
         {active ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
      </button>
   );

   const dayNames: { key: keyof BusinessHours; label: string }[] = [
      { key: 'monday', label: 'Segunda-feira' },
      { key: 'tuesday', label: 'Terça-feira' },
      { key: 'wednesday', label: 'Quarta-feira' },
      { key: 'thursday', label: 'Quinta-feira' },
      { key: 'friday', label: 'Sexta-feira' },
      { key: 'saturday', label: 'Sábado' },
      { key: 'sunday', label: 'Domingo' },
   ];

   return (
      <div className="space-y-6 animate-fade-in pb-20">

         {/* Header */}
         <div className="bg-barber-900 p-6 rounded-xl border border-barber-800 shadow-lg">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
               <Layout className="text-barber-gold" /> Configurações
            </h2>
            <p className="text-gray-400 text-sm mt-1">Personalize módulos, horários e informações do seu negócio.</p>
         </div>

         {/* 🔴 OPERAÇÃO CRÍTICA - Horário + Buffer */}
         <div className="mb-2">
            <div className="flex items-center gap-2 text-xs mb-4">
               <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/30 font-bold">
                  🔴 OPERAÇÃO CRÍTICA
               </span>
               <span className="text-gray-500">Afeta agenda, clientes e faturamento</span>
            </div>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            {/* Horário de Funcionamento */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5">
               <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-bold flex items-center gap-2">
                     <Clock className="text-blue-500" size={18} /> Horário de Funcionamento
                  </h3>
                  <button
                     onClick={() => {
                        // Apply Monday hours to all weekdays
                        const mondayHours = businessHours.monday;
                        setBusinessHours({
                           ...businessHours,
                           tuesday: { ...mondayHours },
                           wednesday: { ...mondayHours },
                           thursday: { ...mondayHours },
                           friday: { ...mondayHours }
                        });
                        toast.info('Horário de Seg aplicado a Ter-Sex');
                     }}
                     className="text-xs text-barber-gold hover:text-white transition-colors"
                  >
                     Aplicar Seg a todos →
                  </button>
               </div>

               <div className="space-y-2">
                  {dayNames.map(({ key, label }) => {
                     const isOpen = !businessHours[key].closed;
                     return (
                        <div
                           key={key}
                           className={`flex items-center gap-3 p-2.5 rounded-lg border transition-all ${isOpen
                              ? 'bg-barber-900 border-barber-800'
                              : 'bg-barber-950/50 border-barber-800/50 opacity-60'
                              }`}
                        >
                           {/* Status indicator */}
                           <div
                              onClick={() => handleDayToggle(key)}
                              className={`w-2.5 h-2.5 rounded-full cursor-pointer transition-colors ${isOpen ? 'bg-green-500' : 'bg-gray-600'
                                 }`}
                              title={isOpen ? 'Aberto' : 'Fechado'}
                           />

                           {/* Day name */}
                           <span className={`text-sm font-medium w-16 ${isOpen ? 'text-white' : 'text-gray-500'}`}>
                              {label.substring(0, 3)}
                           </span>

                           {isOpen ? (
                              <div className="flex items-center gap-2 flex-1">
                                 <input
                                    type="time"
                                    value={businessHours[key].open}
                                    onChange={(e) => handleDayHoursChange(key, 'open', e.target.value)}
                                    className="bg-barber-950 border border-barber-700 text-white rounded px-2 py-1 text-sm outline-none focus:border-barber-gold w-24"
                                 />
                                 <span className="text-gray-500 text-xs">às</span>
                                 <input
                                    type="time"
                                    value={businessHours[key].close}
                                    onChange={(e) => handleDayHoursChange(key, 'close', e.target.value)}
                                    className="bg-barber-950 border border-barber-700 text-white rounded px-2 py-1 text-sm outline-none focus:border-barber-gold w-24"
                                 />
                              </div>
                           ) : (
                              <span className="text-xs text-red-400 font-medium">Fechado</span>
                           )}

                           {/* Toggle */}
                           <button
                              onClick={() => handleDayToggle(key)}
                              className={`text-xs px-2 py-0.5 rounded transition-colors ${isOpen
                                 ? 'text-gray-400 hover:text-red-400'
                                 : 'text-green-400 hover:text-green-300'
                                 }`}
                           >
                              {isOpen ? 'Fechar' : 'Abrir'}
                           </button>
                        </div>
                     );
                  })}
               </div>

               {/* Save Button */}
               <div className="mt-4 flex items-center justify-between">
                  <span className="text-xs text-gray-500">Salva horários + buffer</span>
                  <button
                     onClick={handleSaveAll}
                     disabled={saving}
                     className="bg-barber-gold hover:bg-barber-goldhover text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 text-sm transition-colors disabled:opacity-50"
                  >
                     <Save size={16} /> {saving ? 'Salvando...' : 'Salvar'}
                  </button>
               </div>
            </div>

            {/* Intervalo entre Serviços */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5">
               <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                  <Timer className="text-green-500" size={18} /> Buffer entre Serviços
               </h3>

               <div className="bg-barber-900 p-4 rounded-lg border border-barber-800">
                  <div className="flex justify-between items-center mb-3">
                     <div>
                        <span className="text-white font-medium">Intervalo padrão</span>
                     </div>
                     <div className="text-right">
                        <span className="text-2xl font-bold text-barber-gold">{globalBuffer}</span>
                        <span className="text-gray-400 ml-1 text-sm">min</span>
                     </div>
                  </div>

                  <input
                     type="range"
                     min="0"
                     max="60"
                     step="5"
                     value={globalBuffer}
                     onChange={(e) => setGlobalBuffer(Number(e.target.value))}
                     className="w-full accent-barber-gold h-2 bg-barber-800 rounded-lg appearance-none cursor-pointer"
                  />

                  <div className="flex justify-between text-[10px] text-gray-600 mt-1.5">
                     {[0, 15, 30, 45, 60].map(v => (
                        <span key={v} className={globalBuffer === v ? 'text-barber-gold font-bold' : ''}>{v}</span>
                     ))}
                  </div>

                  {/* Impact Feedback */}
                  <div className={`mt-3 p-2.5 rounded-lg border text-xs ${globalBuffer === 0
                     ? 'bg-green-500/10 border-green-500/30 text-green-400'
                     : globalBuffer <= 15
                        ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400'
                        : 'bg-orange-500/10 border-orange-500/30 text-orange-400'
                     }`}>
                     <span className="font-bold">Impacto:</span>{' '}
                     {globalBuffer === 0 ? (
                        'Sem intervalo. Agendamentos consecutivos.'
                     ) : (
                        <>~{Math.round(globalBuffer * 8 / 30)} slots a menos por dia/profissional</>
                     )}
                  </div>
               </div>

               <p className="text-xs text-gray-500 mt-3 flex items-center gap-1.5">
                  <Users size={12} />
                  Buffer individual por profissional: editar em <strong className="text-gray-400">Equipe</strong>
               </p>
            </div>
         </div>

         {/* 🟡 CRESCIMENTO */}
         <div className="mb-2 mt-8">
            <div className="flex items-center gap-2 text-xs mb-4">
               <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 font-bold">
                  🟡 CRESCIMENTO
               </span>
               <span className="text-gray-500">Afeta receita, retenção e marketing</span>
            </div>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Coluna Esquerda - Descrição + Features Ativas */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5">
               <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                  <Award className="text-barber-gold" size={18} /> Recursos Ativos
               </h3>

               <div className="space-y-3">
                  {/* Pagamentos Online - Core Feature */}
                  <div className="flex items-center gap-3 p-3 bg-barber-900 rounded-lg border border-green-500/30">
                     <div className="p-2 bg-green-500/20 rounded-lg text-green-400">
                        <CreditCard size={18} />
                     </div>
                     <div className="flex-1 min-w-0">
                        <div className="font-medium text-white text-sm flex items-center gap-2">
                           Pagamentos Online
                           <span className="text-[9px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">ATIVO</span>
                        </div>
                        <div className="text-xs text-gray-500">Stripe integrado</div>
                     </div>
                     <Check size={16} className="text-green-500 shrink-0" />
                  </div>

                  {/* Programa de Fidelidade */}
                  <div
                     onClick={() => setExpandedSection(expandedSection === 'loyalty' ? null : 'loyalty')}
                     className={`flex items-center gap-3 p-3 bg-barber-900 rounded-lg border cursor-pointer transition-all ${businessSettings?.loyalty_enabled
                        ? 'border-green-500/30'
                        : 'border-barber-800 hover:border-barber-700'
                        }`}
                  >
                     <div className="p-2 bg-yellow-500/20 rounded-lg text-yellow-400">
                        <Gift size={18} />
                     </div>
                     <div className="flex-1 min-w-0">
                        <div className="font-medium text-white text-sm flex items-center gap-2">
                           Fidelidade
                           {businessSettings?.loyalty_enabled && (
                              <span className="text-[9px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">ATIVO</span>
                           )}
                        </div>
                        <div className="text-xs text-gray-500">Cartão digital</div>
                     </div>
                     <Toggle
                        active={businessSettings?.loyalty_enabled ?? false}
                        onClick={(e: React.MouseEvent) => {
                           e.stopPropagation();
                           handleUpdateBusinessSetting('loyalty_enabled', !businessSettings?.loyalty_enabled);
                        }}
                     />
                  </div>

                  {/* Agendamento Público */}
                  <div className={`flex items-center gap-3 p-3 bg-barber-900 rounded-lg border transition-all ${settings.modules.publicBooking
                     ? 'border-green-500/30'
                     : 'border-barber-800'
                     }`}>
                     <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                        <Globe size={18} />
                     </div>
                     <div className="flex-1 min-w-0">
                        <div className="font-medium text-white text-sm flex items-center gap-2">
                           Agendamento Público
                           {settings.modules.publicBooking && (
                              <span className="text-[9px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">ATIVO</span>
                           )}
                        </div>
                        <div className="text-xs text-gray-500">Link para clientes</div>
                     </div>
                     <Toggle active={settings.modules.publicBooking} onClick={() => handleToggleModule('publicBooking')} />
                  </div>
               </div>

               {/* Loyalty Expanded Panel */}
               {expandedSection === 'loyalty' && businessSettings?.loyalty_enabled && (
                  <div className="mt-4 pt-4 border-t border-barber-800">
                     <div className="grid grid-cols-2 gap-3 mb-3">
                        <div>
                           <label className="text-xs text-gray-400 block mb-1">Visitas para prêmio</label>
                           <input
                              type="number"
                              min="1"
                              max="20"
                              value={businessSettings?.loyalty_visits_for_reward ?? 10}
                              onChange={(e) => handleUpdateBusinessSetting('loyalty_visits_for_reward', Number(e.target.value))}
                              className="w-20 bg-barber-950 border border-barber-700 text-white rounded px-2 py-1.5 text-center text-sm outline-none focus:border-barber-gold"
                           />
                        </div>
                        <div>
                           <label className="text-xs text-gray-400 block mb-1">Prêmio</label>
                           <input
                              type="text"
                              value={businessSettings?.loyalty_reward_description ?? 'Corte grátis'}
                              onChange={(e) => handleUpdateBusinessSetting('loyalty_reward_description', e.target.value)}
                              className="w-full bg-barber-950 border border-barber-700 text-white rounded px-2 py-1.5 text-sm outline-none focus:border-barber-gold"
                           />
                        </div>
                     </div>
                     <p className="text-xs text-gray-500">
                        Após {businessSettings?.loyalty_visits_for_reward ?? 10} visitas → <span className="text-barber-gold">{businessSettings?.loyalty_reward_description ?? 'Corte grátis'}</span>
                     </p>
                  </div>
               )}
            </div>

            {/* Coluna Direita - Em Breve */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5">
               <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                  <Sparkles className="text-gray-500" size={18} /> Em Breve
               </h3>

               <div className="space-y-3">
                  {/* Marketing */}
                  <div className="flex items-center gap-3 p-3 bg-barber-900/50 rounded-lg border border-barber-800/50 opacity-60">
                     <div className="p-2 bg-pink-500/20 rounded-lg text-pink-400">
                        <Megaphone size={18} />
                     </div>
                     <div className="flex-1">
                        <div className="font-medium text-white text-sm">Marketing</div>
                        <div className="text-xs text-gray-500">Campanhas WhatsApp</div>
                     </div>
                     <span className="text-[9px] bg-barber-gold/20 text-barber-gold px-1.5 py-0.5 rounded">BREVE</span>
                  </div>

                  {/* Lembretes */}
                  <div className="flex items-center gap-3 p-3 bg-barber-900/50 rounded-lg border border-barber-800/50 opacity-60">
                     <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                        <Bell size={18} />
                     </div>
                     <div className="flex-1">
                        <div className="font-medium text-white text-sm">Lembretes</div>
                        <div className="text-xs text-gray-500">Notificações automáticas</div>
                     </div>
                     <span className="text-[9px] bg-barber-gold/20 text-barber-gold px-1.5 py-0.5 rounded">BREVE</span>
                  </div>

                  {/* Galeria */}
                  <div className="flex items-center gap-3 p-3 bg-barber-900/50 rounded-lg border border-barber-800/50 opacity-60">
                     <div className="p-2 bg-purple-500/20 rounded-lg text-purple-400">
                        <Camera size={18} />
                     </div>
                     <div className="flex-1">
                        <div className="font-medium text-white text-sm">Galeria</div>
                        <div className="text-xs text-gray-500">Fotos antes/depois</div>
                     </div>
                     <span className="text-[9px] bg-barber-gold/20 text-barber-gold px-1.5 py-0.5 rounded">BREVE</span>
                  </div>

                  {/* Chatbot IA */}
                  <div className="flex items-center gap-3 p-3 bg-barber-900/50 rounded-lg border border-barber-800/50 opacity-60">
                     <div className="p-2 bg-purple-500/20 rounded-lg text-purple-400">
                        <Bot size={18} />
                     </div>
                     <div className="flex-1">
                        <div className="font-medium text-white text-sm">Chatbot IA</div>
                        <div className="text-xs text-gray-500">Assistente virtual</div>
                     </div>
                     <span className="text-[9px] bg-barber-gold/20 text-barber-gold px-1.5 py-0.5 rounded">BREVE</span>
                  </div>
               </div>
            </div>
         </div>

         {/* ⚪ ADMINISTRAÇÃO */}
         <div className="mb-2 mt-8">
            <div className="flex items-center gap-2 text-xs mb-4">
               <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gray-500/10 text-gray-400 border border-gray-500/30 font-bold">
                  ⚪ ADMINISTRAÇÃO
               </span>
               <span className="text-gray-500">Dados do estabelecimento</span>
            </div>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Coluna Esquerda - Info do Negócio */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5">
               <div className="flex justify-between items-start mb-4">
                  <h3 className="text-white font-bold flex items-center gap-2">
                     <Building2 className="text-barber-gold" size={18} /> Informações
                  </h3>
                  {!isEditingBusinessInfo ? (
                     <button
                        onClick={() => setIsEditingBusinessInfo(true)}
                        className="bg-barber-800 hover:bg-barber-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors"
                     >
                        <Edit2 size={14} /> Editar
                     </button>
                  ) : (
                     <div className="flex items-center gap-2">
                        <button
                           onClick={handleCancelEdit}
                           className="bg-barber-800 hover:bg-barber-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors"
                        >
                           <X size={14} /> Cancelar
                        </button>
                        <button
                           onClick={handleSaveBusinessInfo}
                           disabled={savingBusinessInfo || !hasBusinessInfoChanged()}
                           className="bg-barber-gold hover:bg-barber-goldhover text-black px-3 py-1.5 rounded-lg text-sm font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                        >
                           <Save size={14} /> Salvar
                        </button>
                     </div>
                  )}
               </div>

               <div className="space-y-4">
                  <div>
                     <label className="text-xs text-gray-400 uppercase font-bold flex items-center gap-1.5 mb-1.5">
                        <Store size={10} /> Nome
                     </label>
                     <input
                        type="text"
                        value={businessInfo.business_name}
                        onChange={(e) => setBusinessInfo({ ...businessInfo, business_name: e.target.value })}
                        placeholder="Ex: NS Studio"
                        disabled={!isEditingBusinessInfo}
                        className={`w-full bg-barber-900 border border-barber-800 text-white rounded-lg p-2.5 text-sm outline-none transition-colors ${!isEditingBusinessInfo ? 'opacity-70 cursor-not-allowed' : 'focus:border-barber-gold'}`}
                     />
                  </div>

                  <div>
                     <label className="text-xs text-gray-400 uppercase font-bold flex items-center gap-1.5 mb-1.5">
                        <MapPin size={10} /> Endereço
                     </label>
                     <input
                        type="text"
                        value={businessInfo.address}
                        onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
                        placeholder="Ex: Av. Paulista, 1000"
                        disabled={!isEditingBusinessInfo}
                        className={`w-full bg-barber-900 border border-barber-800 text-white rounded-lg p-2.5 text-sm outline-none transition-colors ${!isEditingBusinessInfo ? 'opacity-70 cursor-not-allowed' : 'focus:border-barber-gold'}`}
                     />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                     <div>
                        <label className="text-xs text-gray-400 uppercase font-bold flex items-center gap-1.5 mb-1.5">
                           <Phone size={10} /> Telefone
                        </label>
                        <div className="relative">
                           <input
                              type="tel"
                              value={businessInfo.phone}
                              onChange={(e) => {
                                 setBusinessInfo({ ...businessInfo, phone: e.target.value });
                                 if (phoneValidation.error) setPhoneValidation({ valid: true });
                              }}
                              onBlur={handlePhoneBlur}
                              placeholder="(11) 99999-9999"
                              disabled={!isEditingBusinessInfo}
                              className={`w-full bg-barber-900 border text-white rounded-lg p-2.5 pr-8 text-sm outline-none transition-colors ${!isEditingBusinessInfo
                                 ? 'opacity-70 cursor-not-allowed border-barber-800'
                                 : businessInfo.phone && !phoneValidation.valid
                                    ? 'border-red-500'
                                    : businessInfo.phone && phoneValidation.valid && phoneValidation.national
                                       ? 'border-green-500'
                                       : 'border-barber-800 focus:border-barber-gold'
                                 }`}
                           />
                           {businessInfo.phone && (
                              <div className="absolute right-2 top-1/2 -translate-y-1/2">
                                 {phoneValidation.valid && phoneValidation.national ? (
                                    <CheckCircle size={14} className="text-green-500" />
                                 ) : phoneValidation.error ? (
                                    <AlertCircle size={14} className="text-red-500" />
                                 ) : null}
                              </div>
                           )}
                        </div>
                     </div>
                     <div>
                        <label className="text-xs text-gray-400 uppercase font-bold flex items-center gap-1.5 mb-1.5">
                           <Mail size={10} /> E-mail
                        </label>
                        <input
                           type="email"
                           value={businessInfo.email}
                           onChange={(e) => setBusinessInfo({ ...businessInfo, email: e.target.value })}
                           placeholder="contato@exemplo.com"
                           disabled={!isEditingBusinessInfo}
                           className={`w-full bg-barber-900 border border-barber-800 text-white rounded-lg p-2.5 text-sm outline-none transition-colors ${!isEditingBusinessInfo ? 'opacity-70 cursor-not-allowed' : 'focus:border-barber-gold'}`}
                        />
                     </div>
                  </div>
               </div>
            </div>

            {/* Coluna Direita - Placeholder/Dica */}
            <div className="bg-barber-950 border border-barber-800 rounded-xl p-5 flex flex-col">
               <h3 className="text-white font-bold flex items-center gap-2 mb-4">
                  <ShieldAlert className="text-gray-500" size={18} /> Dados Sensíveis
               </h3>
               <div className="flex-1 flex flex-col justify-center items-center text-center p-6">
                  <div className="p-4 bg-barber-900 rounded-full mb-4">
                     <ShieldAlert size={32} className="text-gray-600" />
                  </div>
                  <p className="text-gray-500 text-sm mb-2">
                     As informações ao lado são usadas no link de agendamento público e em comunicações com clientes.
                  </p>
                  <p className="text-gray-600 text-xs">
                     Mantenha sempre atualizadas para garantir uma boa experiência.
                  </p>
               </div>
            </div>
         </div>

      </div>
   );
};

export default Settings;
