
import React from 'react';

interface BadgeProps {
    children: React.ReactNode;
    variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'vip' | 'outline';
    size?: 'sm' | 'md';
    className?: string;
    icon?: React.ReactNode;
}

const Badge: React.FC<BadgeProps> = ({
    children,
    variant = 'default',
    size = 'md',
    className = '',
    icon
}) => {

    const variants = {
        default: "bg-barber-800 text-gray-300 border-barber-700",
        success: "bg-green-500/10 text-green-500 border-green-500/20",
        warning: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
        danger: "bg-red-500/10 text-red-500 border-red-500/20",
        info: "bg-blue-500/10 text-blue-500 border-blue-500/20",
        vip: "bg-barber-gold/20 text-barber-gold border-barber-gold/30 font-bold",
        outline: "bg-transparent border-gray-600 text-gray-400"
    };

    const sizes = {
        sm: "text-[10px] px-1.5 py-0.5",
        md: "text-xs px-2.5 py-1"
    };

    return (
        <span className={`inline-flex items-center gap-1.5 rounded-full border ${variants[variant]} ${sizes[size]} ${className} uppercase tracking-wide font-bold`}>
            {icon}
            {children}
        </span>
    );
};

export default Badge;
