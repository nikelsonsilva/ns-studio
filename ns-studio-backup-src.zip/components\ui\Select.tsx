
import React from 'react';
import { ChevronDown } from 'lucide-react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
    label?: string;
    icon?: React.ReactNode;
    error?: string;
    containerClassName?: string;
    options: { value: string | number; label: string }[];
}

const Select: React.FC<SelectProps> = ({
    label,
    icon,
    error,
    className = '',
    containerClassName = '',
    options,
    ...props
}) => {
    return (
        <div className={`space-y-1 ${containerClassName}`}>
            {label && (
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">
                    {label}
                </label>
            )}
            <div className="relative group">
                {icon && (
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-barber-gold transition-colors pointer-events-none">
                        {icon}
                    </div>
                )}
                <select
                    className={`w-full bg-barber-950 border border-barber-800 text-white rounded-xl py-3 text-sm outline-none focus:border-barber-gold focus:bg-barber-900 transition-all appearance-none cursor-pointer
          ${icon ? 'pl-10 pr-10' : 'px-4 pr-10'} 
          ${error ? 'border-red-500 focus:border-red-500' : ''}
          ${className}`}
                    {...props}
                >
                    {options.map((opt) => (
                        <option key={opt.value} value={opt.value} className="bg-barber-950 text-white">
                            {opt.label}
                        </option>
                    ))}
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none">
                    <ChevronDown size={16} />
                </div>
            </div>
            {error && (
                <span className="text-xs text-red-500 ml-1 font-medium animate-fade-in">{error}</span>
            )}
        </div>
    );
};

export default Select;
