
import React, { useState, useEffect } from 'react';
import { Menu, Bell, CheckCircle2, AlertCircle, X, ShieldCheck, User } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Calendar from './components/Calendar';
import Clients from './components/Clients';
import Finance from './components/Finance';
import Team from './components/Team';
import Services from './components/Services';
import PublicBooking from './components/PublicBooking';
import Settings from './components/Settings';
import Auth from './components/Auth';
import UserProfileModal from './components/UserProfile';
import { ToastProvider } from './components/ui/Toast';
import { Barber, Service, Notification, Product, Role, MembershipPlan, SystemSettings, BusinessType, Client, UserProfile } from './types';

// Mock Data Global
const initialBarbers: Barber[] = [
  { 
    id: '1', 
    name: 'João Barber', 
    specialty: 'Fade Master', 
    avatar: 'https://images.unsplash.com/photo-1580273916550-e323be2eb5fa?auto=format&fit=crop&q=80&w=200', 
    commissionRate: 50,
    rating: 4.9,
    goal: 5000,
    currentSales: 4200,
    services: ['1', '2', '3', '4'],
    workSchedule: [
        { dayOfWeek: 1, startTime: '10:00', endTime: '19:00', active: false },
        { dayOfWeek: 2, startTime: '09:00', endTime: '20:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 3, startTime: '09:00', endTime: '20:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 4, startTime: '09:00', endTime: '20:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 5, startTime: '09:00', endTime: '21:00', breakStart: '14:00', breakEnd: '15:00', active: true },
        { dayOfWeek: 6, startTime: '08:00', endTime: '18:00', breakStart: '12:00', breakEnd: '12:30', active: true },
        { dayOfWeek: 0, startTime: '10:00', endTime: '14:00', active: false },
    ]
  },
  { 
    id: '2', 
    name: 'Pedro Cortes', 
    specialty: 'Barba & Navalha', 
    avatar: 'https://images.unsplash.com/photo-1618077360395-f3068be8e001?auto=format&fit=crop&q=80&w=200', 
    commissionRate: 45,
    rating: 4.7,
    goal: 4000,
    currentSales: 3800,
    services: ['1', '2', '3'],
    workSchedule: [
        { dayOfWeek: 1, startTime: '13:00', endTime: '20:00', active: true },
        { dayOfWeek: 2, startTime: '10:00', endTime: '19:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 3, startTime: '10:00', endTime: '19:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 4, startTime: '10:00', endTime: '19:00', breakStart: '13:00', breakEnd: '14:00', active: true },
        { dayOfWeek: 5, startTime: '10:00', endTime: '20:00', breakStart: '14:00', breakEnd: '15:00', active: true },
        { dayOfWeek: 6, startTime: '09:00', endTime: '19:00', breakStart: '13:00', breakEnd: '13:30', active: true },
        { dayOfWeek: 0, startTime: '10:00', endTime: '14:00', active: false },
    ]
  },
];

const initialServices: Service[] = [
  { 
    id: '1', 
    name: 'Corte Degradê', 
    description: 'Corte moderno com acabamento navalhado nas laterais.',
    price: 50, 
    duration: 45, 
    category: 'Corte', 
    active: true,
    commissionRate: 50,
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&q=80&w=300'
  },
  { 
    id: '2', 
    name: 'Barba Terapia', 
    description: 'Barba feita com toalha quente e massagem facial.',
    price: 40, 
    duration: 30, 
    category: 'Barba', 
    active: true,
    commissionRate: 50,
    image: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&q=80&w=300'
  },
  { 
    id: '3', 
    name: 'Combo (Corte + Barba)', 
    description: 'Pacote completo para visual renovado.',
    price: 80, 
    duration: 60, 
    category: 'Combo', 
    active: true,
    commissionRate: 55,
    image: 'https://images.unsplash.com/photo-1503951914875-befbb713d052?auto=format&fit=crop&q=80&w=300'
  },
  { 
    id: '4', 
    name: 'Pezinho / Sobrancelha', 
    description: 'Acabamento rápido.',
    price: 20, 
    duration: 15, 
    category: 'Outro', 
    active: true,
    image: 'https://images.unsplash.com/photo-1599351431202-6e0001074160?auto=format&fit=crop&q=80&w=300'
  },
  { 
    id: '5', 
    name: 'Platinado', 
    description: 'Descoloração global e matização.',
    price: 250, 
    duration: 180, 
    category: 'Tratamento', 
    active: false 
  },
];

const initialProducts: Product[] = [
  { id: '1', name: 'Pomada Matte Extra Forte', category: 'Pomada', price: 45.00, costPrice: 22.00, stock: 14, minStock: 5, commissionRate: 10 },
  { id: '2', name: 'Óleo de Barba Premium', category: 'Óleo', price: 35.00, costPrice: 15.00, stock: 3, minStock: 5, commissionRate: 10 },
  { id: '3', name: 'Shampoo Mentolado 300ml', category: 'Shampoo', price: 40.00, costPrice: 18.00, stock: 8, minStock: 4, commissionRate: 10 },
  { id: '4', name: 'Cerveja Artesanal IPA', category: 'Bebida', price: 12.00, costPrice: 6.00, stock: 24, minStock: 12, commissionRate: 0 },
];

const initialClients: Client[] = [
    {
      id: '1',
      name: 'Ricardo Oliveira',
      phone: '(11) 99999-8888',
      lastVisit: '2023-10-15',
      totalVisits: 12,
      tags: ['VIP', 'Corte Navalhado'],
      preferences: 'Corte baixo, sem pomada. Gosta de testar perfumes novos.',
      ltv: 1450.00,
      allergies: ['Alergia a lâminas de níquel (usar titânio)'],
      internalNotes: 'Cliente muito exigente com o pezinho. Gosta de café expresso duplo.',
      drinkPreference: 'Expresso Duplo',
      conversationStyle: 'Profissional',
      loyaltyTier: 'Prata',
      photos: []
    },
    {
      id: '2',
      name: 'Lucas Mendes',
      phone: '(11) 97777-6666',
      lastVisit: '2023-10-01',
      totalVisits: 3,
      tags: ['Atrasa', 'Risco Churn'],
      preferences: 'Degradê na zero.',
      ltv: 120.00,
      drinkPreference: 'Água com gás',
      conversationStyle: 'Quieto',
      loyaltyTier: 'Bronze',
      photos: []
    },
    {
      id: '3',
      name: 'Gustavo Lima',
      phone: '(11) 95555-4444',
      lastVisit: '2023-09-20',
      totalVisits: 24,
      tags: ['VIP', 'Mensalista'],
      preferences: 'Barba lenhador.',
      ltv: 2800.00,
      internalNotes: 'Torcedor fanático do Corinthians, evitar falar do Palmeiras.',
      conversationStyle: 'Conversador',
      loyaltyTier: 'Ouro',
      photos: []
    }
];

const membershipPlans: MembershipPlan[] = [
  {
    id: 'plan_1',
    name: 'Rei da Barba',
    price: 99.90,
    description: 'Barba ilimitada o mês todo.',
    benefits: ['Barba ilimitada', '10% OFF em produtos', 'Bebida grátis'],
    billingCycle: 'Mensal'
  },
  {
    id: 'plan_2',
    name: 'Visual Completo',
    price: 149.90,
    description: 'Corte e Barba quinzenal.',
    benefits: ['2 Cortes/mês', '2 Barbas/mês', 'Preferência na agenda', 'Bebida grátis'],
    billingCycle: 'Mensal'
  }
];

const initialNotifications: Notification[] = [
  { id: '1', type: 'payment', title: 'Pagamento Confirmado', message: 'Ricardo pagou R$ 50,00 via Pix.', time: '5min', read: false },
  { id: '2', type: 'appointment', title: 'Novo Agendamento', message: 'Carlos agendou Corte às 15:30.', time: '12min', read: false },
  { id: '3', type: 'cancel', title: 'Cancelamento', message: 'Lucas cancelou o horário de 18:00.', time: '1h', read: true },
];

// Initial Settings
const initialSettings: SystemSettings = {
  businessName: 'NS Studio',
  businessAddress: 'Av. Paulista, 1000 - SP',
  businessPhone: '(11) 99999-0000',
  businessEmail: 'contato@nsstudio.com',
  businessHours: [
    { dayOfWeek: 1, startTime: '09:00', endTime: '19:00', active: true }, // Seg
    { dayOfWeek: 2, startTime: '09:00', endTime: '19:00', active: true }, // Ter
    { dayOfWeek: 3, startTime: '09:00', endTime: '19:00', active: true }, // Qua
    { dayOfWeek: 4, startTime: '09:00', endTime: '20:00', active: true }, // Qui
    { dayOfWeek: 5, startTime: '09:00', endTime: '20:00', active: true }, // Sex
    { dayOfWeek: 6, startTime: '09:00', endTime: '16:00', active: true }, // Sáb
    { dayOfWeek: 0, startTime: '10:00', endTime: '14:00', active: false }, // Dom
  ],
  modules: {
    products: true,
    finance: true,
    aiChatbot: true,
    publicBooking: true,
    loyaltyProgram: true,
  },
  aiConfig: {
    enableInsights: true,
    insightTypes: {
      financial: true,
      churn: true,
      operational: true,
    },
    notificationFrequency: 'medium',
    tone: 'professional'
  }
};

const AppContent: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [businessType, setBusinessType] = useState<BusinessType>('barbershop');
  const [currentView, setCurrentView] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [showNotifications, setShowNotifications] = useState(false);
  
  // User Profile State
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    name: 'NS Studio Admin',
    email: 'admin@nsstudio.com',
    role: 'Admin',
    avatar: ''
  });
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  
  // Settings State
  const [settings, setSettings] = useState<SystemSettings>(initialSettings);
  
  // Data States
  const [barbers, setBarbers] = useState<Barber[]>(initialBarbers);
  const [services, setServices] = useState<Service[]>(initialServices);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [clients, setClients] = useState<Client[]>(initialClients);

  // Payment Config State (Persistent)
  const [paymentConfig, setPaymentConfig] = useState({
    isConnected: false,
    stripeKey: ''
  });

  // Apply Theme based on business type
  useEffect(() => {
    // When business type changes, update the body attribute
    document.body.setAttribute('data-theme', businessType);
  }, [businessType]);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  
  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllAsRead = () => {
     setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleLogin = (type: BusinessType) => {
    setBusinessType(type);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
      setIsAuthenticated(false);
      setIsProfileOpen(false);
      setCurrentView('dashboard'); // Reset view
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard': return <Dashboard settings={settings} onGoToSettings={() => setCurrentView('settings')} />;
      case 'calendar': return <Calendar barbers={barbers} services={services} products={products} clients={clients} settings={settings} />;
      case 'services': return <Services services={services} products={products} setServices={setServices} setProducts={setProducts} />;
      case 'clients': return <Clients clients={clients} setClients={setClients} />;
      case 'finance': return <Finance paymentConfig={paymentConfig} onSaveConfig={setPaymentConfig} barbers={barbers} userRole={currentUser.role} />;
      case 'team': return <Team barbers={barbers} services={services} />;
      case 'settings': return <Settings settings={settings} onUpdateSettings={setSettings} />;
      default: return <Dashboard settings={settings} />;
    }
  };

  // Auth Guard
  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  // Special view for Public Booking (Full Screen)
  if (currentView === 'public_booking') {
    return (
      <PublicBooking 
        services={services} 
        barbers={barbers} 
        membershipPlans={membershipPlans}
        onBack={() => setCurrentView('dashboard')} 
      />
    );
  }

  return (
    <div className="flex h-screen bg-barber-950 text-main overflow-hidden font-sans transition-colors duration-300">
      <Sidebar 
        currentView={currentView} 
        onChangeView={setCurrentView} 
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
        userRole={currentUser.role}
        settings={settings}
        onLogout={handleLogout}
      />

      {isProfileOpen && (
          <UserProfileModal 
            user={currentUser} 
            onSave={setCurrentUser} 
            onClose={() => setIsProfileOpen(false)} 
            onLogout={handleLogout}
          />
      )}

      <main className="flex-1 flex flex-col h-full relative overflow-hidden">
        {/* Top Header Mobile/Desktop */}
        <header className="h-16 border-b border-barber-800 bg-barber-950/80 backdrop-blur-md flex items-center justify-between px-4 sm:px-6 shrink-0 z-30 transition-colors duration-300">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="md:hidden text-muted hover:text-main">
              <Menu size={24} />
            </button>
            <h2 className="text-lg font-medium text-main md:hidden">NS <span className="text-barber-gold">Studio</span></h2>
            
            {/* Role Switcher (Simulator) - Hidden on Mobile */}
            <div className="hidden md:flex items-center gap-2 bg-barber-900 rounded-lg p-1 border border-barber-800">
               <button
                  onClick={() => setCurrentUser({...currentUser, role: 'Admin'})}
                  className={`px-3 py-1 rounded text-xs font-bold transition-colors ${currentUser.role === 'Admin' ? 'bg-barber-800 text-main shadow' : 'text-muted hover:text-main'}`}
               >
                  Admin
               </button>
               <button
                  onClick={() => setCurrentUser({...currentUser, role: 'Manager'})}
                  className={`px-3 py-1 rounded text-xs font-bold transition-colors ${currentUser.role === 'Manager' ? 'bg-barber-800 text-main shadow' : 'text-muted hover:text-main'}`}
               >
                  Manager
               </button>
               <button
                  onClick={() => setCurrentUser({...currentUser, role: 'Barber'})}
                  className={`px-3 py-1 rounded text-xs font-bold transition-colors ${currentUser.role === 'Barber' ? 'bg-barber-800 text-main shadow' : 'text-muted hover:text-main'}`}
               >
                  Barber
               </button>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Notification Bell */}
            <div className="relative">
               <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className={`relative p-2 transition-colors ${showNotifications ? 'text-main bg-barber-800 rounded-lg' : 'text-muted hover:text-main'}`}
               >
                  <Bell size={20} />
                  {unreadCount > 0 && (
                     <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-barber-950 animate-pulse"></span>
                  )}
               </button>

               {/* Notification Dropdown */}
               {showNotifications && (
                 <>
                   <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)}></div>
                   <div className="absolute right-0 top-12 w-80 bg-barber-900 border border-barber-800 rounded-xl shadow-2xl z-50 animate-fade-in overflow-hidden">
                      <div className="p-3 border-b border-barber-800 flex justify-between items-center bg-barber-950">
                         <h3 className="font-bold text-main text-sm">Notificações</h3>
                         {unreadCount > 0 && (
                            <button onClick={markAllAsRead} className="text-[10px] text-barber-gold hover:underline">Marcar lidas</button>
                         )}
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                         {notifications.map(notification => (
                            <div key={notification.id} className={`p-4 border-b border-barber-800 last:border-0 hover:bg-barber-800/30 transition-colors flex gap-3 ${!notification.read ? 'bg-barber-800/10' : ''}`}>
                               <div className={`mt-1 p-1.5 rounded-full shrink-0 h-fit ${
                                  notification.type === 'payment' ? 'bg-green-500/20 text-green-500' :
                                  notification.type === 'cancel' ? 'bg-red-500/20 text-red-500' :
                                  'bg-blue-500/20 text-blue-500'
                               }`}>
                                  {notification.type === 'payment' ? <CheckCircle2 size={14} /> : 
                                   notification.type === 'cancel' ? <X size={14} /> : <Bell size={14} />}
                               </div>
                               <div>
                                  <div className="flex justify-between items-start">
                                     <h4 className={`text-sm font-bold ${!notification.read ? 'text-main' : 'text-muted'}`}>{notification.title}</h4>
                                     <span className="text-xs text-muted">{notification.time}</span>
                                  </div>
                                  <p className="text-xs text-muted mt-0.5">{notification.message}</p>
                               </div>
                            </div>
                         ))}
                      </div>
                   </div>
                 </>
               )}
            </div>

            <div 
                className="flex items-center gap-3 pl-4 border-l border-barber-800 cursor-pointer group"
                onClick={() => setIsProfileOpen(true)}
            >
              <div className="text-right hidden sm:block">
                <div className="text-sm font-bold text-main group-hover:text-barber-gold transition-colors">
                    {currentUser.name}
                </div>
                <div className="text-xs text-barber-gold/70 group-hover:text-barber-gold">
                    {currentUser.role === 'Admin' ? 'Administrador' : currentUser.role === 'Manager' ? 'Gerente' : 'Barbeiro'}
                </div>
              </div>
              <div className="w-9 h-9 rounded-lg border border-barber-700 bg-barber-800 flex items-center justify-center overflow-hidden group-hover:border-barber-gold transition-colors">
                 {currentUser.avatar ? (
                     <img src={currentUser.avatar} alt="Profile" className="w-full h-full object-cover" />
                 ) : (
                     <User size={20} className="text-muted group-hover:text-main" />
                 )}
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
          <div className="max-w-7xl mx-auto">
             {renderContent()}
          </div>
        </div>

      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
};

export default App;
