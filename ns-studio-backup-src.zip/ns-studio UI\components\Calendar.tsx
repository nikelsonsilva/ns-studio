
import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Clock,
  MoreVertical,
  User,
  Filter,
  Ban,
  Search,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  DollarSign,
  Calendar as CalendarIcon,
  TrendingUp,
  Zap,
  MoreHorizontal,
  CreditCard,
  Banknote,
  X,
  Menu
} from 'lucide-react';
import { 
  format, 
  addDays, 
  subDays, 
  addMonths, 
  subMonths, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameDay, 
  isToday, 
  startOfMonth, 
  endOfMonth, 
  isSameMonth,
  setHours,
  setMinutes,
  differenceInMinutes
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Barber, Service, Product, Client, SystemSettings, Appointment, Status } from '../types';
import Button from './ui/Button';
import Select from './ui/Select';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Card from './ui/Card';
import Badge from './ui/Badge';
import Switch from './ui/Switch';
import { useToast } from './ui/Toast';

interface CalendarProps {
  barbers: Barber[];
  services: Service[];
  products: Product[];
  clients: Client[];
  settings: SystemSettings;
}

const Calendar: React.FC<CalendarProps> = ({ barbers, services, products, clients, settings }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  // Mini calendar navigation state
  const [miniCalendarMonth, setMiniCalendarMonth] = useState(new Date());
  
  const [selectedBarberId, setSelectedBarberId] = useState('all');
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [selectedSlotTime, setSelectedSlotTime] = useState<string | null>(null);
  
  // Mobile Sidebar State
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  
  // New Visual State
  const [highlightFreeSlots, setHighlightFreeSlots] = useState(false);

  // Real-time Clock
  const [currentTime, setCurrentTime] = useState(new Date());

  const toast = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);

  // Update clock every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    // Auto-scroll to current time on mount (simple implementation)
    if (scrollRef.current && isToday(currentDate)) {
       // Scroll logic requires careful calculation of offset, skipping for now to keep it simple
    }
    return () => clearInterval(timer);
  }, [currentDate]);

  // Mock appointments
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: '1',
      clientName: 'Ana Silva',
      barberId: '1',
      serviceId: '1',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '09:00',
      status: Status.COMPLETED,
      hasDeposit: false
    },
    {
      id: '2',
      clientName: 'Carlos Oliveira',
      barberId: '2',
      serviceId: '2',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '10:00',
      status: Status.CONFIRMED,
      hasDeposit: false
    },
    {
      id: '3',
      clientName: 'Roberto Santos',
      barberId: '1',
      serviceId: '3',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '14:30',
      status: Status.PENDING,
      hasDeposit: true
    },
    {
      id: '4',
      clientName: 'Felipe Neto',
      barberId: '2',
      serviceId: '4',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '16:00',
      status: Status.CONFIRMED,
      hasDeposit: false
    },
    {
      id: '5',
      clientName: 'Pausa Almoço',
      barberId: '1',
      serviceId: '0', // Mock ID for internal block
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '12:00',
      status: Status.BLOCKED,
      hasDeposit: false
    }
  ]);

  // --- Handlers ---
  const handlePrevMonth = () => setMiniCalendarMonth(subMonths(miniCalendarMonth, 1));
  const handleNextMonth = () => setMiniCalendarMonth(addMonths(miniCalendarMonth, 1));
  
  const onDateClick = (day: Date) => {
      setCurrentDate(day);
      if (window.innerWidth < 1280) {
          setIsMobileSidebarOpen(false); // Close mobile drawer on selection
      }
  };

  const handleOpenNewAppointment = (time?: string) => {
      setSelectedSlotTime(time || '09:00');
      setIsAppointmentModalOpen(true);
  };

  const handlePrevDay = () => setCurrentDate(subDays(currentDate, 1));
  const handleNextDay = () => setCurrentDate(addDays(currentDate, 1));
  const handleToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setMiniCalendarMonth(today);
  };

  // --- Helpers for Grid ---
  // Generate Hours: 08:00 to 20:00
  const startHour = 8;
  const endHour = 20;
  const timeSlots = Array.from({ length: endHour - startHour + 1 }, (_, i) => startHour + i);

  // Mini Calendar Generation
  const generateCalendarGrid = () => {
      const monthStart = startOfMonth(miniCalendarMonth);
      const monthEnd = endOfMonth(monthStart);
      const startDate = startOfWeek(monthStart);
      const endDate = endOfWeek(monthEnd);
      return eachDayOfInterval({ start: startDate, end: endDate });
  };
  const calendarDays = generateCalendarGrid();
  const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

  // --- Stats Calculation (Cockpit) ---
  const dailyAppointments = appointments.filter(a => isSameDay(new Date(a.date), currentDate));
  const dailyRevenue = dailyAppointments.reduce((acc, curr) => {
      if (curr.status === Status.CANCELED || curr.status === Status.BLOCKED) return acc;
      const service = services.find(s => s.id === curr.serviceId);
      return acc + (service?.price || 0);
  }, 0);
  const occupancyRate = Math.round((dailyAppointments.filter(a => a.status !== Status.BLOCKED).length / (timeSlots.length * barbers.length)) * 100);

  // --- Visual Helpers ---
  
  // Define semantic styles for appointment cards
  const getAppointmentStyles = (status: Status) => {
      switch(status) {
          case Status.CONFIRMED: 
              return { border: 'border-l-emerald-500', bg: 'bg-emerald-500/10', text: 'text-emerald-100', icon: CheckCircle2 };
          case Status.COMPLETED: 
              return { border: 'border-l-gray-500', bg: 'bg-gray-500/10', text: 'text-gray-400', opacity: 'opacity-70', icon: CheckCircle2 };
          case Status.PENDING: 
              return { border: 'border-l-blue-500', bg: 'bg-blue-500/10', text: 'text-blue-100', icon: Clock };
          case Status.CANCELED: 
              return { border: 'border-l-red-500', bg: 'bg-red-500/10', text: 'text-red-100', decoration: 'line-through', icon: Ban };
          case Status.BLOCKED: 
              return { border: 'border-l-amber-500', bg: 'bg-amber-500/10', text: 'text-amber-100', pattern: true, icon: Ban }; // Pattern logic handled in CSS/Inline
          default: 
              return { border: 'border-l-gray-500', bg: 'bg-gray-500/10', text: 'text-gray-200', icon: MoreHorizontal };
      }
  };

  // Business Hours Logic for background styling (lighter during day, darker early/late)
  const isBusinessHour = (hour: number) => hour >= 9 && hour < 19;

  // Current Time Line Logic
  const getCurrentTimePosition = () => {
      const now = currentTime;
      if (!isSameDay(now, currentDate)) return null;
      
      const currentHour = now.getHours();
      const currentMin = now.getMinutes();
      
      if (currentHour < startHour || currentHour > endHour) return null;

      // This object helps us render the line inside the correct hour slot
      return { hour: currentHour, percent: (currentMin / 60) * 100 };
  };
  const timeIndicator = getCurrentTimePosition();

  return (
    <div className="flex flex-col xl:flex-row gap-6 h-[calc(100vh-80px)] md:h-[calc(100vh-100px)] animate-fade-in pb-0 md:pb-4 relative">
        
        {/* === MOBILE OVERLAY (Drawer) === */}
        {isMobileSidebarOpen && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm xl:hidden" onClick={() => setIsMobileSidebarOpen(false)} />
        )}

        {/* === LEFT SIDEBAR (Responsive) === */}
        <div className={`
            fixed inset-y-0 left-0 z-50 w-80 bg-barber-950 border-r border-barber-800 transform transition-transform duration-300 ease-in-out p-6 flex flex-col gap-6 overflow-y-auto
            ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
            xl:translate-x-0 xl:static xl:w-80 xl:p-0 xl:bg-transparent xl:border-0 xl:overflow-visible xl:flex
        `}>
            {/* Mobile Header for Sidebar */}
            <div className="flex items-center justify-between xl:hidden mb-2">
                <h3 className="text-lg font-bold text-main">Calendário & Filtros</h3>
                <button onClick={() => setIsMobileSidebarOpen(false)} className="p-2 bg-barber-800 rounded-full text-white">
                    <X size={20} />
                </button>
            </div>

            {/* 1. Mini Calendar (Navigation) */}
            <Card noPadding className="p-4 bg-barber-950 border-barber-800 shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <button onClick={handlePrevMonth} className="p-1 hover:bg-barber-800 rounded text-muted hover:text-main"><ChevronLeft size={16}/></button>
                    <span className="font-bold text-main capitalize text-sm">
                        {format(miniCalendarMonth, 'MMMM yyyy', { locale: ptBR })}
                    </span>
                    <button onClick={handleNextMonth} className="p-1 hover:bg-barber-800 rounded text-muted hover:text-main"><ChevronRight size={16}/></button>
                </div>
                
                <div className="grid grid-cols-7 mb-2">
                    {weekDays.map(day => (
                        <div key={day} className="text-center text-[10px] font-bold text-muted h-6 flex items-center justify-center">
                            {day}
                        </div>
                    ))}
                </div>
                
                <div className="grid grid-cols-7 gap-1">
                    {calendarDays.map((day, idx) => {
                        const isSelected = isSameDay(day, currentDate);
                        const isCurrentMonth = isSameMonth(day, miniCalendarMonth);
                        const isDayToday = isToday(day);
                        const hasEvents = appointments.some(a => isSameDay(new Date(a.date), day));
                        
                        return (
                            <button
                                key={idx}
                                onClick={() => onDateClick(day)}
                                className={`
                                    h-8 w-8 rounded-full flex items-center justify-center text-xs font-medium transition-all relative
                                    ${!isCurrentMonth ? 'text-gray-600 opacity-30' : 'text-main'}
                                    ${isSelected ? 'bg-barber-gold text-inverted font-bold shadow-md shadow-amber-500/20 scale-105' : 'hover:bg-barber-800'}
                                    ${isDayToday && !isSelected ? 'border border-barber-gold text-barber-gold' : ''}
                                `}
                            >
                                {format(day, 'd')}
                                {hasEvents && !isSelected && (
                                    <span className="absolute bottom-1 w-1 h-1 bg-barber-800 rounded-full"></span>
                                )}
                            </button>
                        );
                    })}
                </div>
            </Card>

            {/* 2. "Available Now" Widget (Compact & Operational) */}
            <Card noPadding className="flex-1 min-h-[300px] xl:min-h-0 bg-barber-950 border-barber-800 flex flex-col overflow-hidden shadow-md">
                <div className="p-4 border-b border-barber-800 bg-barber-900/30">
                   <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-2">
                         <div className="bg-emerald-500/10 p-1.5 rounded-md animate-pulse">
                            <Zap size={16} className="text-emerald-500" />
                         </div>
                         <div>
                            <h3 className="font-bold text-main text-sm leading-none">Disponíveis agora</h3>
                            <span className="text-[10px] text-muted">{format(currentTime, 'HH:mm')} • Tempo Real</span>
                         </div>
                      </div>
                      <button className="p-1.5 text-muted hover:text-white bg-barber-900 rounded border border-barber-800 hover:border-barber-700 transition-colors">
                         <Filter size={14} />
                      </button>
                   </div>

                   {/* Toggle Highlight */}
                   <div className="flex items-center justify-between bg-black/20 p-2 rounded-lg border border-white/5">
                       <span className="text-[10px] text-muted font-bold uppercase tracking-wide">Destacar na Grade</span>
                       <Switch checked={highlightFreeSlots} onCheckedChange={setHighlightFreeSlots} />
                   </div>
                </div>

                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                    {barbers.map((barber, index) => {
                       // Mock logic: Calculate "Free Until"
                       const freeUntil = index === 0 ? '18:00' : '19:30';
                       const nextBusy = index === 0 ? 120 : 45; // minutes free
                       const progressColor = nextBusy > 60 ? 'bg-emerald-500' : 'bg-amber-500';

                       return (
                          <div key={barber.id} className="border border-barber-800 rounded-xl p-3 hover:border-barber-700 transition-all cursor-pointer group bg-barber-900/20 hover:bg-barber-900/60 relative overflow-hidden">
                             {/* Progress Bar Background */}
                             <div className="absolute bottom-0 left-0 h-1 bg-barber-800 w-full">
                                <div className={`h-full ${progressColor}`} style={{ width: `${Math.min(nextBusy, 100)}%` }}></div>
                             </div>

                             <div className="flex items-center gap-3 mb-2">
                                <div className="w-8 h-8 rounded-full bg-barber-800 border border-barber-700 overflow-hidden shrink-0">
                                   {barber.avatar ? <img src={barber.avatar} className="w-full h-full object-cover" /> : <span className="flex items-center justify-center h-full text-xs font-bold">{barber.name[0]}</span>}
                                </div>
                                <div className="flex-1 min-w-0">
                                   <div className="flex justify-between items-center">
                                      <h4 className="font-bold text-main text-sm truncate">{barber.name}</h4>
                                      <span className="text-[10px] text-emerald-500 font-bold bg-emerald-500/10 px-1.5 rounded">Livre</span>
                                   </div>
                                   <div className="flex items-center gap-1.5 text-[10px] text-muted mt-0.5">
                                      <span>Até {freeUntil}</span>
                                      <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                                      <span>{nextBusy} min livres</span>
                                   </div>
                                </div>
                             </div>
                          </div>
                       );
                    })}
                </div>
            </Card>
        </div>

        {/* === MAIN AREA (Cockpit & Timeline) === */}
        <div className="flex-1 flex flex-col bg-input-bg border border-barber-800 rounded-xl overflow-hidden shadow-xl relative h-full">
            
            {/* 3. Cockpit Header (Stats & Controls) */}
            <div className="flex flex-col border-b border-barber-800 bg-barber-950 z-20 shadow-sm">
                
                {/* Top Row: Date & Main Actions */}
                <div className="p-3 sm:p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 sm:gap-4">
                    <div className="flex items-center justify-between w-full md:w-auto gap-4">
                        <div className="flex items-center gap-3">
                            {/* Mobile Sidebar Toggle */}
                            <button 
                                onClick={() => setIsMobileSidebarOpen(true)} 
                                className="xl:hidden p-2 bg-barber-900 border border-barber-800 rounded-lg text-muted hover:text-white"
                            >
                                <CalendarIcon size={20} />
                            </button>

                            <div className="flex items-center bg-barber-900 rounded-lg p-1 border border-barber-800 shadow-inner">
                                <button onClick={handlePrevDay} className="p-1.5 hover:bg-barber-800 rounded text-muted hover:text-white transition-colors"><ChevronLeft size={18}/></button>
                                <button onClick={handleToday} className="px-3 py-1 text-xs font-bold text-main hover:bg-barber-800 rounded transition-colors uppercase tracking-wider hidden sm:block">Hoje</button>
                                <button onClick={handleNextDay} className="p-1.5 hover:bg-barber-800 rounded text-muted hover:text-white transition-colors"><ChevronRight size={18}/></button>
                            </div>
                            <div>
                                <h2 className="text-lg sm:text-xl font-bold text-main capitalize leading-none flex items-center gap-2">
                                {format(currentDate, 'EEEE, d', { locale: ptBR })} 
                                </h2>
                                <span className="text-[10px] sm:text-xs text-muted font-medium uppercase tracking-wide">
                                    {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                                </span>
                            </div>
                        </div>

                         <div className="md:hidden">
                            <Button onClick={() => handleOpenNewAppointment()} size="icon" className="rounded-full w-10 h-10 shadow-lg bg-barber-gold text-black">
                                <Plus size={20} />
                            </Button>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 sm:gap-3 w-full md:w-auto">
                        <Select 
                            value={selectedBarberId}
                            onChange={(e) => setSelectedBarberId(e.target.value)}
                            options={[
                                { value: 'all', label: 'Todos Profissionais' },
                                ...barbers.map(b => ({ value: b.id, label: b.name }))
                            ]}
                            className="bg-barber-900 border-barber-800 text-xs h-9 py-0 flex-1 sm:w-48 shadow-sm"
                            icon={<Filter size={12} />}
                        />
                        
                        {/* Desktop Add Button */}
                        <div className="hidden md:block relative group">
                            <Button onClick={() => handleOpenNewAppointment()} size="sm" leftIcon={<Plus size={16} />}>
                                Novo
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Bottom Row: Daily KPIs (Cockpit) - Scrollable on Mobile */}
                <div className="px-3 sm:px-4 pb-3 flex items-center gap-4 sm:gap-6 overflow-x-auto border-t border-barber-800/50 pt-3 bg-barber-900/30 scrollbar-hide">
                    <div className="flex items-center gap-3 pr-4 sm:pr-6 border-r border-barber-800/50 min-w-fit">
                        <div className="p-1.5 sm:p-2 bg-blue-500/10 rounded-lg text-blue-400"><CalendarIcon size={14} className="sm:w-4 sm:h-4" /></div>
                        <div>
                            <span className="block text-[10px] text-muted uppercase font-bold">Agendamentos</span>
                            <span className="block font-bold text-main text-xs sm:text-sm">{dailyAppointments.length} <span className="text-[10px] text-muted font-normal">hoje</span></span>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 pr-4 sm:pr-6 border-r border-barber-800/50 min-w-fit">
                        <div className="p-1.5 sm:p-2 bg-emerald-500/10 rounded-lg text-emerald-400"><DollarSign size={14} className="sm:w-4 sm:h-4" /></div>
                        <div>
                            <span className="block text-[10px] text-muted uppercase font-bold">Faturamento Prev.</span>
                            <span className="block font-bold text-emerald-400 text-xs sm:text-sm">R$ {dailyRevenue.toFixed(0)}</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 min-w-fit">
                        <div className="p-1.5 sm:p-2 bg-amber-500/10 rounded-lg text-amber-400"><TrendingUp size={14} className="sm:w-4 sm:h-4" /></div>
                        <div>
                            <span className="block text-[10px] text-muted uppercase font-bold">Ocupação</span>
                            <span className="block font-bold text-amber-400 text-xs sm:text-sm">{occupancyRate}%</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* 4. Timeline Scroll Area */}
            <div className="flex-1 overflow-y-auto relative bg-barber-950 scroll-smooth touch-pan-y" ref={scrollRef}>
                
                {timeSlots.map((hour, index) => {
                    const timeString = `${hour.toString().padStart(2, '0')}:00`;
                    
                    // Filter appointments for this slot
                    const slotAppointments = appointments.filter(apt => {
                        const aptDate = new Date(apt.date);
                        const aptHour = parseInt(apt.time.split(':')[0]);
                        const isCorrectDate = isSameDay(aptDate, currentDate);
                        const isCorrectHour = aptHour === hour;
                        const isCorrectBarber = selectedBarberId === 'all' || apt.barberId === selectedBarberId;
                        return isCorrectDate && isCorrectHour && isCorrectBarber;
                    });

                    // Check if this hour contains the current time line
                    const isCurrentHourSlot = timeIndicator && timeIndicator.hour === hour;
                    
                    // Styling for Business Hours vs Off Hours
                    const isWorkingHour = isBusinessHour(hour);
                    const bgClass = isWorkingHour 
                        ? 'bg-transparent' // Standard background
                        : 'bg-[#000000]/30'; // Slightly darker for off-hours

                    return (
                        <div key={hour} className={`group relative flex border-b border-barber-800/40 min-h-[100px] sm:min-h-[120px] transition-colors ${bgClass}`}>
                            
                            {/* Time Column */}
                            <div className="w-12 sm:w-16 py-2 sm:py-3 text-right pr-2 sm:pr-4 shrink-0 border-r border-barber-800/40 relative bg-barber-950/50 backdrop-blur-sm z-10">
                                <span className={`text-[10px] sm:text-xs font-bold block sticky top-2 transition-colors ${isWorkingHour ? 'text-muted' : 'text-gray-700'}`}>
                                    {timeString}
                                </span>
                            </div>

                            {/* Content Column */}
                            <div className="flex-1 relative p-1 sm:p-2">
                                
                                {/* Vertical Grid Lines (for visual rhythm) */}
                                <div className="absolute inset-y-0 left-0 w-px bg-barber-800/10"></div>
                                <div className="absolute inset-y-0 left-1/2 w-px bg-barber-800/10"></div>

                                {/* Current Time Line Indicator */}
                                {isCurrentHourSlot && (
                                    <div 
                                        className="absolute left-0 right-0 h-[2px] bg-red-500 z-10 flex items-center pointer-events-none shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                                        style={{ top: `${timeIndicator.percent}%` }}
                                    >
                                        <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-red-500 -ml-1 sm:-ml-1.5 border-2 border-barber-950"></div>
                                        <div className="absolute left-2 bg-red-500 text-white text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 rounded-r-md shadow-sm">
                                            {format(currentTime, 'HH:mm')}
                                        </div>
                                    </div>
                                )}

                                {/* Slot Content Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 sm:gap-3 h-full relative z-0">
                                    {slotAppointments.length > 0 ? (
                                        slotAppointments.map(apt => {
                                            const barber = barbers.find(b => b.id === apt.barberId);
                                            const service = services.find(s => s.id === apt.serviceId);
                                            
                                            // Status Styling
                                            const styles = getAppointmentStyles(apt.status);
                                            const StatusIcon = styles.icon;
                                            
                                            return (
                                                <div 
                                                    key={apt.id} 
                                                    className={`
                                                        relative rounded-lg border-l-[3px] sm:border-l-[4px] p-2 sm:p-3 transition-all cursor-pointer shadow-sm
                                                        ${styles.border} ${styles.bg} ${styles.opacity || ''}
                                                        active:scale-95 hover:brightness-110 hover:shadow-md hover:-translate-y-0.5
                                                        flex flex-col justify-between
                                                    `}
                                                    style={styles.pattern ? { backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '4px 4px', backgroundOpacity: 0.1 } : {}}
                                                    onClick={() => toast.info(`Detalhes: ${apt.clientName}`)}
                                                >
                                                    <div>
                                                        <div className="flex justify-between items-start mb-0.5 sm:mb-1">
                                                            <span className={`font-bold text-xs sm:text-sm text-white truncate ${styles.decoration || ''}`}>{apt.clientName}</span>
                                                            <div className="flex gap-1">
                                                                {/* Payment Badge Mock */}
                                                                {!apt.hasDeposit && apt.status !== Status.BLOCKED && (
                                                                    <div title="Pagamento Pendente" className="bg-black/20 p-0.5 rounded text-amber-400"><Banknote size={10} /></div>
                                                                )}
                                                            </div>
                                                        </div>
                                                        <div className={`text-[10px] sm:text-xs truncate mb-1 sm:mb-2 ${styles.text}`}>
                                                            {apt.status === Status.BLOCKED ? 'Bloqueio de Agenda' : service?.name}
                                                        </div>
                                                    </div>

                                                    <div className="flex items-center justify-between pt-1 sm:pt-2 border-t border-white/5 mt-auto">
                                                        <div className="flex items-center gap-1.5">
                                                            {barber?.avatar ? (
                                                                <img src={barber.avatar} className="w-3 h-3 sm:w-4 sm:h-4 rounded-full border border-white/10" />
                                                            ) : (
                                                                <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-white/20 flex items-center justify-center text-[8px]">{barber?.name.charAt(0)}</div>
                                                            )}
                                                            <span className="text-[9px] sm:text-[10px] opacity-70 truncate max-w-[60px] sm:max-w-[80px]">{barber?.name.split(' ')[0]}</span>
                                                        </div>
                                                        <div className={`text-[9px] sm:text-[10px] uppercase font-bold flex items-center gap-1 ${styles.text}`}>
                                                            <StatusIcon size={10} /> {apt.time}
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    ) : (
                                        /* Ghost Button on Hover (Touch friendly for mobile) */
                                        <div className={`col-span-full h-full w-full ${isMobileSidebarOpen ? '' : 'flex'} items-center px-2 sm:px-4`}>
                                            <button 
                                                onClick={() => handleOpenNewAppointment(timeString)}
                                                className={`
                                                    flex items-center gap-2 text-[10px] sm:text-xs font-bold text-barber-gold bg-barber-950/90 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full border border-barber-800 shadow-lg
                                                    opacity-0 group-hover:opacity-100 transition-all duration-200
                                                    ${highlightFreeSlots ? 'opacity-100' : ''}
                                                    active:opacity-100 active:scale-95
                                                `}
                                            >
                                                <Plus size={12} className="sm:w-3.5 sm:h-3.5" /> Agendar {timeString}
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
                
                {/* Bottom Spacer */}
                <div className="h-24 flex items-center justify-center text-[10px] sm:text-xs text-muted/30 uppercase font-bold tracking-widest">
                    Fim do Expediente
                </div>
            </div>
        </div>

        {/* Modal for New Appointment */}
        <Modal
            isOpen={isAppointmentModalOpen}
            onClose={() => setIsAppointmentModalOpen(false)}
            title="Novo Agendamento"
            footer={
                <>
                    <Button variant="ghost" onClick={() => setIsAppointmentModalOpen(false)}>Cancelar</Button>
                    <Button variant="primary" onClick={() => {
                        toast.success('Agendamento criado com sucesso!');
                        setIsAppointmentModalOpen(false);
                    }}>Confirmar</Button>
                </>
            }
        >
            <div className="space-y-4">
                <Input label="Nome do Cliente" placeholder="Buscar cliente..." icon={<Search size={16} />} />
                <div className="grid grid-cols-2 gap-4">
                    <Input label="Data" type="date" defaultValue={format(currentDate, 'yyyy-MM-dd')} />
                    <Input label="Hora" type="time" defaultValue={selectedSlotTime || "09:00"} />
                </div>
                <Select 
                    label="Profissional" 
                    options={barbers.map(b => ({ value: b.id, label: b.name }))}
                />
                <Select 
                    label="Serviço" 
                    options={services.map(s => ({ value: s.id, label: s.name }))}
                />
            </div>
        </Modal>

    </div>
  );
};

export default Calendar;
