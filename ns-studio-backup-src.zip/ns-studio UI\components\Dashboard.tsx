
import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  Scissors, 
  AlertCircle, 
  MessageCircle, 
  CheckCircle2, 
  Clock,
  Sparkles,
  ArrowRight,
  Target,
  Plus,
  DollarSign,
  Lock,
  Zap,
  Settings as SettingsIcon,
  XCircle
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { SystemSettings } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import { useToast } from './ui/Toast';

const data = [
  { name: 'Seg', total: 1200 },
  { name: 'Ter', total: 1450 },
  { name: 'Qua', total: 1300 },
  { name: 'Qui', total: 1900 },
  { name: 'Sex', total: 2800 },
  { name: 'Sáb', total: 3200 },
  { name: 'Dom', total: 800 },
];

const pendingRequests = [
  { id: 1, name: 'Carlos Eduardo', service: 'Corte + Barba', time: '14:30', source: 'WhatsApp' },
  { id: 2, name: 'Marcos Silva', service: 'Degradê Navalhado', time: '16:00', source: 'Instagram' },
];

const chairs = [
  { id: 1, barber: 'João Barber', client: 'Roberto S.', service: 'Corte Degradê', start: '14:00', duration: 45, elapsed: 30, status: 'busy' },
  { id: 2, barber: 'Pedro Cortes', client: 'Disponível', service: '-', start: '-', duration: 0, elapsed: 0, status: 'free' },
  { id: 3, barber: 'Matheus Jr', client: 'Felipe Neto', service: 'Barba Terapia', start: '14:15', duration: 30, elapsed: 15, status: 'busy' },
];

const financialGoal = { current: 14250, target: 20000 };

interface DashboardProps {
    settings?: SystemSettings;
    onGoToSettings?: () => void;
}

const StatCard = ({ title, value, subtext, icon: Icon, trend }: any) => (
  <Card className="hover:border-barber-700 transition-colors" noPadding>
    <div className="p-6">
        <div className="flex justify-between items-start mb-4">
        <div className="p-3 bg-barber-800 rounded-lg text-barber-gold">
            <Icon size={24} />
        </div>
        {trend && (
            <span className={`text-sm font-medium ${trend > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
            {trend > 0 ? '+' : ''}{trend}%
            </span>
        )}
        </div>
        <h3 className="text-muted text-sm font-medium uppercase tracking-wider mb-1">{title}</h3>
        <div className="text-3xl font-bold text-main mb-1">{value}</div>
        <p className="text-muted text-xs">{subtext}</p>
    </div>
  </Card>
);

const AIInsightCard = ({ text, type, onClick }: { text: string, type: 'financial' | 'operational' | 'churn', onClick?: () => void }) => (
    <div 
        onClick={onClick}
        className="bg-barber-950 border border-barber-800 p-4 rounded-xl flex items-start gap-3 relative overflow-hidden group hover:border-barber-gold/30 transition-all cursor-pointer shadow-sm"
    >
        <div className={`absolute top-0 left-0 w-1 h-full ${type === 'financial' ? 'bg-emerald-500' : type === 'operational' ? 'bg-sky-500' : 'bg-rose-500'}`}></div>
        <div className="bg-barber-900 p-2 rounded-full shrink-0">
            <Sparkles size={16} className="text-barber-gold" />
        </div>
        <div>
            <h4 className="text-main text-sm font-bold mb-1 flex items-center gap-2">
                IA Insight
                <span className="text-[9px] text-muted bg-barber-900 border border-barber-800 px-1.5 rounded uppercase">{type}</span>
            </h4>
            <p className="text-muted text-xs leading-relaxed">{text}</p>
        </div>
        <button className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity text-muted hover:text-main">
            <ArrowRight size={16} />
        </button>
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ settings, onGoToSettings }) => {
  const [isFabOpen, setIsFabOpen] = useState(false);
  const toast = useToast();

  const goalProgress = (financialGoal.current / financialGoal.target) * 100;

  // Determine which insights to show based on settings
  const showFinancial = settings?.aiConfig.enableInsights && settings?.aiConfig.insightTypes.financial;
  const showOperational = settings?.aiConfig.enableInsights && settings?.aiConfig.insightTypes.operational;
  const showChurn = settings?.aiConfig.enableInsights && settings?.aiConfig.insightTypes.churn;

  return (
    <div className="space-y-6 animate-fade-in pb-20 relative">
      
      {/* Quick Actions FAB */}
      <div className="fixed bottom-6 left-6 z-40 flex flex-col-reverse items-start gap-3">
        <button 
          onClick={() => setIsFabOpen(!isFabOpen)}
          className={`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 ${isFabOpen ? 'bg-barber-800 text-white rotate-45' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
        >
          <Zap size={24} fill="currentColor" />
        </button>
        
        {isFabOpen && (
          <div className="flex flex-col-reverse gap-3 animate-fade-in">
             <button className="flex items-center gap-2 bg-barber-900 border border-barber-800 text-main px-4 py-2 rounded-full shadow-xl hover:bg-barber-800 transition-colors group">
                <span className="text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity absolute left-14 bg-barber-950 px-2 py-1 rounded">Novo Agendamento</span>
                <Plus size={20} className="text-emerald-500" />
             </button>
             {settings?.modules.finance && (
                <button className="flex items-center gap-2 bg-barber-900 border border-barber-800 text-main px-4 py-2 rounded-full shadow-xl hover:bg-barber-800 transition-colors group">
                    <span className="text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity absolute left-14 bg-barber-950 px-2 py-1 rounded">Lançar Despesa</span>
                    <DollarSign size={20} className="text-rose-500" />
                </button>
             )}
             <button className="flex items-center gap-2 bg-barber-900 border border-barber-800 text-main px-4 py-2 rounded-full shadow-xl hover:bg-barber-800 transition-colors group">
                <span className="text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity absolute left-14 bg-barber-950 px-2 py-1 rounded">Bloquear Agenda</span>
                <Lock size={20} className="text-amber-500" />
             </button>
          </div>
        )}
      </div>

      {/* Goal vs Realized Widget - Only if Finance enabled */}
      {settings?.modules.finance && (
        <div className="bg-gradient-to-r from-barber-900 to-barber-950 border border-barber-800 rounded-xl p-6 shadow-lg relative overflow-hidden">
            <div className="absolute right-0 top-0 p-8 opacity-5 pointer-events-none">
                <Target size={120} />
            </div>
            <div className="relative z-10 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6">
                <div className="flex-1 w-full">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-4 gap-2">
                      <div>
                          <h2 className="text-lg font-bold text-main flex items-center gap-2">
                              <Target className="text-barber-gold" size={20} /> Meta Mensal
                          </h2>
                          <p className="text-xs text-muted">Progresso atual de faturamento</p>
                      </div>
                      <div className="text-left sm:text-right w-full sm:w-auto mt-2 sm:mt-0 bg-barber-950/50 p-2 rounded-lg sm:bg-transparent sm:p-0">
                          <div className="text-2xl font-bold text-main">R$ {financialGoal.current.toLocaleString('pt-BR')}</div>
                          <div className="text-xs text-muted">Meta: R$ {financialGoal.target.toLocaleString('pt-BR')}</div>
                      </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="h-4 w-full bg-barber-950 rounded-full border border-barber-800 overflow-hidden relative">
                      <div 
                          className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full transition-all duration-1000 ease-out relative"
                          style={{ width: `${Math.min(goalProgress, 100)}%` }}
                      >
                          <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]"></div>
                      </div>
                      {/* Goal Marker */}
                      <div className="absolute top-0 bottom-0 w-0.5 bg-white/50 z-20 right-0" style={{ left: '100%' }}></div>
                  </div>
                  <div className="mt-2 flex justify-between text-xs font-medium">
                      <span className="text-emerald-500">{goalProgress.toFixed(1)}% Atingido</span>
                      <span className="text-muted">Faltam R$ {(financialGoal.target - financialGoal.current).toLocaleString('pt-BR')}</span>
                  </div>
                </div>
                
                <div className="shrink-0 flex w-full lg:w-auto items-center justify-between lg:justify-start gap-4 lg:border-l lg:border-barber-800 lg:pl-6 pt-4 lg:pt-0 border-t border-barber-800 lg:border-t-0">
                  <div className="text-center flex-1 lg:flex-none">
                      <div className="text-xs text-muted uppercase font-bold">Projeção</div>
                      <div className="text-xl font-bold text-sky-400">R$ 22.5k</div>
                  </div>
                  <div className="text-center flex-1 lg:flex-none">
                      <div className="text-xs text-muted uppercase font-bold">Média Dia</div>
                      <div className="text-xl font-bold text-barber-gold">R$ 950</div>
                  </div>
                </div>
            </div>
        </div>
      )}

      {/* Real-time Chairs Widget */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
         {chairs.map(chair => {
            const progress = chair.duration > 0 ? (chair.elapsed / chair.duration) * 100 : 0;
            const isBusy = chair.status === 'busy';
            return (
               <Card key={chair.id} noPadding className={`p-4 group ${isBusy ? '' : 'opacity-80'}`}>
                  <div className="flex justify-between items-start mb-3">
                     <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${isBusy ? 'bg-barber-gold text-black' : 'bg-barber-800 text-muted'}`}>
                           {chair.id}
                        </div>
                        <div>
                           <div className="text-xs text-muted uppercase font-bold">Cadeira {chair.id}</div>
                           <div className="font-bold text-main text-sm">{chair.barber}</div>
                        </div>
                     </div>
                     {/* Use Icons along with colors for accessibility */}
                     <div className={`flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${isBusy ? 'bg-rose-500/10 text-rose-500' : 'bg-emerald-500/10 text-emerald-500'}`}>
                        {isBusy ? <Clock size={12} /> : <CheckCircle2 size={12} />}
                        {isBusy ? 'Ocupada' : 'Livre'}
                     </div>
                  </div>

                  {isBusy ? (
                     <div className="space-y-3">
                        <div className="flex justify-between items-center text-xs">
                           <span className="text-muted font-medium">{chair.client}</span>
                           <span className="text-barber-gold">{chair.service}</span>
                        </div>
                        
                        <div className="relative pt-1">
                           <div className="flex mb-1 items-center justify-between">
                              <span className="text-[10px] font-semibold inline-block text-muted">
                                 {chair.elapsed} min
                              </span>
                              <span className="text-[10px] font-semibold inline-block text-muted">
                                 {chair.duration} min
                              </span>
                           </div>
                           <div className="overflow-hidden h-1.5 mb-1 text-xs flex rounded bg-barber-950 border border-barber-800">
                              <div style={{ width: `${progress}%` }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-sky-500 transition-all duration-1000"></div>
                           </div>
                        </div>
                        <div className="text-[10px] text-right text-emerald-400 font-bold">
                           Termina em {chair.duration - chair.elapsed} min
                        </div>
                     </div>
                  ) : (
                     <div className="h-[74px] flex items-center justify-center flex-col text-muted">
                        <CheckCircle2 size={24} className="mb-1 opacity-50" />
                        <span className="text-xs font-medium">Aguardando Cliente</span>
                     </div>
                  )}
               </Card>
            )
         })}
      </div>

      {/* AI Insights Section */}
      {settings?.aiConfig.enableInsights && (showOperational || showChurn || showFinancial) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {showOperational && (
                <AIInsightCard 
                    type="operational"
                    text="Sábado representa 30% do seu faturamento semanal. Considere abrir 1h mais cedo."
                    onClick={onGoToSettings}
                />
            )}
            {showChurn && (
                <AIInsightCard 
                    type="churn"
                    text="Detectei 12 clientes VIP que não retornaram há mais de 45 dias. Toque para ver a lista."
                    onClick={() => toast.info("Abrindo lista de Churn...")}
                />
            )}
            {showFinancial && (
                <AIInsightCard 
                    type="financial"
                    text="O serviço 'Combo' tem margem 15% maior que serviços avulsos. Sugira no checkout."
                    onClick={() => toast.success("Análise de margem carregada!")}
                />
            )}
            
            {(!showOperational && !showChurn && !showFinancial) && (
                <div className="col-span-full text-center p-4 border border-dashed border-barber-800 rounded-xl text-muted text-sm">
                    IA Ativada, mas nenhum tipo de insight selecionado. <button onClick={onGoToSettings} className="text-barber-gold hover:underline">Configurar</button>
                </div>
            )}
        </div>
      )}
      
      {!settings?.aiConfig.enableInsights && (
         <div className="bg-barber-900 border border-barber-800 p-3 rounded-lg flex flex-col sm:flex-row justify-between items-center opacity-70 hover:opacity-100 transition-opacity gap-2">
            <span className="text-xs text-muted text-center sm:text-left">Insights de IA desativados.</span>
            <button onClick={onGoToSettings} className="text-xs bg-barber-950 px-3 py-1 rounded text-main flex items-center gap-1 w-full sm:w-auto justify-center">
                <SettingsIcon size={12} /> Configurar
            </button>
         </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Faturamento Hoje" 
          value="R$ 1.250" 
          subtext="8 agendamentos concluídos" 
          icon={TrendingUp} 
          trend={12} 
        />
        <StatCard 
          title="Agendamentos" 
          value="24" 
          subtext="4 pendentes de confirmação" 
          icon={Scissors} 
          trend={5} 
        />
        <StatCard 
          title="Novos Clientes" 
          value="6" 
          subtext="Vieram pelo Instagram" 
          icon={Users} 
          trend={-2} 
        />
        <StatCard 
          title="Taxa No-Show" 
          value="4.2%" 
          subtext="Baixo risco esta semana" 
          icon={AlertCircle} 
          trend={-0.5} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <Card className="lg:col-span-2 shadow-lg" noPadding>
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-main">Receita Semanal</h3>
                <select className="bg-barber-950 border border-barber-800 text-xs text-muted rounded px-2 py-1 outline-none">
                    <option>Esta Semana</option>
                    <option>Mês Passado</option>
                </select>
            </div>
            <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%" minHeight={200}>
                <BarChart data={data}>
                    <XAxis 
                    dataKey="name" 
                    stroke="#71717a" 
                    tick={{ fill: '#71717a' }} 
                    axisLine={false}
                    tickLine={false}
                    />
                    <YAxis 
                    stroke="#71717a" 
                    tick={{ fill: '#71717a' }} 
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => `R$${value}`}
                    />
                    <Tooltip 
                    cursor={{ fill: '#27272a' }}
                    contentStyle={{ backgroundColor: 'rgb(var(--color-surface))', borderColor: 'rgb(var(--color-border))', color: 'rgb(var(--color-text-main))' }}
                    itemStyle={{ color: 'rgb(var(--color-text-main))' }}
                    labelStyle={{ color: 'rgb(var(--color-text-muted))' }}
                    />
                    <Bar dataKey="total" radius={[4, 4, 0, 0]}>
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index === 5 ? 'rgb(var(--color-primary))' : '#52525b'} />
                    ))}
                    </Bar>
                </BarChart>
                </ResponsiveContainer>
            </div>
          </div>
        </Card>

        {/* WhatsApp/Requests Feed */}
        <Card className="flex flex-col shadow-lg" noPadding>
          <div className="p-6 flex flex-col h-full">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-main flex items-center gap-2">
                <MessageCircle className="text-emerald-500" size={20} />
                Solicitações
                </h3>
                <span className="bg-emerald-500/20 text-emerald-500 text-xs px-2 py-1 rounded-full font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                Bot Ativo
                </span>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-4 max-h-[300px] lg:max-h-none">
                {pendingRequests.map((req) => (
                <div key={req.id} className="bg-barber-950 p-4 rounded-lg border border-barber-800 flex flex-col gap-3">
                    <div className="flex justify-between items-start">
                    <div>
                        <h4 className="font-bold text-main">{req.name}</h4>
                        <p className="text-sm text-muted">{req.service}</p>
                    </div>
                    <div className="text-right">
                        <div className="text-barber-gold font-bold">{req.time}</div>
                        <div className="text-xs text-muted">{req.source}</div>
                    </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                        <Button variant="primary" size="sm" className="flex-1" leftIcon={<CheckCircle2 size={16} />}>
                            Confirmar
                        </Button>
                        <Button variant="secondary" size="sm" className="flex-1">
                            Reagendar
                        </Button>
                    </div>
                </div>
                ))}
                
                <div className="bg-barber-950/50 p-4 rounded-lg border border-barber-800/50 border-dashed text-center text-muted text-sm">
                <Clock size={20} className="mx-auto mb-2 opacity-50" />
                Aguardando novas mensagens...
                </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
