

export enum Status {
  CONFIRMED = 'Confirmado',
  PENDING = 'Pendente',
  COMPLETED = 'Concluído',
  NOSHOW = 'Faltou',
  CANCELED = 'Cancelado',
  BLOCKED = 'Bloqueado'
}

export enum PaymentMethod {
  PIX = 'Pix',
  CREDIT_CARD = 'Cartão de Crédito',
  CASH = 'Dinheiro',
  DEBIT_CARD = 'Débito'
}

export type Role = 'Admin' | 'Manager' | 'Barber';

export type BusinessType = 'barbershop' | 'beauty_salon';

export interface UserProfile {
  name: string;
  email: string;
  avatar?: string;
  role: Role;
  phone?: string;
}

export interface WorkDay {
  dayOfWeek: number; // 0=Sun, 1=Mon, ...
  startTime: string; // "09:00"
  endTime: string; // "19:00"
  breakStart?: string; // "12:00"
  breakEnd?: string; // "13:00"
  active: boolean;
}

export interface SystemSettings {
  businessName: string;
  businessAddress: string;
  businessPhone: string;
  businessEmail: string;
  businessHours: WorkDay[]; // Global operating hours
  modules: {
    products: boolean;
    finance: boolean;
    aiChatbot: boolean;
    publicBooking: boolean;
    loyaltyProgram: boolean;
  };
  aiConfig: {
    enableInsights: boolean;
    insightTypes: {
      financial: boolean; // Dicas de lucro/meta
      churn: boolean; // Clientes sumidos
      operational: boolean; // Otimização de agenda
    };
    notificationFrequency: 'low' | 'medium' | 'high';
    tone: 'professional' | 'friendly' | 'analytical'; // New customization option
  };
}

export interface Barber {
  id: string;
  name: string;
  specialty: string;
  avatar: string;
  email?: string;
  phone?: string;
  commissionRate: number; // percentage
  rating: number;
  goal?: number; // Meta financeira mensal
  currentSales?: number; // Vendas atuais
  workSchedule?: WorkDay[];
  useCustomBuffer?: boolean;
  bufferTime?: number;
  services?: string[]; // IDs of services this barber performs
}

export interface Resource {
  id: string;
  name: string;
  type: 'Cadeira' | 'Lavatório' | 'Sala Estética';
  status: 'active' | 'maintenance';
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  duration: number; // minutes
  category?: string; // Flexible category
  active: boolean;
  commissionRate?: number; // percentage override
  image?: string;
  billingType?: 'one_time' | 'recurring';
}

export interface Product {
  id: string;
  name: string;
  category: 'Pomada' | 'Shampoo' | 'Óleo' | 'Equipamento' | 'Bebida' | 'Outro';
  price: number;
  costPrice: number;
  stock: number;
  minStock: number;
  image?: string;
  commissionRate?: number;
}

export interface MembershipPlan {
  id: string;
  name: string;
  price: number;
  description: string;
  benefits: string[];
  billingCycle: 'Mensal' | 'Anual';
}

export type LoyaltyTier = 'Bronze' | 'Prata' | 'Ouro' | 'Diamante';

export interface ClientPhoto {
  id: string;
  url: string;
  date: string;
  type: 'before' | 'after';
  notes?: string;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  lastVisit: string;
  totalVisits: number;
  loyaltyPoints?: number; // Pontos atuais (ex: 7/10)
  tags: string[]; // e.g., 'VIP', 'No-Show Risk'
  // CRM Avançado
  ltv?: number; // Lifetime Value
  preferences?: string;
  allergies?: string[]; // Ex: 'Alergia a Menta'
  internalNotes?: string; // Visível apenas para barbeiros
  drinkPreference?: string;
  conversationStyle?: 'Conversador' | 'Quieto' | 'Profissional';
  birthDate?: string;
  photos?: ClientPhoto[];
  loyaltyTier?: LoyaltyTier;
  activeMembership?: string; // ID of the plan
}

export interface WaitlistItem {
  id: string;
  clientName: string;
  serviceName: string;
  phone: string;
  notes?: string;
  priority: 'High' | 'Normal' | 'Low';
  requestTime: string; // e.g. "Após 18h"
  createdAt: string;
}

export interface ConsumptionItem {
  id: string;
  productId: string;
  name: string;
  quantity: number;
  price: number;
}

export interface Appointment {
  id: string;
  clientName: string;
  barberId: string;
  resourceId?: string; // ID do recurso (Cadeira 1, etc)
  serviceId: string;
  date: string; // ISO date
  time: string; // HH:mm
  status: Status;
  hasDeposit: boolean;
  consumption?: ConsumptionItem[];
}

export interface FinancialRecord {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  method?: PaymentMethod;
  barberId?: string;
}

export interface RecurringExpense {
  id: string;
  description: string;
  amount: number;
  dayOfMonth: number;
  active: boolean;
  category: string;
}

export interface Notification {
  id: string;
  type: 'payment' | 'appointment' | 'cancel' | 'system';
  title: string;
  message: string;
  time: string;
  read: boolean;
}